from consumer.aws_consumer.aws_eventbridge_consumer_ec2_running import NewEC2RunningConsumer
from consumer.base_consumer import BaseConsumer
from consumer.gcp_consumer.gcp_pubsub_consumer_new_compute import NewGCPComputeConsumer
from triggers.base_trigger import BaseTrigger


class NewEC2RunningEvent(BaseTrigger):
    def entry_point(self, data, cloud_type="gcp"):
        self.execute_consumer(data, cloud_type)

    def get_consumer_for_trigger(self, cloud_type="gcp") -> BaseConsumer:
        if cloud_type == "aws":
            return NewEC2RunningConsumer(
                consumer_config=self.create_executor_config())
        elif cloud_type == "gcp":
            return NewGCPComputeConsumer(consumer_config=self.create_consumer_config())
