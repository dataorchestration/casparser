import os

from consumer.aws_consumer.aws_sqs_consumer_compute_listing import AWSSQSConsumerComputeListing
from consumer.azure_consumer.azure_service_bus_consumer_compute_listing import AzureServiceBusConsumerComputeListing
from consumer.base_consumer import BaseConsumer
from consumer.gcp_consumer.gcp_pubsub_consumer_compute_listing import GCPPubSubConsumerComputeListing
from triggers.base_trigger import BaseTrigger


class TriggerDiskSnapshottingForIncomingCompute(BaseTrigger):
    def entry_point(self, data, cloud_type="gcp"):
        self.execute_consumer(data, cloud_type)

    def get_consumer_for_trigger(self, cloud_type="gcp") -> BaseConsumer:
        if cloud_type == "gcp":
            return GCPPubSubConsumerComputeListing(
                consumer_config=self.create_consumer_config())
        if cloud_type == "aws":
            return AWSSQSConsumerComputeListing(
                consumer_config=self.create_consumer_config())
        if cloud_type == "azure":
            return AzureServiceBusConsumerComputeListing(consumer_config=self.create_consumer_config())
