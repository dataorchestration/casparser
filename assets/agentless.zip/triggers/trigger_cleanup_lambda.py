from consumer.base_consumer import BaseConsumer
from executors.aws_executor.cleanup_executor import AWSCleanUpExecutor
from executors.aws_executor.monitoring_executor import AWSMonitoringExecutor
from executors.base_executor import BaseExecutor
from triggers.base_trigger import BaseTrigger


class TriggerCleanUp(BaseTrigger):
    def entry_point(self, data, cloud_type="gcp"):
        self.execute_lambda(cloud_type)

    def get_executor(self, cloud_type="gcp") -> BaseExecutor:
        if cloud_type == "aws":
            return AWSCleanUpExecutor(consumer_config=self.create_executor_config())
