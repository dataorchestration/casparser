from consumer.aws_consumer.aws_sqs_consumer_snapshot_waiting import AWSSQSConsumerSnapshotWaiting
from consumer.azure_consumer.azure_service_bus_consumer_copy_disk import AzureServiceBusConsumerCopyDisk
from consumer.azure_consumer.azure_service_bus_consumer_create_disk import AzureServiceBusConsumerCreateDisk
from consumer.base_consumer import BaseConsumer
from consumer.gcp_consumer.gcp_pubsub_consumer_snapshot_waiting import GCPPubSubConsumerSnapshotWaiting
from triggers.base_trigger import BaseTrigger


class TriggerDiskCreationOnSnapshotComplete(BaseTrigger):
    def entry_point(self, data, cloud_type="gcp"):
        self.execute_consumer(data, cloud_type)

    def get_consumer_for_trigger(self, cloud_type="gcp") -> BaseConsumer:
        if cloud_type == "gcp":
            return GCPPubSubConsumerSnapshotWaiting(
                consumer_config=self.create_consumer_config())
        if cloud_type == "aws":
            return AWSSQSConsumerSnapshotWaiting(consumer_config=self.create_consumer_config())
        if cloud_type == "azure":
            return AzureServiceBusConsumerCreateDisk(consumer_config=self.create_consumer_config())
