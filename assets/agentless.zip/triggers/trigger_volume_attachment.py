import os

from funcy import merge

from consumer.aws_consumer.aws_sqs_consumer_volume_attachment import AWSSQSConsumerVolumeAttachment
from consumer.azure_consumer.azure_service_bus_consumer_disk_attachment import AzureServiceBusConsumerDiskAttachment
from consumer.base_consumer import BaseConsumer
from consumer.gcp_consumer.gcp_pubsub_consumer_volume_attachment import GCPPubSubConsumerVolumeAttachment
from triggers.base_trigger import BaseTrigger


class TriggerVolumeAttachment(BaseTrigger):
    def entry_point(self, data, cloud_type="gcp"):
        self.execute_consumer(data, cloud_type)

    def get_consumer_for_trigger(self, cloud_type="gcp") -> BaseConsumer:
        if cloud_type == "gcp":
            return GCPPubSubConsumerVolumeAttachment(
                consumer_config=merge(self.create_consumer_config(), {"tags": os.getenv("TAGS", "").split(", ")}))
        if cloud_type == "aws":
            return AWSSQSConsumerVolumeAttachment(consumer_config=self.create_consumer_config())
        if cloud_type == "azure":
            return AzureServiceBusConsumerDiskAttachment(consumer_config=self.create_consumer_config())
