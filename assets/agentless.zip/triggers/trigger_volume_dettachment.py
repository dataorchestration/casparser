import os

from funcy import merge

from consumer.aws_consumer.aws_sqs_consumer_volume_dettachment import AWSSQSConsumerVolumeDettachment
from consumer.base_consumer import BaseConsumer
from consumer.gcp_consumer.gcp_pubsub_consumer_volume_dettachment import GCPPubSubConsumerVolumeDettachment
from triggers.base_trigger import BaseTrigger


class TriggerVolumeDettachment(BaseTrigger):
    def entry_point(self, data, cloud_type="gcp"):
        self.execute_consumer(data, cloud_type)

    def get_consumer_for_trigger(self, cloud_type="gcp") -> BaseConsumer:
        if cloud_type == "gcp":
            return GCPPubSubConsumerVolumeDettachment(
                consumer_config=merge(self.create_consumer_config(), {"tags": os.getenv("TAGS").split(",")}))
        if cloud_type == "aws":
            return AWSSQSConsumerVolumeDettachment(
                consumer_config=self.create_consumer_config())
