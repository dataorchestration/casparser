import fire


def main():
    fire.Fire()
