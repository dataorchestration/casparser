import os

from funcy import merge

from consumer.base_consumer import BaseConsumer
from executors.base_executor import BaseExecutor
from logger.custom_logging import log
from services.consumer_services import get_envs_from_filepath


class BaseTrigger():
    def entry_point(self, data):
        raise NotImplementedError()

    def get_consumer_for_trigger(self, cloud_type=None) -> BaseConsumer:
        # this can be from yaml file too
        raise NotImplementedError()

    def get_executor(self, cloud_type="gcp") -> BaseExecutor:
        raise NotImplementedError()

    def create_consumer_config(self):
        # printing all env variables
        # logging all env variables
        log(f"setting output topic {os.getenv('OUTPUT_TOPIC')}")
        return {"output_topic_name": os.getenv("OUTPUT_TOPIC"),
                "project_id": os.getenv("PROJECT_ID"),
                "zone": os.getenv("ZONE"),
                "region": os.getenv("REGION"),
                "account_id": os.getenv("ACCOUNT_ID"),
                "tags": os.getenv("TAGS", "").split(", "),
                "subscription_id": os.getenv("SUBSCRIPTION_ID", None),
                "queue_name": os.getenv("QUEUE_NAME", None),
                "resource_group_name": os.getenv("RESOURCE_GROUP_NAME", None),
                "storage_account_name": os.getenv("STORAGE_ACCOUNT_NAME", None),
                "container_name": os.getenv("CONTAINER_NAME", None),
                "tenant_id": os.getenv("TENANT_ID", None),
                "client_id": os.getenv("CLIENT_ID", None),
                "client_secret": os.getenv("CLIENT_SECRET", None),
                "output_service_bus_connection_string": os.getenv("OUTPUT_SERVICE_BUS_CONNECTION_STRING", None),
                "snapshot_storage_connection_string": os.getenv("SNAPSHOT_STORAGE_CONNECTION_STRING", None),
                "snapshot_storage_name": os.getenv("SNAPSHOT_STORAGE_NAME", None),

                }

    def create_executor_config(self):
        ## convert all env to dict
        env_dict = {}
        for key, value in os.environ.items():
            env_dict[key] = value
        env_dict = merge(env_dict, {"tags": os.getenv("TAGS", "").split(", ")})
        # need to set resource_group_name,subscription_id,client_id,tenent_id,client_secret,OUTPUT_TOPIC,OUTPUT_SERVICE_BUS_CONNECTION_STRING
        env_dict["resource_group_name"] = get_envs_from_filepath()['resource_group_name']
        env_dict["subscription_id"] = get_envs_from_filepath()['subscription_id']
        env_dict["client_id"] = get_envs_from_filepath()['client_id']
        env_dict["tenant_id"] = get_envs_from_filepath()['tenant_id']
        env_dict["client_secret"] = get_envs_from_filepath()['client_secret']
        env_dict["OUTPUT_TOPIC"] = get_envs_from_filepath()['compute_listing_queue_name']
        env_dict["OUTPUT_SERVICE_BUS_CONNECTION_STRING"] = get_envs_from_filepath()[
            'queue_subscription_connection_string']
        return env_dict

    def execute_consumer(self, data, cloud_type="gcp"):
        consumer = self.get_consumer_for_trigger(cloud_type)
        log(f"triggering handle input message {data}")
        consumer.handle_input_message(data)
        if_filtered = consumer.apply_filter()
        if if_filtered:
            log(f"triggering apply {data}")
            consumer.apply()
            log(f"triggering output handler {data}")
            consumer.output_handler()
        else:
            log("filter failed with data: {} for consumer".format(data, consumer))
            consumer.failure_handler()

    def execute_lambda(self, cloud_type="gcp"):
        executor = self.get_executor(cloud_type)
        # here no parameters are passed to the lambda function
        executor.execute()
