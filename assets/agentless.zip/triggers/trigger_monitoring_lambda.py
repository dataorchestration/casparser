from consumer.base_consumer import BaseConsumer
from executors.aws_executor.monitoring_executor import AWSMonitoringExecutor
from executors.azure_executor import AzureMonitoringExecutor
from executors.base_executor import BaseExecutor
from executors.gcp_executors.monitoring_executor import GCPMonitoringExecutor
from triggers.base_trigger import BaseTrigger


class TriggerMonitoring(BaseTrigger):
    def entry_point(self, data, cloud_type="gcp"):
        self.execute_lambda(cloud_type)

    def get_executor(self, cloud_type="gcp") -> BaseExecutor:
        if cloud_type == "aws":
            return AWSMonitoringExecutor(consumer_config=self.create_executor_config())
        elif cloud_type == "gcp":
            return GCPMonitoringExecutor(consumer_config=self.create_executor_config())
        elif cloud_type == "azure":
            return AzureMonitoringExecutor(consumer_config=self.create_executor_config())