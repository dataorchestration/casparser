import enum
import os
from functools import partial

from executors.azure_executor import AzureMonitoringExecutor
from triggers.base_trigger import BaseTrigger
from triggers.trigger_disk_creation_for_snapshot_ready import TriggerDiskCreationOnSnapshotComplete
from triggers.trigger_disk_snapshotting_for_incoming_compute import TriggerDiskSnapshottingForIncomingCompute
from triggers.trigger_monitoring_lambda import TriggerMonitoring
from triggers.trigger_snapshot_copy import TriggerSnapshotCopy
from triggers.trigger_volume_attachment import TriggerVolumeAttachment


def get_function_name_from_consumer_name(consumer_name, cloud_type="azure") -> BaseTrigger.entry_point:
    if consumer_name == "compute_listing":
        return partial(TriggerDiskSnapshottingForIncomingCompute().entry_point, cloud_type=cloud_type)
    if consumer_name == "snapshot_copy":
        return partial(TriggerSnapshotCopy().entry_point, cloud_type=cloud_type)
    if consumer_name == "create_disk":
        return partial(TriggerDiskCreationOnSnapshotComplete().entry_point, cloud_type=cloud_type)
    if consumer_name == "attach_disk":
        return partial(TriggerVolumeAttachment().entry_point, cloud_type=cloud_type)


def get_executor_from_executor_name(executor_name, cloud_type="azure"):
    if executor_name == "compute_listing":
        return partial(TriggerMonitoring().get_executor, cloud_type=cloud_type)


def get_queue_property_by_consumer_name(consumer_name):
    if consumer_name == "compute_listing":
        return "compute-listing-queue"
    if consumer_name == "snapshot_copy":
        return "snapshot-copy-queue"
    if consumer_name == "create_disk":
        return "disk-creation-queue"
    if consumer_name == "attach_disk":
        return "disk-attach-queue"


class ServiceBusPropertyName(enum.Enum):
    TOPIC_NAME = "topic_name"
    SERVICE_BUS_CONNECTION_STRING = "service_bus_connection_string"
    TOPIC_SUBSCRIPTION_NAME = "topic_subscription_name"
    SERVICE_BUS_NAMESPACE_NAME = "service_bus_namespace_name"


class ConsumerNames(enum.Enum):
    COMPUTE_LISTING = "compute_listing"
    SNAPSHOT_COPY = "snapshot_copy"
    CREATE_DISK = "create_disk"
    ATTACH_DISK = "attach_disk"


def get_output_queue_for_consumer_name(consumer_name):
    if consumer_name == "compute_listing":
        return "snapshot-copy-queue"
    if consumer_name == "snapshot_copy":
        return "disk-creation-queue"
    if consumer_name == "create_disk":
        return "disk-attach-queue"


def get_input_queue_name_for_consumer_name(consumer_name):
    if consumer_name == "compute_listing":
        return get_envs_from_filepath()["compute_listing_queue_name"]
    if consumer_name == "snapshot_copy":
        return get_envs_from_filepath()["snapshot_copy_queue_name"]
    if consumer_name == "create_disk":
        return get_envs_from_filepath()["disk_create_queue_name"]
    if consumer_name == "attach_disk":
        return get_envs_from_filepath()["disk_attach_queue_name"]
    if consumer_name == "detach_disk":
        return get_envs_from_filepath()["disk_detach_queue_name"]


def get_subscription_name_for_consumer_name(consumer_name):
    if consumer_name == "compute_listing":
        return get_envs_from_filepath()["compute_listing_subscription_name"]
    if consumer_name == "snapshot_copy":
        return get_envs_from_filepath()["snapshot_copy_subscription_name"]
    if consumer_name == "create_disk":
        return get_envs_from_filepath()["disk_create_subscription_name"]
    if consumer_name == "attach_disk":
        return get_envs_from_filepath()["disk_attach_subscription_name"]
    if consumer_name == "detach_disk":
        return get_envs_from_filepath()["disk_detach_subscription_name"]


def get_output_queue_name_for_consumer_name(consumer_name):
    if consumer_name == "compute_listing":
        if os.getenv("CLOUD_TYPE") in ("aws", "gcp"):
            return get_envs_from_filepath()["disk_create_queue_name"]
        if os.getenv("CLOUD_TYPE") == "azure":
            return get_envs_from_filepath()["snapshot_copy_queue_name"]
    if consumer_name == "snapshot_copy":
        return get_envs_from_filepath()["disk_create_queue_name"]
    if consumer_name == "create_disk":
        return get_envs_from_filepath()["disk_attach_queue_name"]
    else:
        return "NOT_REQUIRED"


def get_envs_from_filepath(filepath=os.getenv("ENV_FILE_PATH")):
    # check if file exists
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"File {filepath} does not exist")
    with open(filepath, "r") as f:
        envs = f.read().splitlines()
    return {line.split("=", maxsplit=1)[0]: line.split("=", maxsplit=1)[1] for line in envs}


def service_bus_properties_by_consumer_name(consumer_name, property_name: ServiceBusPropertyName):
    return os.getenv(get_queue_property_by_consumer_name(consumer_name))[property_name.value]
