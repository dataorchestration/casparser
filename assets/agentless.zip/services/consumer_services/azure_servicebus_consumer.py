import os
import time
import traceback

import fire
from azure.servicebus import ServiceBusClient

from handlers.failure.RaiseExceptionHandler import QueuePushBackException
from logger.custom_logging import log
from services.consumer_services import get_function_name_from_consumer_name, get_input_queue_name_for_consumer_name, \
    get_subscription_name_for_consumer_name, get_envs_from_filepath, get_executor_from_executor_name


def start_service_bus_consumer(consumer_name):
    servicebus_client = ServiceBusClient.from_connection_string(os.getenv("INPUT_SERVICE_BUS_CONNECTION_STRING"))
    topic_name = os.getenv("INPUT_TOPIC_NAME")
    subscription_name = os.getenv("INPUT_TOPIC_SUBSCRIPTION_NAME")
    receiver = servicebus_client.get_subscription_receiver(topic_name, subscription_name)
    log(f"Starting consumer: {consumer_name}")
    with receiver:
        for msg in receiver:
            # renew lock if lock has expired
            try:
                log(f"Received message: {msg}")
                response = get_function_name_from_consumer_name(consumer_name)(data=msg)
                log(f"succeeded in processing message: {msg}")
                receiver.complete_message(msg)
            # extend lease if lock has expired
            except QueuePushBackException as e:
                log(f"Initial conditions are not matching for message, hence pushing back: {msg}")
                traceback.print_exc()
                receiver.abandon_message(msg)
                time.sleep(120)
            except Exception as e:
                log(f"Exception occurred while processing message: {msg}")
                traceback.print_exc()


def start_executor_from_exectuor_name(executor_name):
    get_executor_from_executor_name(executor_name)()


def read_from_env_file_and_trigger_by_consumer_name(consumer_name: str):
    log(f"flags path {os.getenv('ENV_FILE_PATH')}")
    os.environ["INPUT_TOPIC_NAME"] = get_input_queue_name_for_consumer_name(consumer_name)
    os.environ["INPUT_TOPIC_SUBSCRIPTION_NAME"] = get_subscription_name_for_consumer_name(consumer_name)
    os.environ["INPUT_SERVICE_BUS_CONNECTION_STRING"] = get_envs_from_filepath()['queue_subscription_connection_string']
    os.environ["REGION"] = get_envs_from_filepath()['region']
    os.environ["SNAPSHOT_STORAGE_NAME"] = get_envs_from_filepath()['snapshot_storage_name']
    os.environ["SNAPSHOT_STORAGE_CONNECTION_STRING"] = get_envs_from_filepath()['snapshot_storage_connection_string']
    start_service_bus_consumer(consumer_name)


if __name__ == '__main__':
    fire.Fire({"start_consumer": read_from_env_file_and_trigger_by_consumer_name,
               "start_executor": start_executor_from_exectuor_name, })
