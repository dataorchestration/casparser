import logging

import azure.functions as func

from triggers.trigger_disk_snapshotting_for_incoming_compute import TriggerDiskSnapshottingForIncomingCompute


def main(msg: func.ServiceBusMessage):
    logging.info('Python ServiceBus queue trigger processed message: %s',
                 msg.get_body().decode('utf-8'))
    TriggerDiskSnapshottingForIncomingCompute().entry_point(data=msg, cloud_type="azure")
