import os

from executors.base_executor import BaseExecutor
from logger.custom_logging import log
from utils.gcp.utils_gcp_compute import get_instances_with_greater_than_given_disk_slots, \
    get_all_instances_with_given_state, get_instances_with_disks_attached_less_than_given_limit, \
    gcp_start_suspended_instances_with_tag, gcp_suspend_running_instances_with_tag
from utils.gcp.utils_gcp_queue import get_number_of_messages_in_pubsub_queue


class GCPMonitoringExecutor(BaseExecutor):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def execute(self, *args, **kwargs):
        """
        scale up or down the number of instances based on the number of slots occupied
        """
        # get gcp instances with disks attached equal max slots
        # get gcp instances with disks attached less than min slots +1
        # instances running
        scale_up_by = 0
        scale_down_by = 0
        number_of_running_instances = len(get_all_instances_with_given_state(self.consumer_config.get("PROJECT_ID"),
                                                                             self.consumer_config.get("ZONE"),
                                                                             self.consumer_config.get("tags"),
                                                                             "RUNNING"))
        instances = get_instances_with_greater_than_given_disk_slots(self.consumer_config.get("PROJECT_ID"),
                                                                     self.consumer_config.get("ZONE"),
                                                                     self.consumer_config.get("tags"),
                                                                     int(os.getenv("MAX_SLOTS", 18)) - 1)
        instances_with_no_external_disks = get_instances_with_disks_attached_less_than_given_limit(
            self.consumer_config.get("PROJECT_ID"),
            self.consumer_config.get("ZONE"),
            self.consumer_config.get("tags"),
            int(os.getenv("MIN_SLOTS", 1)) + 1)
        if len(instances) > 0 and len(instances) < int(self.consumer_config.get("MAX_INSTANCES")):
            # scale up by scale up by
            log("Scaling up by {} since instances are suspended and slots are full with {}".format(
                int(os.getenv("SCALE_UP_BY", 1)), int(os.getenv("MAX_SLOTS", 18))))
            scale_up_by = int(os.getenv("SCALE_UP_BY", 1))

        if number_of_running_instances == 0 and int(
                self.consumer_config.get("MIN_INSTANCES")) == 0 and get_number_of_messages_in_pubsub_queue(
            self.consumer_config.get(
                "VOLUME_ATTACHMENT_TRIGGER_QUEUE"), self.consumer_config.get("PROJECT_ID")) > 0:
            log("Scaling up by {} since all instances are suspended and there are messages to be processed".format(
                int(os.getenv("SCALE_UP_BY", 1))))
            scale_up_by += 1

        if len(instances_with_no_external_disks) > int(self.consumer_config.get("MIN_INSTANCES")) and len(
                instances_with_no_external_disks) > 0:
            scale_down_by += int(os.getenv("SCALE_DOWN_BY", 1))

        if scale_up_by > 0:
            log("giving preferences to scale up and hence scaling by {}".format(int(os.getenv("SCALE_UP_BY", 1))))
            gcp_start_suspended_instances_with_tag(self.consumer_config.get("PROJECT_ID"),
                                                   self.consumer_config.get("ZONE"),
                                                   self.consumer_config.get("tags"), int(os.getenv("SCALE_UP_BY", 1)))
        elif scale_down_by > 0:
            log("since scaling up is not required we are scaling down instances")
            gcp_suspend_running_instances_with_tag(self.consumer_config.get("PROJECT_ID"),
                                                   self.consumer_config.get("ZONE"), self.consumer_config.get("tags"),
                                                   int(os.getenv("SCALE_DOWN_BY", 1)))
