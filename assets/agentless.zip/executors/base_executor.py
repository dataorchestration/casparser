class BaseExecutor():
    def __init__(self, *args, **kwargs):
        self.consumer_config = kwargs.get("consumer_config")

    def execute(self, *args, **kwargs):
        raise NotImplementedError()
