from executors.base_executor import BaseExecutor
from logger.custom_logging import log
from utils.aws.utils_compute import aws_get_all_snapshots_ids_with_given_tag, aws_delete_disk, aws_delete_snapshot, \
    aws_get_all_volume_ids_with_given_tag


class AWSCleanUpExecutor(BaseExecutor):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def execute(self, *args, **kwargs):
        log("triggering cleanup executor")
        region = self.consumer_config.get("REGION")
        account_id = self.consumer_config.get("ACCOUNT_ID")
        # get all snapshots with tag and value
        all_snapshots_with_tag = aws_get_all_snapshots_ids_with_given_tag(account_id, region, "CreatedBy",
                                                                          "UptycsAgentlessPipeline")
        log("all volumes with tag {}".format(all_snapshots_with_tag))
        # delete all volumes with created_by tag
        [aws_delete_snapshot(account_id, region, volume) for volume in all_snapshots_with_tag]
        all_snapshot_ids = aws_get_all_volume_ids_with_given_tag(account_id, region, "CreatedBy",
                                                                 "UptycsAgentlessPipeline")
        log("all snapshots with tag {}".format(all_snapshot_ids))
        # delete all snapshots with created_by tag
        [aws_delete_disk(account_id, region, volume) for volume in all_snapshot_ids]
