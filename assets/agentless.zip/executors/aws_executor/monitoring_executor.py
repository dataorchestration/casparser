import os

from executors.base_executor import BaseExecutor
from logger.custom_logging import log
from utils.aws.utils_compute import aws_get_instances_with_disks_attached_less_than_given_limit, \
    aws_get_instances_with_disks_attached_more_than_given_limit, \
    aws_start_the_instance, get_aws_instance_with_tags_and_given_state, aws_stop_the_instance
from utils.aws.utils_sqs import get_number_of_messages_in_sqs_queue


class AWSMonitoringExecutor(BaseExecutor):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def execute(self, *args, **kwargs):
        log("triggering base executor")
        scale_up_counter = 0
        scale_down_counter = 0
        tags = self.consumer_config.get("TAGS", "").split(", ")
        log(f"checking if slots occupied are greater than {int(os.getenv('MAX_SLOTS', 18)) - 1}")
        instances = aws_get_instances_with_disks_attached_more_than_given_limit(self.consumer_config.get("ACCOUNT_ID"),
                                                                                self.consumer_config.get("REGION"),
                                                                                tags,
                                                                                int(os.getenv("MAX_SLOTS", 18)) - 1,
                                                                                self.consumer_config.get("ZONE"))
        if len(instances) > 0 and len(instances) < int(self.consumer_config.get("MAX_INSTANCES")):
            log(f"instances with disks attached more than {int(os.getenv('MAX_SLOTS', 18)) - 1} are {instances}")
            log(f"scaling up by {int(os.getenv('SCALE_UP_BY', 1))}")
            scale_up_counter += 1

        log(f"checking if disks attached are less than min slots {int(os.getenv('MIN_SLOTS', 1)) + 1}")
        instances = aws_get_instances_with_disks_attached_less_than_given_limit(self.consumer_config.get("ACCOUNT_ID"),
                                                                                self.consumer_config.get("REGION"),
                                                                                tags,
                                                                                int(os.getenv("MIN_SLOTS", 1)) + 1,
                                                                                self.consumer_config.get("ZONE"))
        try:
            if len(instances) > 0 and len(instances) > int(self.consumer_config.get("MIN_INSTANCES")) and \
                    get_number_of_messages_in_sqs_queue(
                        self.consumer_config.get("ACCOUNT_ID"),
                        self.consumer_config.get("REGION"),
                        self.consumer_config.get(
                            "VOLUME_ATTACHMENT_TRIGGER_QUEUE")) == 0:
                log(f"instances with disks attached less than {int(os.getenv('MIN_SLOTS', 1)) + 1} are {instances}")
                log(f"scaling down by {int(os.getenv('SCALE_DOWN_BY', 1))}")
                scale_down_counter += 1
        except Exception as e:
            print("error in setting scaling down counter. error is " + str(e))

        try:
            if len(instances) == 0 and get_number_of_messages_in_sqs_queue(self.consumer_config.get("ACCOUNT_ID"),
                                                                           self.consumer_config.get("REGION"),
                                                                           self.consumer_config.get(
                                                                               "VOLUME_ATTACHMENT_TRIGGER_QUEUE")) > 0:
                scale_up_counter += 1
        except Exception as e:
            print("error in setting scale up counter. error is " + str(e))

        # we will either be scalling up or down, and priority will be given to scale up
        if scale_up_counter > 0:
            log("triggering scale up")
            instance_ids = get_aws_instance_with_tags_and_given_state(self.consumer_config.get("ACCOUNT_ID")
                                                                      , self.consumer_config.get("REGION"),
                                                                      tags, "stopped")
            # we will start the first instance which is stopped
            if len(instance_ids) > 0:
                aws_start_the_instance(self.consumer_config.get("ACCOUNT_ID"),
                                       self.consumer_config.get("REGION"), instance_ids[0])
        elif scale_down_counter > 0:
            log("triggering scale down")
            instance_ids = get_aws_instance_with_tags_and_given_state(self.consumer_config.get("ACCOUNT_ID"),
                                                                      self.consumer_config.get("REGION"),
                                                                      tags, "running")
            # we will stop the first instance which is running
            if len(instance_ids) > 0:
                log(f"we have {len(instance_ids)} instances running and stopping because of scale down")
                aws_stop_the_instance(self.consumer_config.get("ACCOUNT_ID"), self.consumer_config.get("REGION"),
                                      instance_ids[0])
