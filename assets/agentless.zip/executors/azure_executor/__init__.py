import os
from datetime import datetime

from executors.base_executor import BaseExecutor
from messages.message_ec2_scanning_info import InstanceVolumeToScan
from utils.azure.utils_compute import azure_get_vm_with_filters
from utils.azure.utils_service_bus import send_message_to_service_bus_topic


class AzureMonitoringExecutor(BaseExecutor):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def execute(self, *args, **kwargs):
        # fetch all the instances with given tags and os_type
        # return json of type {'name': 'myvm-vmLinux-0', 'os_type': 'Linux', 'os_disk_name': 'osdisk-myvm-0', 'os_disk_size': 30, 'data_disk_name': None, 'data_disk_size': None, 'resource_group_name': 'uptycs-resource'}]
        vms = azure_get_vm_with_filters(self.consumer_config.get("resource_group_name"),
                                        self.consumer_config.get("subscription_id"),
                                        self.consumer_config.get("client_id"),
                                        self.consumer_config.get("tenant_id"),
                                        self.consumer_config.get("client_secret"))
        # send messages to compute listing queue
        for vm in vms:
            instance_volume_to_scan = InstanceVolumeToScan(volume_name=vm.get("os_disk_name"),
                                                           dest_snapshot_name=f"monitorting-triggered-{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}",
                                                           dest_volume_name=f"snapshot_created_volume-{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}")
            json_data = instance_volume_to_scan.to_json()
            send_message_to_service_bus_topic(self.consumer_config.get("OUTPUT_SERVICE_BUS_CONNECTION_STRING"),
                                              self.consumer_config.get("OUTPUT_TOPIC"),
                                              json_data)
