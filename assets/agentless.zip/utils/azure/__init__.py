# fetch azure token from azure from vm from 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fmanagement.azure.com%2F' -H Metadata:true -s
def fetch_azure_token():
    import requests
    import json
    import os

    url = "http://169.254.169.254/metadata/identity/oauth2/token"
    params = {
        "api-version": "2018-02-01",
        "resource": "https://management.azure.com/"
    }
    headers = {
        "Metadata": "true"
    }
    response = requests.get(url, params=params, headers=headers)
    if response.status_code == 200:
        response_json = json.loads(response.text)
        return response_json["access_token"]
