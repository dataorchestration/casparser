import time
from datetime import datetime, timedelta

from azure.identity import ClientSecretCredential, ManagedIdentityCredential, DefaultAzureCredential
from azure.mgmt.compute import ComputeManagementClient, models
from azure.mgmt.compute.v2022_07_02.models import GrantAccessData
from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions

from logger.custom_logging import log


def get_compute_client(client_id, client_secret, tenant_id, subscription_id):
    """
    This method will return azure compute client
    :return:
    """
    if client_id is not None or client_secret is not None or tenant_id is not None or subscription_id is not None:
        credentials = ClientSecretCredential(
            client_id=client_id,
            client_secret=client_secret,
            tenant_id=tenant_id
        )
    else:
        credentials = DefaultAzureCredential()
    compute_client = ComputeManagementClient(credential=credentials, subscription_id=subscription_id)
    return compute_client


def get_blob_service_client(client_id, client_secret, tenant_id, connection_string):
    """
    This method will return blob service client
    :return:
    """
    credentials = ClientSecretCredential(
        client_id=client_id,
        client_secret=client_secret,
        tenant_id=tenant_id
    )
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    return blob_service_client


def azure_create_disk_from_disk_name(resource_group_name, subscription_id, client_id, tenant_id, client_secret,
                                     disk_name, snapshot_name, location):
    """
    This method will create snapshot from disk name
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param disk_name:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    disk = compute_client.disks.get(resource_group_name=resource_group_name, disk_name=disk_name)
    disk = compute_client.disks.begin_create_or_update(
        resource_group_name,
        snapshot_name,
        {
            'location': location,
            'creation_data': {
                'create_option': 'Copy',
                'source_uri': disk.id
            }},
        polling=True

    )
    response = disk
    return response


def azure_create_snapshot_from_disk_name(resource_group_name, subscription_id, client_id, tenant_id, client_secret,
                                         disk_name, snapshot_name, location):
    """
    This method will create snapshot from disk name
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param disk_name:
    :param snapshot_name:
    :param location:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    disk = compute_client.disks.get(resource_group_name=resource_group_name, disk_name=disk_name)
    snapshot = compute_client.snapshots.begin_create_or_update(
        resource_group_name,
        snapshot_name,
        {
            'location': location,
            'creation_data': {
                'create_option': 'Copy',
                'source_uri': disk.id
            }}
    )
    return snapshot


def azure_check_if_snapshot_is_ready(resource_group_name, subscription_id, client_id, tenant_id, client_secret,
                                     snapshot_name):
    """
    This method will check if snapshot is ready
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param snapshot_name:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    snapshot = compute_client.snapshots.get(resource_group_name=resource_group_name, snapshot_name=snapshot_name)
    return snapshot.provisioning_state == "Succeeded"


def azure_create_sas_url(resource_group_name, subscription_id, client_id, tenant_id, client_secret, snapshot_name):
    """
    This method will create sas url from disk name
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param snapshot_name:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    disk = compute_client.snapshots.begin_grant_access(resource_group_name=resource_group_name,
                                                       snapshot_name=snapshot_name,
                                                       grant_access_data=GrantAccessData(
                                                           access="Read",
                                                           duration_in_seconds=1200)

                                                       )

    sas_url = disk.result()
    return sas_url.access_sas


def get_azure_storage_id_from_sas_url(sas_url):
    """
    This method will return azure storage id from sas url
    :param sas_url:
    :return:
    """
    return sas_url.split("?")[0]


def create_disk_from_snapshot_sas_url(resource_group_name, subscription_id, client_id, tenant_id, client_secret,
                                      sas_url, disk_name, location, snapshot_storage_name, disk_type="Standard_LRS",
                                      zones=["1"]):
    """
    This method will create disk from snapshot name
    :param resource_group_name: 
    :param subscription_id: 
    :param client_id: 
    :param tenant_id: 
    :param client_secret: 
    :param sas_url: 
    :param disk_name: 
    :param location: 
    :return: 
    """
    # load storage account from
    qualified_storage_account_id = f"/subscriptions/{subscription_id}/resourceGroups/{resource_group_name}/providers/Microsoft.Storage/storageAccounts/{snapshot_storage_name}"
    creation_data = {
        'location': location,
        'creation_data': {
            'source_uri': sas_url,
            'storage_account_id': qualified_storage_account_id,
            'create_option': models.DiskCreateOption.IMPORT,
            'zone_resilient': True,
        },
        'sku': {'name': disk_type},
        'zones': zones
    }
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    disk = compute_client.disks.begin_create_or_update(
        resource_group_name,
        disk_name,
        creation_data)
    return disk


def azure_delete_disk(resource_group_name, subscription_id, client_id, tenant_id, client_secret, disk_name):
    """
    This method will delete disk
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param disk_name:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    response = compute_client.disks.begin_delete(resource_group_name, disk_name)
    return response


def azure_delete_snapshot(resource_group_name, subscription_id, client_id, tenant_id, client_secret, snapshot_name):
    """
    This method will delete snapshot
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param snapshot_name:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    response = compute_client.snapshots.begin_delete(resource_group_name, snapshot_name)
    return response


def azure_get_disk_size(resource_group_name, subscription_id, client_id, tenant_id, client_secret, disk_name):
    """
    This method will get disk size
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param disk_name:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    disk = compute_client.disks.get(resource_group_name=resource_group_name, disk_name=disk_name)
    response = disk.disk_size_gb
    return response


def get_next_lun(data_disks):
    """
    This method will get next lun
    :param data_disks:
    :return:
    """
    lun = 0
    for disk in data_disks:
        if disk.lun > lun:
            lun = disk.lun
    return lun + 1


def azure_attach_disk_to_vm(resource_group_name, subscription_id, client_id, tenant_id, client_secret, disk_id,
                            vm_name):
    """
    This method will attach disk to vm
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param disk_id:
    :param vm_name:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    vm = compute_client.virtual_machines.get(resource_group_name=resource_group_name, vm_name=vm_name)
    vm.storage_profile.data_disks.append({
        'lun': get_next_lun(vm.storage_profile.data_disks),
        'id': disk_id,
        'create_option': 'Attach',
        'managed_disk': {
            'id': disk_id
        }
    })
    response = compute_client.virtual_machines.begin_create_or_update(resource_group_name, vm_name, vm)
    return response


def get_blob_sas_url(resource_group_name, subscription_id, client_id, tenant_id, client_secret, storage_account_name,
                     container_name, blob_name,
                     permission=BlobSasPermissions(read=True, write=True, delete=True, create=True),
                     expiry=datetime.utcnow() + timedelta(hours=1), storage_connection_sting=None):
    """

    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param storage_account_name:
    :param container_name:
    :param blob_name:
    :param permission:
    :param expiry:
    :return:
    """
    blob_service_client = get_blob_service_client(client_id, client_secret, tenant_id, storage_connection_sting)
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    sas_token = generate_blob_sas(account_name=storage_account_name,
                                  account_key=blob_service_client.credential.account_key,
                                  container_name=container_name, blob_name=blob_name, permission=permission,
                                  expiry=expiry)
    sas_url = blob_client.url + "?" + sas_token
    return sas_url


def copy_snapshot_blob_from_sas_url_to_blob_storage(subscription_id, client_id, tenant_id,
                                                    client_secret, sas_url, snapshot_storage_connection_string,
                                                    dest_container_name,
                                                    dest_blob_name) -> object:
    """
    This method will copy snapshot blob from sas url to blob storage
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param sas_url:
    :param storage_account_name:
    :param dest_container_name:
    :param dest_blob_name:
    :return:
    az storage blob copy start --account-name storageforsnapshots -b snapshot1 -c snapshot-test-snapshot-2023-04-24-23-11-30 -u 'https://md-f5j4dg1hx4nr.z38.blob.storage.azure.net/v2mrmn42spsf/abcd?sv=2018-03-28&sr=b&si=b17810ec-0857-461e-86d2-2d63205951e2&sig=4SemDgodvjJ%2BKHdGViPqH8MTw7Qbmx20ADqSbrZ8a1o%3D'
    """
    blob_service_client = get_blob_service_client(client_id, client_secret, tenant_id,
                                                  snapshot_storage_connection_string)
    blob_client = blob_service_client.get_blob_client(container=dest_container_name, blob=dest_blob_name)
    blob_client.start_copy_from_url(sas_url)
    blob = blob_service_client.get_blob_client(container=dest_container_name,
                                               blob=dest_blob_name)
    copy_status = blob.get_blob_properties().copy.status
    return copy_status


def check_blob_status(subscription_id, client_id, tenant_id, client_secret, storage_connection_string,
                      container_name, blob_name):
    """
    This method will check blob status
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param storage_account_name:
    :param container_name:
    :param blob_name:
    :return:
    """
    blob_service_client = get_blob_service_client(client_id, client_secret, tenant_id, storage_connection_string)
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    blob_status_dictionary = blob_client.get_blob_properties()
    return blob_status_dictionary.copy.status


def check_if_bob_status_is_completed(subscription_id, client_id, tenant_id, client_secret, storage_connection_string,
                                     container_name, blob_name):
    """
    This method will check blob status
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param storage_connection_string:
    :param container_name:
    :param blob_name:
    :return:
    """
    blob_service_client = get_blob_service_client(client_id, client_secret, tenant_id, storage_connection_string)
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    blob_status_dictionary = blob_client.get_blob_properties()
    return blob_status_dictionary.copy.status == "success"


def get_blob_copy_status_from_sas_url_to_blob_storage(subscription_id, client_id, tenant_id,
                                                      client_secret, sas_url, container_name,
                                                      blob_name):
    """
    This method will copy snapshot blob from sas url to blob storage
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param sas_url:
    :param storage_account_name:
    :param container_name:
    :param blob_name:
    :return:
    """
    blob_service_client = get_blob_service_client(client_id, client_secret, tenant_id, subscription_id)
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    blob_status_dictionary = blob_client.get_blob_properties(sas_url)
    return blob_status_dictionary['copy_status']


def azure_disk_get_free_disk_slots_available(subscription_id, client_id, tenant_id, client_secret,
                                             resource_group_name, vm_name):
    """
    This method will return the number of free disk slots available on the VM
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param resource_group_name:
    :param vm_name:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    vm = compute_client.virtual_machines.get(resource_group_name, vm_name)
    disks = vm.storage_profile.data_disks
    # get first slot number which is free
    free_disk_slot = 0
    for disk in disks:
        if disk.lun > free_disk_slot:
            free_disk_slot = disk.lun
    return free_disk_slot + 1


def azure_get_number_of_disks_attached_to_vm(subscription_id, client_id, tenant_id, client_secret,
                                             resource_group_name, vm_name):
    """
    This method will return the number of disks attached to the VM
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param resource_group_name:
    :param vm_name:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    vm = compute_client.virtual_machines.get(resource_group_name, vm_name)
    disks = vm.storage_profile.data_disks
    return len(disks)


def azure_check_if_disk_is_created(resource_group_name, subscription_id, client_id, tenant_id, client_secret,
                                   disk_name):
    """
    This method will check if disk is created
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param disk_name:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    disk = compute_client.disks.get(resource_group_name, disk_name)
    return disk.provisioning_state == "Succeeded"


def azure_check_if_disk_exists(resource_group_name, subscription_id, client_id, tenant_id, client_secret,
                               disk_name):
    """
    This method will check if disk exists
    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param disk_name:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    disk = compute_client.disks.get(resource_group_name, disk_name)
    return disk is not None


def azure_get_vm_with_filters(
        resource_group_name, subscription_id, client_id, tenant_id, client_secret):
    """

    :param resource_group_name:
    :param subscription_id:
    :param client_id:
    :param tenant_id:
    :param client_secret:
    :param tag_name:
    :param tag_value:
    :return:
    """
    compute_client = get_compute_client(client_id, client_secret, tenant_id, subscription_id)
    vms = compute_client.virtual_machines.list(resource_group_name)
    # return vms with name, os_type, os_disk_name, os_disk_size, data_disk_name, data_disk_size
    log(vms)
    vm_list = []
    for vm in vms:
        vm_dict = {}
        vm_dict['name'] = vm.name
        vm_dict['os_type'] = vm.storage_profile.os_disk.os_type
        vm_dict['os_disk_name'] = vm.storage_profile.os_disk.name
        vm_dict['os_disk_size'] = vm.storage_profile.os_disk.disk_size_gb
        vm_dict['data_disk_name'] = vm.storage_profile.data_disks[0].name if len(vm.storage_profile.data_disks) > 0 else None
        vm_dict['data_disk_size'] = vm.storage_profile.data_disks[0].disk_size_gb if len(vm.storage_profile.data_disks) > 0 else None
        vm_dict['resource_group_name'] = vm.id.split('/')[4]
        vm_list.append(vm_dict)
    return vm_list
