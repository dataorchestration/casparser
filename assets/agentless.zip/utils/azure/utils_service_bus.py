# send message to service bus
# Path: utils/azure/utils_service_bus.py
from azure.servicebus import ServiceBusMessage, ServiceBusClient


def send_single_message(sender, message_string):
    message = ServiceBusMessage(message_string)
    response = sender.send_messages(message)
    return response


def send_message_to_service_bus(connection_string, queue_name, message_string):
    servicebus_client = ServiceBusClient.from_connection_string(conn_str=connection_string, logging_enable=True)
    with servicebus_client:
        sender = servicebus_client.get_queue_sender(queue_name=queue_name)
        with sender:
            response = send_single_message(sender, message_string)
            return response


def send_message_to_service_bus_topic(connection_string, topic_name, message_string):
    servicebus_client = ServiceBusClient.from_connection_string(conn_str=connection_string, logging_enable=True)
    with servicebus_client:
        sender = servicebus_client.get_topic_sender(topic_name=topic_name)
        with sender:
            response = send_single_message(sender, message_string)
            return response


def receive_message_from_service_bus(connection_string, queue_name):
    servicebus_client = ServiceBusClient.from_connection_string(conn_str=connection_string, logging_enable=True)
    with servicebus_client:
        receiver = servicebus_client.get_queue_receiver(queue_name=queue_name, max_wait_time=5)
        with receiver:
            received_message = receiver.receive_messages(max_message_count=1, max_wait_time=5)
            for message in received_message:
                return message
            return None


def receive_message_from_service_bus_topic(connection_string, topic_name, subscription_name):
    servicebus_client = ServiceBusClient.from_connection_string(conn_str=connection_string, logging_enable=True)
    with servicebus_client:
        receiver = servicebus_client.get_subscription_receiver(topic_name=topic_name,
                                                               subscription_name=subscription_name,
                                                               max_wait_time=5)
        with receiver:
            received_message = receiver.receive_messages(max_message_count=1, max_wait_time=5)
            for message in received_message:
                return message
            return None
