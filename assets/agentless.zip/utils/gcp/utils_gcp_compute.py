import sys
from collections import defaultdict
from typing import Any

from logger.custom_logging import log


def list_all_instances(
        project_id: str,
):
    """
    Returns a dictionary of all instances present in a project, grouped by their zone.
    Args:
        project_id: project ID or project number of the Cloud project you want to use.
    Returns:
        A dictionary with zone names as keys (in form of "zones/{zone_name}") and
        iterable collections of Instance objects as values.
    """
    from google.cloud import compute_v1
    instance_client = compute_v1.InstancesClient()
    request = compute_v1.AggregatedListInstancesRequest()
    request.project = project_id
    # Use the `max_results` parameter to limit the number of results that the API returns per response page.
    request.max_results = 100

    agg_list = instance_client.aggregated_list(request=request)

    all_instances = defaultdict(list)
    # Despite using the `max_results` parameter, you don't need to handle the pagination
    # yourself. The returned `AggregatedListPager` object handles pagination
    # automatically, returning separated pages as you iterate over the results.
    for zone, response in agg_list:
        if response.instances:
            all_instances[zone].extend(response.instances)
            for instance in response.instances:
                log(f"Instances found: {zone} - {instance.name} ({instance.machine_type})")
    return all_instances


def get_instances_with_given_tag(project_id, zone, tag):
    instances = list_all_instances(project_id)
    instances_with_given_tags = []
    for zone, instances in instances.items():
        for instance in instances:
            if tag in instance.tags.items:
                instances_with_given_tags.append(instance)
    return instances_with_given_tags


def get_all_instances_with_given_state(project_id, zone, tags, state):
    instances = list_all_instances(project_id)
    instances_with_given_state = []
    for zone, instances in instances.items():
        for instance in instances:
            if instance.status == state and any(tag in instance.tags.items for tag in tags):
                instances_with_given_state.append(instance)
    return instances_with_given_state


def get_instance(project_id: str, zone: str, instance_name: str):
    """
    Get information about a VM instance in the given zone in the specified project.
    Args:
        project_id: project ID or project number of the Cloud project you want to use.
        zone: name of the zone you want to use. For example: “us-west3-b”
        instance_name: name of the VM instance you want to query.
    Returns:
        An Instance object.
    """
    from google.cloud import compute_v1
    instance_client = compute_v1.InstancesClient()
    instance = instance_client.get(
        project=project_id, zone=zone, instance=instance_name
    )
    return instance


def validate_gcp_instance(project_id, zone, instance_id, volume_id):
    response = get_instance(project_id, zone, instance_id)
    source_urls = [disk.source.split("/")[-1] for disk in response.disks]
    return volume_id in source_urls


def take_snapshot_for_disk(zone, project_id, volume_id, snapshot_name, region=None):
    from google.cloud import compute_v1
    if zone is not None:
        disk_client = compute_v1.DisksClient()
        disk = disk_client.get(project=project_id, zone=zone, disk=volume_id)
    else:
        # we are mostly thinking of zonal disks so this might come in less handy
        region_disk_client = compute_v1.RegionDisksClient()
        disk = region_disk_client.get(
            project=project_id, region=region, disk=volume_id
        )
    snapshot = compute_v1.Snapshot()
    snapshot.source_disk = disk.self_link
    snapshot.name = snapshot_name
    snapshot_client = compute_v1.SnapshotsClient()
    snapshot_client.insert(project=project_id, snapshot_resource=snapshot)


def get_disk_size_from_disk(project_id, zone, volume_id):
    from google.cloud import compute_v1
    disk_client = compute_v1.DisksClient()
    disk = disk_client.get(project=project_id, zone=zone, disk=volume_id)
    return disk.size_gb


def check_if_snapshot_completed(project_id, snapshot_id):
    from google.cloud import compute_v1
    snapshot_client = compute_v1.SnapshotsClient()
    snapshot = snapshot_client.get(project=project_id, snapshot=snapshot_id)
    log("current status of snapshot is {}".format(snapshot.status))
    return snapshot.status == "READY"


def delete_snapshot(project_id, snapshot_id):
    from google.cloud import compute_v1
    snapshot_client = compute_v1.SnapshotsClient()
    operation = snapshot_client.delete(project=project_id, snapshot=snapshot_id)
    return operation


def get_snapshot_from_id(project_id, snapshot_id):
    from google.cloud import compute_v1
    snapshot_client = compute_v1.SnapshotsClient()
    snapshot = snapshot_client.get(project=project_id, snapshot=snapshot_id)
    return snapshot


def convert_snapshot_to_disk_volume(project_id, snapshot_id, volume_name, zone, disk_size_gb):
    from google.cloud import compute_v1
    disk_client = compute_v1.DisksClient()
    disk = compute_v1.Disk()
    disk.name = volume_name
    disk.size_gb = disk_size_gb
    disk.source_snapshot = get_snapshot_from_id(project_id, snapshot_id).self_link
    operation = disk_client.insert(project=project_id, zone=zone, disk_resource=disk)


def check_if_disk_creation_completed(project_id, zone, volume_name):
    from google.cloud import compute_v1
    disk_client = compute_v1.DisksClient()
    disk = disk_client.get(project=project_id, zone=zone, disk=volume_name)
    log("current status of disk is {}".format(disk.status))
    return disk.status == "READY"


def filter_on_tags(project_id, zone, instance_name, tags):
    instance = get_instance(project_id, zone, instance_name)
    instance_tags = instance.tags.items
    return any(tag in instance_tags for tag in tags)


def get_instances_with_disks_attached_less_than_given_limit(project_id, zone, tags, max_slots):
    instances = list_all_instances(project_id)
    instances = [instance for instance in instances[f"zones/{zone}"] if instance.status == "RUNNING"]
    filtered_on_tags = [instance for instance in instances if
                        filter_on_tags(project_id, zone, instance.name, tags)]
    filtered_on_disk_slots = [instance for instance in filtered_on_tags if len(instance.disks) < max_slots]
    return filtered_on_disk_slots


def get_instances_with_greater_than_given_disk_slots(project_id, zone, tags, min_slots):
    instances = list_all_instances(project_id)
    instances = [instance for instance in instances[f"zones/{zone}"] if instance.status == "RUNNING"]
    filtered_on_tags = [instance for instance in instances if
                        filter_on_tags(project_id, zone, instance.name, tags)]
    filtered_on_disk_slots = [instance for instance in filtered_on_tags if len(instance.disks) > min_slots]
    return filtered_on_disk_slots


def attach_given_disk_to_instance(project_id, zone, instance_name, disk_name):
    from google.cloud import compute_v1
    instance_client = compute_v1.InstancesClient()
    instance = get_instance(project_id, zone, instance_name)
    disk = compute_v1.AttachedDisk()
    disk.source = "zones/{}/disks/{}".format(zone, disk_name)
    disk.device_name = f"{instance_name}-{disk_name}"
    log(f"attaching disk {disk_name} to instance {instance_name}")
    disk.auto_delete = True
    disk.boot = False
    instance.disks.append(disk)
    operation = instance_client.update(project=project_id, zone=zone, instance=instance_name,
                                       instance_resource=instance)
    return operation


def detach_disk_from_instance(project_id, zone, instance_name, disk_name):
    from google.cloud import compute_v1
    instance_client = compute_v1.InstancesClient()
    instance = get_instance(project_id, zone, instance_name)
    instance.disks = [disk for disk in instance.disks if disk.source.split("/")[-1] != disk_name]
    operation = instance_client.update(project=project_id, zone=zone, instance=instance_name,
                                       instance_resource=instance)
    return operation


def update_tags_for_instance(project_id, zone, instance_name, tags):
    from google.cloud import compute_v1
    instance_client = compute_v1.InstancesClient()
    instance = get_instance(project_id, zone, instance_name)
    current_tags = instance.tags.items
    instance.tags.items = list(set(current_tags + tags))
    operation = instance_client.update(project=project_id, zone=zone, instance=instance_name,
                                       instance_resource=instance)
    return operation


def create_gcp_instance(name, project_id, zone, machine_type="e2-micro",
                        image="projects/debian-cloud/global/images/debian-11-bullseye-v20220920", tags="",
                        disk_size_gb=10):
    log("creating instance {}".format(name))
    from google.cloud import compute_v1
    instance_client = compute_v1.InstancesClient()
    instance = compute_v1.Instance()
    instance.name = name
    instance.machine_type = "zones/{}/machineTypes/{}".format(zone, machine_type)
    instance.disks = [
        compute_v1.AttachedDisk(
            auto_delete=True,
            boot=True,
            initialize_params=compute_v1.AttachedDiskInitializeParams(
                source_image=image,
                disk_size_gb=disk_size_gb,
            ),
        )
    ]
    instance.network_interfaces = [
        compute_v1.NetworkInterface(
            access_configs=[
                compute_v1.AccessConfig(
                    name="External NAT", type_=compute_v1.AccessConfig.Type.ONE_TO_ONE_NAT.name
                )
            ]
        )
    ]
    instance.tags = compute_v1.Tags(items=tags)
    operation = instance_client.insert(project=project_id, zone=zone, instance_resource=instance)
    wait_for_extended_operation(operation)
    return instance


def delete_gcp_instance(instance_name, project_id, zone):
    log("deleting instance {}".format(instance_name))
    from google.cloud import compute_v1
    instance_client = compute_v1.InstancesClient()
    operation = instance_client.delete(project=project_id, zone=zone, instance=instance_name)
    wait_for_extended_operation(operation)


def wait_for_extended_operation(
        operation, verbose_name: str = "operation", timeout: int = 300
) -> Any:
    """
    This method will wait for the extended (long-running) operation to
    complete. If the operation is successful, it will return its result.
    If the operation ends with an error, an exception will be raised.
    If there were any warnings during the execution of the operation
    they will be printed to sys.stderr.
    Args:
        operation: a long-running operation you want to wait on.
        verbose_name: (optional) a more verbose name of the operation,
            used only during error and warning reporting.
        timeout: how long (in seconds) to wait for operation to finish.
            If None, wait indefinitely.
    Returns:
        Whatever the operation.result() returns.
    Raises:
        This method will raise the exception received from `operation.exception()`
        or RuntimeError if there is no exception set, but there is an `error_code`
        set for the `operation`.
        In case of an operation taking longer than `timeout` seconds to complete,
        a `concurrent.futures.TimeoutError` will be raised.
    """
    result = operation.result(timeout=timeout)

    if operation.error_code:
        print(
            f"Error during {verbose_name}: [Code: {operation.error_code}]: {operation.error_message}",
            file=sys.stderr,
            flush=True,
        )
        print(f"Operation ID: {operation.name}", file=sys.stderr, flush=True)
        raise operation.exception() or RuntimeError(operation.error_message)

    if operation.warnings:
        print(f"Warnings during {verbose_name}:\n", file=sys.stderr, flush=True)
        for warning in operation.warnings:
            print(f" - {warning.code}: {warning.message}", file=sys.stderr, flush=True)

    return result


def delete_gcp_disk(project_id, zone, disk_name, wait=True):
    log("deleting disk {}".format(disk_name))
    from google.cloud import compute_v1
    disk_client = compute_v1.DisksClient()
    operation = disk_client.delete(project=project_id, zone=zone, disk=disk_name)
    if wait:
        wait_for_extended_operation(operation)


def delete_gcp_snapshot(snapshot_name, project_id, wait=True):
    log("deleting snapshot {}".format(snapshot_name))
    from google.cloud import compute_v1
    snapshot_client = compute_v1.SnapshotsClient()
    operation = snapshot_client.delete(project=project_id, snapshot=snapshot_name)
    if wait:
        wait_for_extended_operation(operation)


def is_disk_already_attached_to_given_instance(project_id, zone, instance_name, disk_name):
    instance = get_instance(project_id, zone, instance_name)
    for disk in instance.disks:
        if disk.source.split("/")[-1] == disk_name:
            return True
    return False


def delete_disk(project_id, zone, disk_name):
    log("deleting disk {}".format(disk_name))
    from google.cloud import compute_v1
    disk_client = compute_v1.DisksClient()
    operation = disk_client.delete(project=project_id, zone=zone, disk=disk_name)
    wait_for_extended_operation(operation)


def get_number_of_disks_for_instance(project_id, zone, instance_name):
    instance = get_instance(project_id, zone, instance_name)
    return len(instance.disks)


def get_root_volume_for_instance_id(project_id, zone, instance_name):
    log("getting root volume for instance {} with project id {} and zone {}".format(
        instance_name, project_id, zone))
    instance = get_instance(project_id, zone, instance_name)
    for disk in instance.disks:
        if disk.boot:
            return disk.source.split("/")[-1]
    raise Exception("no root volume found for instance {}".format(instance_name))


def list_all_disk_not_used_by(project_id, zone):
    from google.cloud import compute_v1
    disk_client = compute_v1.DisksClient()
    disks = disk_client.list(project=project_id, zone=zone)
    return [disk for disk in disks if disk.users == []]


def gcp_start_suspended_instances_with_tag(project_id, zone, tags, start_units=1):
    from google.cloud import compute_v1
    instance_client = compute_v1.InstancesClient()
    instances = instance_client.list(project=project_id, zone=zone)
    instances = [instance for instance in instances if
                 instance.status == "SUSPENDED" and any(tag in instance.tags.items for tag in tags)]
    instances = instances[:start_units]
    for instance in instances:
        log("starting instance {}".format(instance.name))
        operation = instance_client.resume(project=project_id, zone=zone, instance=instance.name)
        wait_till_instance_state(instance.name, "RUNNING", project_id, zone)


def gcp_suspend_running_instances_with_tag(project_id, zone, tags, stop_units=1):
    from google.cloud import compute_v1
    instance_client = compute_v1.InstancesClient()
    instances = instance_client.list(project=project_id, zone=zone)
    instances = [instance for instance in instances if
                 instance.status == "RUNNING" and any(tag in instance.tags.items for tag in tags)]
    instances = instances[:stop_units]
    for instance in instances:
        log("stopping instance {}".format(instance.name))
        operation = instance_client.suspend(project=project_id, zone=zone, instance=instance.name)
        wait_till_instance_state(instance.name, "SUSPENDED", project_id, zone)


def wait_till_instance_state(instance_name, state, project_id, zone):
    from google.cloud import compute_v1
    instance_client = compute_v1.InstancesClient()
    while True:
        instance = instance_client.get(project=project_id, zone=zone, instance=instance_name)
        if instance.status == state:
            break
        import time
        log("waiting for instance {} to be in state {}.sleeping for 5 sec".format(instance_name, state))
        time.sleep(5)
        log("checking if instance {} is in state {}".format(instance_name, state))
