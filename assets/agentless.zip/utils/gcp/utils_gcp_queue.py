# google pub sub util is a wrapper around google pub sub client

from logger.custom_logging import log


def send_message_to_topic(project_id, topic_name, message, timeout=15):
    """
    Pushes a message to a topic with a visibility timeout
    Args:
        project_id: project ID or project number of the Cloud project you want to use.
        topic_name: name of the topic you want to use.
        message: message to be pushed to the topic
        timeout: visibility timeout for the message
    Returns:
        None
    """
    from google.cloud import pubsub_v1
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_name)
    future = publisher.publish(topic_path, message.encode("utf-8"))
    log(f"Published {message} to {topic_path}")
    future.result(timeout=timeout)


def create_pubsub_topic(topic_name, project_id):
    """
    Creates a topic with the given name
    Args:
        topic_name: name of the topic you want to use.
        project_id: project ID or project number of the Cloud project you want to use.
    Returns:
        None
    """
    from google.cloud import pubsub_v1
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_name)
    publisher.create_topic(request={"name": topic_path})
    log(f"Created topic {topic_path}")


def create_pubsub_topic_if_not_exists(topic_name, project_id):
    """
    Creates a topic with the given name if it does not exist
    Args:
        topic_name: name of the topic you want to use.
        project_id: project ID or project number of the Cloud project you want to use.
    Returns:
        None
    """
    from google.cloud import pubsub_v1
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_name)
    try:
        publisher.get_topic(request={"topic": topic_path})
    except Exception:
        publisher.create_topic(request={"name": topic_path})
        log(f"Created topic {topic_path}")


def delete_pubsub_topic(topic_name, project_id):
    """
    Deletes a topic with the given name
    Args:
        topic_name: name of the topic you want to use.
        project_id: project ID or project number of the Cloud project you want to use.
    Returns:
        None
    """
    from google.cloud import pubsub_v1
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_name)
    publisher.delete_topic(request={"topic": topic_path})
    log(f"Deleted topic {topic_path}")


def create_subscription_if_not_exists(topic_name, project_id):
    """
    Creates a subscription with the given name if it does not exist
    Args:
        topic_name: name of the topic you want to use.
        project_id: project ID or project number of the Cloud project you want to use.
    Returns:
        None
    """
    from google.cloud import pubsub_v1
    subscriber = pubsub_v1.SubscriberClient()
    topic_path = subscriber.topic_path(project_id, topic_name)
    subscription_path = subscriber.subscription_path(project_id, topic_name)
    try:
        subscriber.get_subscription(request={"subscription": subscription_path})
    except Exception:
        subscriber.create_subscription(request={"topic": topic_path, "name": subscription_path})
        log(f"Created subscription {subscription_path}")


def check_if_event_is_available_in_pubsub_queue(topic_name, project_id, ackit=False):
    """
    Checks if an event is available in the pubsub queue
    Args:
        topic_name: name of the topic you want to use.
        project_id: project ID or project number of the Cloud project you want to use.
    Returns:
        True if an event is available, False otherwise
    """
    from google.cloud import pubsub_v1
    subscriber = pubsub_v1.SubscriberClient()
    subscription_path = subscriber.subscription_path(project_id, topic_name)
    response = subscriber.pull(
        request={"max_messages": 1, "subscription": subscription_path, "return_immediately": True})
    if ackit:
        ack_ids = [msg.ack_id for msg in response.received_messages]
        subscriber.acknowledge(request={"subscription": subscription_path, "ack_ids": ack_ids})
    return len(response.received_messages) > 0


def delete_subscription(topic_name, project_id):
    """
    Deletes a subscription with the given name
    Args:
        topic_name: name of the topic you want to use.
        project_id: project ID or project number of the Cloud project you want to use.
    Returns:
        None
    """
    from google.cloud import pubsub_v1
    subscriber = pubsub_v1.SubscriberClient()
    subscription_path = subscriber.subscription_path(project_id, topic_name)
    subscriber.delete_subscription(request={"subscription": subscription_path})
    log(f"Deleted subscription {subscription_path}")


def fetch_single_message_from_pubsub_queue(topic_name, project_id, ackit=True):
    """
    Fetches a single message from the pubsub queue
    Args:
        topic_name: name of the topic you want to use.
        project_id: project ID or project number of the Cloud project you want to use.
    Returns:
        The message if one is available, None otherwise
    """
    from google.cloud import pubsub_v1
    subscriber = pubsub_v1.SubscriberClient()
    subscription_path = subscriber.subscription_path(project_id, topic_name)
    response = subscriber.pull(request={"max_messages": 1, "subscription": subscription_path})
    if len(response.received_messages) > 0:
        if ackit:
            ack_ids = [msg.ack_id for msg in response.received_messages]
            subscriber.acknowledge(request={"subscription": subscription_path, "ack_ids": ack_ids})
        return response.received_messages[0].message.data.decode("utf-8")


def get_number_of_messages_in_pubsub_queue(topic_name, project_id):
    """
    Returns the number of messages in the pubsub queue
    Args:
        topic_name: name of the topic you want to use.
        project_id: project ID or project number of the Cloud project you want to use.
    Returns:
        The number of messages in the pubsub queue
    """
    from google.cloud import pubsub_v1
    subscriber = pubsub_v1.SubscriberClient()
    subscription_path = subscriber.subscription_path(project_id, topic_name)
    response = subscriber.pull(request={"max_messages": 1, "subscription": subscription_path})
    return len(response.received_messages)


def purge_pubsub_queue(topic_name, project_id):
    """
    Purges the pubsub queue
    Args:
        topic_name: name of the topic you want to use.
        project_id: project ID or project number of the Cloud project you want to use.
    Returns:
        None
    """
    from google.cloud import pubsub_v1
    subscriber = pubsub_v1.SubscriberClient()
    subscription_path = subscriber.subscription_path(project_id, topic_name)
