import time

from funcy import merge
from retry import retry

from logger.custom_logging import log
from utils import less_than, greater_than
from utils.aws.utils_network import get_default_security_group_for_vpc, aws_get_default_vpc


def get_all_possible_combinations_of_device_names():
    """get all possible combinations of device names"""
    device_names = []
    """
    https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/device_naming.html
    recommended device names are /dev/sd[f-p]
    """
    for index in range(100, 123):
        device_names.append("/dev/sd{}".format(chr(index)))
    return sorted(device_names)


def get_available_device_names(current_occupied_device_names):
    """get available device names"""
    device_names = get_all_possible_combinations_of_device_names()
    for device_name in current_occupied_device_names:
        if device_name in device_names or any(device_name in s for s in device_names):
            device_names.remove(device_name)
    return device_names


def aws_get_instance_state_by_instance_id(account_id, region, instance_id):
    """get instance state by instance id"""
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    instance = ec2.describe_instances(InstanceIds=[instance_id])
    return instance["Reservations"][0]["Instances"][0]["State"]["Name"]


def aws_validate_instance(account_id, region, instance_name, volume_name):
    """validate the instance and volume name"""

    return aws_get_instance_state_by_instance_id(account_id, region, instance_name) == 'running' and (
            aws_get_volume_id_of_disk_attached(account_id, region, instance_name) == volume_name)


def aws_take_snapshot(account_id, region, volume_name, snapshot_name):
    """take snapshot of the volume"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    log("creating snapshot for volume: {}".format(volume_name))
    response = ec2.create_snapshot(VolumeId=volume_name, Description=snapshot_name,
                                   TagSpecifications=[{
                                       'ResourceType': 'snapshot',
                                       'Tags': [{
                                           'Key': 'CreatedBy',
                                           'Value': 'UptycsAgentlessPipeline'
                                       }]
                                   }])
    return {"snapshot_id": response.snapshot_id, "volume_id": response.volume_id,
            "disk_size": response.volume_size}


def aws_check_if_snapshot_completed(account_id, region, snapshot_name):
    """check if snapshot is completed"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    snapshot = ec2.Snapshot(snapshot_name)
    if snapshot.state == "completed":
        return True
    return False


def aws_kms_key_id_for_snapshot_id(account_id, region, snapshot_id):
    """get kms key id for snapshot"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    snapshot = ec2.Snapshot(snapshot_id)
    return snapshot.kms_key_id


def aws_convert_snapshot_to_disk_volume(account_id, region, snapshot_name, disk_name, availability_zone,
                                        volume_type="gp2"):
    """convert snapshot to disk volume"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    kms_id = aws_kms_key_id_for_snapshot_id(account_id, region, snapshot_name)
    log("creating volume from snapshot: {} with kms key id {}".format(snapshot_name, kms_id))
    params = {"SnapshotId": snapshot_name, "VolumeType": volume_type, "AvailabilityZone": availability_zone,
              "TagSpecifications": [{
                  'ResourceType': 'volume',
                  'Tags': [{
                      'Key': 'CreatedBy',
                      'Value': 'UptycsAgentlessPipeline'
                  }]
              }]}
    if kms_id:
        params = merge(params, {"KmsKeyId": kms_id, "Encrypted": True})
    response = ec2.create_volume(**params)
    return {"volume_id": response.volume_id, "disk_size": response.size}


def aws_check_if_disk_creation_completed(account_id, region, volume_name):
    """check if disk creation is completed"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    volume = ec2.Volume(volume_name)
    if volume.state == "available":
        return True
    return False


def aws_get_device_names_mounted_on_instance(account_id, region, instance_name):
    """get device names mounted on instance"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    instance = ec2.Instance(instance_name)
    device_names = []
    for device in instance.block_device_mappings:
        device_names.append(device["DeviceName"])
    return device_names


def get_first_unfilled_device_name(account_id, region, instance_id):
    """get first unfilled device name"""
    device_names = aws_get_device_names_mounted_on_instance(account_id, region, instance_id)
    names = get_available_device_names(device_names)
    return names[0]


def aws_attach_given_disk_to_instance(account_id, region, instance_name, volume_name, device_location="/dev/sdf"):
    """attach disk to instance"""
    log("attaching disk: {} to instance: {}".format(volume_name, instance_name))
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    response = ec2.attach_volume(InstanceId=instance_name, VolumeId=volume_name, Device=device_location)
    return {"volume_id": response["VolumeId"], "instance_id": response["InstanceId"]}


@retry(tries=3, delay=2)
def aws_attach_disk_to_instance(account_id, region, instance_name, volume_name):
    """attach disk to instance"""
    device_name = get_first_unfilled_device_name(account_id, region, instance_name)
    aws_attach_given_disk_to_instance(account_id, region, instance_name, volume_name, device_name)


def aws_check_if_disk_attached_to_instance(account_id, region, volume_name, instance_name):
    """check if disk is attached to instance"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    volume = ec2.Volume(volume_name)
    instance = ec2.Instance(instance_name)
    for device in instance.block_device_mappings:
        if device["Ebs"]["VolumeId"] == volume.id:
            return True
    return False


def aws_detach_disk_from_instance(account_id, region, volume_name, instance_name, device_location=None):
    """detach disk from instance"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    volume = ec2.Volume(volume_name)
    instance = ec2.Instance(instance_name)
    device_name = device_location or get_device_location_of_given_volume_id(account_id, region,
                                                                            instance_name, volume_name)
    if device_name:
        log("detaching disk: {} from instance: {}".format(volume_name, instance_name))
        response = volume.detach_from_instance(InstanceId=instance.id, Device=device_name)
        return {"volume_id": response["VolumeId"], "instance_id": response["InstanceId"]}
    else:
        log("disk: {} is not attached to instance: {}".format(volume_name, instance_name))
        return None


def aws_check_if_disk_detached_from_instance(account_id, region, volume_name, instance_name):
    """check if disk is detached from instance"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    volume = ec2.Volume(volume_name)
    instance = ec2.Instance(instance_name)
    for device in instance.block_device_mappings:
        if device["Ebs"]["VolumeId"] == volume.id:
            return False
    return True


def aws_delete_disk(account_id, region, volume_name):
    """delete disk"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    volume = ec2.Volume(volume_name)
    volume.delete()


def aws_check_if_disk_deleted(account_id, region, volume):
    """check if disk is deleted"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    try:
        volume = ec2.Volume(volume)
        return False
    except:
        return True


def aws_delete_snapshot(account_id, region, snapshot_name):
    """delete snapshot"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    snapshot = ec2.Snapshot(snapshot_name)
    response = snapshot.delete()


def aws_check_if_snapshot_deleted(account_id, region, snapshot_name):
    """check if snapshot is deleted"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    try:
        snapshot = ec2.Snapshot(snapshot_name)
        return False
    except:
        return True


def aws_validate_disk(account_id, region, volume_name):
    """validate disk"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    volume = ec2.Volume(volume_name)
    if volume.state == "available":
        return True
    return False


def aws_validate_disk_attached_to_instance(account_id, region, volume_name, instance_name):
    """validate disk attached to instance"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    volume = ec2.Volume(volume_name)
    instance = ec2.Instance(instance_name)
    for device in instance.block_device_mappings:
        if device["Ebs"]["VolumeId"] == volume.id:
            return True
    return False


def get_instances_with_tags(account_id, region, tags, tag_key="type"):
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    # filter on tag and zone
    instances = ec2.instances.filter(Filters=[{'Name': f'tag:{tag_key}', 'Values': tags}, ])
    return instances


def get_number_of_disks_attached_to_instance(account_id, region, instance_id):
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    instance = ec2.Instance(instance_id)
    return len(instance.block_device_mappings)


def aws_get_instances_with_disk_attached_filter(account_id, region, tags, max_slots, filter_clause=less_than,
                                                zone=None, state="running"):
    instances = get_instances_with_tags(account_id, region, tags)
    instances_with_disks_attached_less_than_given_limit = []
    for instance in instances:
        if zone and instance.placement["AvailabilityZone"] == zone and filter_clause(
                get_number_of_disks_attached_to_instance(
                    account_id, region, instance.id), max_slots) and instance.state["Name"] == state:
            instances_with_disks_attached_less_than_given_limit.append(instance)
    return instances_with_disks_attached_less_than_given_limit


def aws_get_instances_with_disks_attached_less_than_given_limit(account_id, region, tags, max_slots, zone=None):
    return aws_get_instances_with_disk_attached_filter(account_id, region, tags, max_slots, less_than, zone)


def aws_get_instances_with_disks_attached_more_than_given_limit(account_id, region, tags, max_slots, zone=None):
    return aws_get_instances_with_disk_attached_filter(account_id, region, tags, max_slots, greater_than, zone)


def aws_create_instance(account_id, region, image_id, instance_type, key_name, security_group_ids, subnet_id,
                        tag_key="type",
                        tag_value="scanner"):
    """create instance"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    response = ec2.create_instances(ImageId=image_id, InstanceType=instance_type, KeyName=key_name,
                                    SecurityGroupIds=security_group_ids, SubnetId=subnet_id, MinCount=1, MaxCount=1)
    instance = ec2.Instance(response[0].id)
    instance.create_tags(Tags=[{"Key": tag_key, "Value": tag_value}])
    instance.wait_until_running()
    return {"instance_id": instance.id}


def add_tags_to_given_instance(account_id, region, instance_id, tag_key, tag_value):
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    instance = ec2.Instance(instance_id)
    instance.create_tags(Tags=[{"Key": tag_key, "Value": tag_value}])


def remove_tags_from_given_instance(account_id, region, instance_id, tag_key):
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    instance = ec2.Instance(instance_id)
    instance.delete_tags(Tags=[{"Key": tag_key}])


def wait_till_instance_tag_is_assigned(account_id, region, instance_id, tag_key):
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    instance = ec2.Instance(instance_id)
    while True:
        for tag in instance.tags:
            if tag["Key"] == tag_key:
                return True
        log("waiting for tag to be assigned to instance")
        time.sleep(1)
        instance.reload()


def aws_create_instance_for_default_network(account_id, region, image_id, instance_type, key_name, tag_key="type",
                                            tag_value="scanner"):
    """create instance"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    response = ec2.create_instances(ImageId=image_id, InstanceType=instance_type, KeyName=key_name,
                                    SecurityGroupIds=[get_default_security_group_for_vpc(account_id, region,
                                                                                         aws_get_default_vpc(account_id,
                                                                                                             region))],
                                    MinCount=1, MaxCount=1)
    instance = ec2.Instance(response[0].id)
    instance.create_tags(Tags=[{"Key": tag_key, "Value": tag_value}])
    instance.wait_until_running()
    return {"instance_id": instance.id}


def aws_delete_instance_for_instance_id(account_id, region, instance_id):
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    instance = ec2.Instance(instance_id)
    instance.terminate()


def aws_get_volume_id_of_disk_attached(account_id, region, instance_id):
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    instance = ec2.describe_instances(InstanceIds=[instance_id])
    return instance["Reservations"][0]["Instances"][0]["BlockDeviceMappings"][0]["Ebs"]["VolumeId"]


def get_device_location_of_given_volume_id(account_id, region, instance_id, volume_id):
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    instance = ec2.describe_instances(InstanceIds=[instance_id])
    for device in instance["Reservations"][0]["Instances"][0]["BlockDeviceMappings"]:
        if device["Ebs"]["VolumeId"] == volume_id:
            return device["DeviceName"]


def in_aws_is_disk_already_attached_to_given_instance(account_id, region, instance_id, volume_id):
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    instance = ec2.describe_instances(InstanceIds=[instance_id])
    for device in instance["Reservations"][0]["Instances"][0]["BlockDeviceMappings"]:
        if device["Ebs"]["VolumeId"] == volume_id:
            return True
    return False


def get_zone_of_scanner_instance(account_id, region):
    """there is a assumption that all instances will be in same zone"""
    instances = get_instances_with_tags(account_id, region, ["scanner"])
    for instance in instances:
        return instance.placement["AvailabilityZone"]


def wait_till_volume_is_dettached(account_id, region, volume_id):
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    volume = ec2.Volume(volume_id)
    while volume.state != "available":
        log("waiting for volume to be available. sleeping for 5 seconds")
        time.sleep(5)
        volume.reload()


def get_snapshot_id_from_volume_id(account_id, region, volume_id):
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    response = ec2.describe_volumes(VolumeIds=[volume_id])
    return response["Volumes"][0]["SnapshotId"]


def aws_stop_the_instance(account_id, region, instance_id):
    log("stopping the instance. instance id: {}".format(instance_id))
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    ec2.stop_instances(InstanceIds=[instance_id])


def aws_start_the_instance(account_id, region, instance_id):
    log("starting the instance. instance id: {}".format(instance_id))
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    ec2.start_instances(InstanceIds=[instance_id])


def get_aws_instance_with_tags_and_given_state(account_id, region, tag_value, state):
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    instances = ec2.instances.filter(Filters=[{'Name': 'tag:' + 'type', 'Values': [tag_value]},
                                              {'Name': 'instance-state-name', 'Values': [state]}])
    instance_ids = [instance.instance_id for instance in instances]
    return instance_ids


def aws_get_all_volume_ids_attached_to_instance_id(account_id, region, instance_id):
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    instance = ec2.describe_instances(InstanceIds=[instance_id])
    volume_ids = []
    for device in instance["Reservations"][0]["Instances"][0]["BlockDeviceMappings"]:
        volume_ids.append(device["Ebs"]["VolumeId"])
    return volume_ids


def get_root_volume_id_of_instance(account_id, region, instance_id):
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    instance = ec2.describe_instances(InstanceIds=[instance_id])
    root_device_name = instance["Reservations"][0]["Instances"][0]["RootDeviceName"]
    for device in instance["Reservations"][0]["Instances"][0]["BlockDeviceMappings"]:
        if device["DeviceName"] == root_device_name:
            return device["Ebs"]["VolumeId"]


def aws_get_all_snapshots_ids_with_given_tag(account_id, region, tag_key, tag_value):
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    response = ec2.describe_snapshots(Filters=[{'Name': 'tag:' + tag_key, 'Values': [tag_value]}])
    snapshot_ids = []
    for snapshot in response["Snapshots"]:
        snapshot_ids.append(snapshot["SnapshotId"])
    return snapshot_ids


def aws_get_all_volume_ids_with_given_tag(account_id, region, tag_key, tag_value):
    import boto3
    ec2 = boto3.client('ec2', region_name=region)
    response = ec2.describe_volumes(Filters=[{'Name': 'tag:' + tag_key, 'Values': [tag_value]}])
    volume_ids = []
    for volume in response["Volumes"]:
        volume_ids.append(volume["VolumeId"])
    return volume_ids
