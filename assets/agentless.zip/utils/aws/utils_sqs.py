import json
import os
import threading
import time
import traceback

from config.config_manager import get_config
from logger.custom_logging import log


# Get the queue. This returns an SQS.Queue instance
def list_all_queues(region_name):
    import boto3
    sqs = boto3.resource('sqs', region_name=region_name, endpoint_url=get_config("AWS_SQS_ENDPOINT", None))
    [queue for queue in sqs.queues.all()]


def send_message_to_sqs(account_id, region_name, message, queue_name,
                        delay_seconds=int(os.getenv("SQS_DELAYED_SECONDS", "60")), debug=False):
    log(f"sending {message}")
    import boto3
    sqs = boto3.resource('sqs', region_name=region_name, endpoint_url=get_config("AWS_SQS_ENDPOINT", None))
    queue = sqs.get_queue_by_name(QueueName=queue_name)
    assert isinstance(message, str)
    response = queue.send_message_to_service_bus(
        DelaySeconds=delay_seconds,
        MessageBody=message
    )


def async_send_message(message, queue_name):
    thread = threading.Thread(target=send_message_to_sqs, args=(message, queue_name))
    thread.start()


def receive_messages(processor_function, queue_name, delete=True):
    import boto3
    sqs = boto3.resource('sqs', endpoint_url=get_config("AWS_SQS_ENDPOINT", None))
    queue = sqs.get_queue_by_name(QueueName=queue_name)
    for message in queue.receive_messages():
        try:
            processor_function(message.body)
            if (delete):
                message.delete()
        except Exception as e:
            traceback.print_exc()
            log(f"message not processed hence not deleting")


def receive_message(account_id, region, queue_name, delete=True, wait_time=20):
    import boto3
    sqs = boto3.resource('sqs', region_name=region)
    queue = sqs.get_queue_by_name(QueueName=queue_name)
    for message in queue.receive_messages(WaitTimeSeconds=wait_time):
        try:
            if delete:
                message.delete()
            return message

        except Exception as e:
            traceback.print_exc()
            log(f"message not processed hence not deleting")


def process_batch_messages(processor_function, queue_name, batch=10, args={}, delete=True):
    import boto3
    sqs = boto3.resource('sqs', endpoint_url=get_config("AWS_SQS_ENDPOINT", None))
    queue = sqs.get_queue_by_name(QueueName=queue_name)
    retry = 0
    batch_count = 0
    batch_messages = []
    while (True):
        for message in queue.receive_messages():
            if batch_count == batch:
                break
            batch_messages.append(message)
            batch_count += 1
            retry = 0
        retry += 1
        if batch_count == batch or retry == 10:
            break
    try:
        log(f'processing messages: {batch_count}')
        processor_function([message.body for message in batch_messages],
                           **args)
        if (delete):
            [message.delete() for message in batch_messages]
    except Exception as e:
        traceback.print_exc()
        log(f"message not processed hence not deleting")


def revive_messages(queue_name, new_queue_name, upgrade_message=lambda x: x, check_for_older_messages=lambda x: False):
    import boto3
    sqs = boto3.resource('sqs', endpoint_url=get_config("AWS_SQS_ENDPOINT", None))
    queue = sqs.get_queue_by_name(QueueName=queue_name)
    while (True):
        for message in queue.receive_messages():
            send_message_to_sqs(upgrade_message(message.body), new_queue_name)
            message.delete()


def upgrade_message_to_v1(message_body):
    message = json.loads(message_body)
    message.update({"version": "v1"})
    return json.dumps(message)


def check_for_older_message_for_v1(json_message):
    return "version" not in json_message or json_message["version"] != "v1"


def sqs_v1_reviver(queue_name, new_queue_name):
    try:
        revive_messages(queue_name, new_queue_name, upgrade_message=upgrade_message_to_v1,
                        check_for_older_messages=check_for_older_message_for_v1)
    except:
        traceback.print_exc()


def multithread_receiver(queue_name, new_queue_name, threads=100):
    mthreads = []
    for thread_num in range(threads):
        thread = threading.Thread(target=sqs_v1_reviver, args=(queue_name, new_queue_name))
        thread.start()
        mthreads.append(thread)
    log(len(mthreads))
    for mthread in mthreads:
        mthread.join()


def aws_create_sqs_queue(account_id, region, queue_name):
    import boto3
    client = boto3.client('sqs', region_name=region)
    response = client.create_queue(
        QueueName=queue_name,
        Attributes={
            'DelaySeconds': '0',
            'MessageRetentionPeriod': '86400'
        }
    )
    return response


def aws_delete_sqs_queue(account_id, region, queue_name):
    import boto3
    client = boto3.client('sqs', region_name=region)
    response = client.delete_queue(
        QueueUrl=f'https://sqs.{region}.amazonaws.com/{account_id}/{queue_name}'
    )
    return response


def wait_till_message_is_received(account_id, region, queue_name, wait_time=180):
    start_time = time.time()
    while True:
        try:
            message = receive_message(account_id, region, queue_name, wait_time=20)
            return message.body
        except:
            traceback.print_exc()
            time.sleep(10)
            if time.time() - start_time > wait_time:
                return None


def get_number_of_messages_in_sqs_queue(account_id, region, sqs_queue_name):
    import boto3
    sqs = boto3.resource('sqs', region_name=region)
    queue = sqs.get_queue_by_name(QueueName=sqs_queue_name)
    num_messages = queue.attributes['ApproximateNumberOfMessages']
    num_in_flight_msgs = queue.attributes['ApproximateNumberOfMessagesNotVisible']
    return int(num_messages) + int(num_in_flight_msgs)
