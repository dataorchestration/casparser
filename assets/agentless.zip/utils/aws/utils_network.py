def aws_get_default_vpc(account_id, region):
    """get default vpc"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    vpcs = ec2.vpcs.filter(
        Filters=[{'Name': 'isDefault', 'Values': ['true']}])
    for vpc in vpcs:
        return vpc.id
    return None


def get_default_subnet(account_id, region, vpc):
    """get default subnet"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    subnets = ec2.subnets.filter(
        Filters=[{'Name': 'vpc-id', 'Values': [vpc]}])
    for subnet in subnets:
        return subnet.id
    return None


def get_default_security_group_for_vpc(account_id, region, vpc):
    """get default security group for vpc"""
    import boto3
    ec2 = boto3.resource('ec2', region_name=region)
    security_groups = ec2.security_groups.filter(
        Filters=[{'Name': 'vpc-id', 'Values': [vpc]}])
    for security_group in security_groups:
        return security_group.id
    return None
