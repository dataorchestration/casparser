def list_all_computes(**kwargs):
    """list all computes from cloud provider"""
    raise NotImplementedError()


def list_all_volumes(**kwargs):
    """get all volumes"""
    raise NotImplementedError()


def get_volumes_for_instance_id(**kwargs):
    """get all volumes of one instance id"""
    raise NotImplementedError()

def create_snapshot_for_the_volume(**kwargs):
    """create snapshot for the volume"""
    raise NotImplementedError()