def less_than(left_value, right_value):
    return left_value < right_value


def greater_than(left_value, right_value):
    return left_value > right_value
