import json
import os
import time
import traceback
import unittest

from logger.custom_logging import log
from triggers.trigger_monitoring_lambda import TriggerMonitoring
from utils.gcp.utils_gcp_compute import create_gcp_instance, delete_gcp_instance, get_instances_with_given_tag, \
    attach_given_disk_to_instance, get_all_instances_with_given_state
from utils.gcp.utils_gcp_queue import send_message_to_topic, purge_pubsub_queue


class TestGCPScaling(unittest.TestCase):
    NUMBER_OF_INSTANCES = 3
    PROJECT_ID = "electionscraping"
    ZONE = "asia-south1-a"
    # this disk is already present
    volume_id_1 = "disk-snapshotting-c-region"
    volume_id_2 = "postgres-disk"

    os.environ["MAX_SLOTS"] = "2"

    def setUp(self) -> None:
        # spawn 3 gcp instances
        for i in range(self.NUMBER_OF_INSTANCES):
            create_gcp_instance(name="test-instance-%s" % i, machine_type="n1-standard-1", project_id=self.PROJECT_ID,
                                zone=self.ZONE,
                                tags=["scanners"])

    def tearDown(self) -> None:
        for i in range(self.NUMBER_OF_INSTANCES):
            delete_gcp_instance(instance_name="test-instance-%s" % i, project_id=self.PROJECT_ID, zone=self.ZONE)

    def test_scaling(self):
        try:
            cloud_event = {
                "data": {
                    "project_name": "test",
                }
            }
            # list number of instances running
            original_number_of_instances = len(
                get_all_instances_with_given_state(project_id=self.PROJECT_ID, zone=self.ZONE,
                                                   tags=["scanners"], state="RUNNING"))
            log("number of instances running: %s" % original_number_of_instances)
            # this should bring down the number of instances to 2
            TriggerMonitoring().entry_point(cloud_event, cloud_type="gcp")
            time.sleep(10)
            self.assertEqual(len(
                get_all_instances_with_given_state(project_id=self.PROJECT_ID, zone=self.ZONE,
                                                   tags=["scanners"], state="RUNNING")),
                original_number_of_instances - 1)
            TriggerMonitoring().entry_point(cloud_event, cloud_type="gcp")
            time.sleep(10)
            self.assertEqual(len(
                get_all_instances_with_given_state(project_id=self.PROJECT_ID, zone=self.ZONE,
                                                   tags=["scanners"], state="RUNNING")),
                original_number_of_instances - 2)
            TriggerMonitoring().entry_point(cloud_event, cloud_type="gcp")
            time.sleep(10)
            self.assertEqual(len(
                get_all_instances_with_given_state(project_id=self.PROJECT_ID, zone=self.ZONE,
                                                   tags=["scanners"], state="RUNNING")),
                original_number_of_instances - 3)
            # instance_id = get_instances_with_given_tag(project_id=self.PROJECT_ID, zone=self.ZONE, tag="scanners")[0].id
            # attach_given_disk_to_instance(project_id=self.PROJECT_ID, zone=self.ZONE, instance_name=instance_id,
            #                               disk_name=self.volume_id_1)
            send_message_to_topic(project_id=self.PROJECT_ID, topic_name="VOLUME_ATTACHMENT_TRIGGER_QUEUE",
                                  message=json.dumps({
                                      "disk_id": self.volume_id_1}))

            log("waiting for 10 seconds fo disk to attach")
            time.sleep(10)
            TriggerMonitoring().entry_point(cloud_event, cloud_type="gcp")
            time.sleep(10)
            self.assertEqual(len(get_all_instances_with_given_state(project_id=self.PROJECT_ID, zone=self.ZONE,
                                                                    tags=["scanners"], state="RUNNING")), 1)
            instance_name = \
                get_all_instances_with_given_state(project_id=self.PROJECT_ID, zone=self.ZONE, tags=["scanners"],
                                                   state="RUNNING")[0].name
            attach_given_disk_to_instance(project_id=self.PROJECT_ID, zone=self.ZONE, instance_name=instance_name,
                                          disk_name=self.volume_id_1)
            TriggerMonitoring().entry_point(cloud_event, cloud_type="gcp")
            time.sleep(10)
            self.assertEqual(len(get_all_instances_with_given_state(project_id=self.PROJECT_ID, zone=self.ZONE,
                                                                    tags=["scanners"], state="RUNNING")), 2)
        except:
            traceback.print_exc()
            self.fail()


if __name__ == '__main__':
    os.environ["MAX_SLOTS"] = "2"
    os.environ["MIN_INSTANCES"] = "0"
    os.environ["MAX_INSTANCES"] = "3"
    os.environ["ZONE"] = "asia-south1-a"
    unittest.main()
