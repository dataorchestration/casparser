import base64
import json
import os
import time
import traceback
import unittest
import warnings
from datetime import datetime

import mock

from handlers.failure.RaiseExceptionHandler import QueuePushBackException
from logger.custom_logging import log
from triggers.trigger_disk_creation_for_snapshot_ready import TriggerDiskCreationOnSnapshotComplete
from triggers.trigger_disk_snapshotting_for_incoming_compute import TriggerDiskSnapshottingForIncomingCompute
from triggers.trigger_volume_attachment import TriggerVolumeAttachment
from triggers.trigger_volume_dettachment import TriggerVolumeDettachment
from utils.gcp.utils_gcp_compute import create_gcp_instance, delete_gcp_instance, delete_gcp_snapshot, \
    get_number_of_disks_for_instance
from utils.gcp.utils_gcp_queue import delete_pubsub_topic, \
    check_if_event_is_available_in_pubsub_queue, fetch_single_message_from_pubsub_queue, \
    create_subscription_if_not_exists, delete_subscription, create_pubsub_topic_if_not_exists

warnings.filterwarnings('ignore')


class TestConsumers(unittest.TestCase):
    PROJECT_ID = "electionscraping"
    ZONE = "asia-south1-c"

    def setUp(self) -> None:
        log("setup")
        self.snapshot_taking_instance = "snapshot-taking-instance"
        self.scanning_taking_instance = "scanning-taking-instance"
        create_gcp_instance(name=("%s" % self.snapshot_taking_instance), project_id=self.PROJECT_ID, zone=self.ZONE)
        create_gcp_instance(name=self.scanning_taking_instance, project_id=self.PROJECT_ID, zone=self.ZONE,
                            tags=["scanners"])
        create_pubsub_topic_if_not_exists(topic_name="snapshot_waiting", project_id=self.PROJECT_ID)
        create_subscription_if_not_exists(topic_name="snapshot_waiting", project_id=self.PROJECT_ID)
        create_pubsub_topic_if_not_exists(topic_name="attachment_completed", project_id=self.PROJECT_ID)
        create_subscription_if_not_exists(topic_name="attachment_completed", project_id=self.PROJECT_ID)
        create_pubsub_topic_if_not_exists(topic_name="disk_creation_waiting", project_id=self.PROJECT_ID)
        create_subscription_if_not_exists(topic_name="disk_creation_waiting", project_id=self.PROJECT_ID)

    def tearDown(self) -> None:
        log("delete the instance")
        delete_gcp_instance(self.snapshot_taking_instance, project_id=self.PROJECT_ID, zone=self.ZONE)
        delete_gcp_instance("%s" % self.scanning_taking_instance, project_id=self.PROJECT_ID, zone=self.ZONE)
        delete_pubsub_topic(topic_name="snapshot_waiting", project_id=self.PROJECT_ID)
        delete_subscription(topic_name="snapshot_waiting", project_id=self.PROJECT_ID)
        delete_pubsub_topic(topic_name="attachment_completed", project_id=self.PROJECT_ID)
        delete_subscription(topic_name="attachment_completed", project_id=self.PROJECT_ID)
        delete_pubsub_topic(topic_name="disk_creation_waiting", project_id=self.PROJECT_ID)
        delete_subscription(topic_name="disk_creation_waiting", project_id=self.PROJECT_ID)

    def get_cloud_event_for_given_payload(self, payload, project_name="test"):
        """

        :param payload:
        :param project_name:
        :return:
        {
          'attributes': {
            'specversion': '1.0',
            'id': '6161074933123473',
            'source': '//pubsub.googleapis.com/projects/electionscraping/topics/dataorc-test-function-volume-scanning-trigger-topic',
            'type': 'google.cloud.pubsub.topic.v1.messagePublished',
            'datacontenttype': 'application/json',
            'time': '2022-11-06T09:45:55.603Z'
          },
          'data': {
            'message': {
              'data': 'eyJ2b2x1bWVfaWQiOiJzbmFwc2hvdF90YWtpbmdfaW5zdGFuY2UiLCJpbnN0YW5jZV9pZCI6InNuYXBzaG90X3Rha2luZ19pbnN0YW5jZSJ9',
              'messageId': '6161074933123473',
              'message_id': '6161074933123473',
              'publishTime': '2022-11-06T09:45:55.603Z',
              'publish_time': '2022-11-06T09:45:55.603Z'
            },
            'subscription': 'projects/electionscraping/subscriptions/eventarc-asia-southeast1-function-volume-scanning-trigger-427495-sub-628'
          }
        }
        """
        mock_event = mock.MagicMock()

        json_cloud_event = {
            "attributes": {
                "source": "projects/{}/topics/{}".format(project_name, "test")
            },

            "data": {
                "message": {
                    "data": base64.b64encode(json.dumps(payload, separators=(',', ':')).encode("utf-8")).decode("utf-8")
                }
            }
        }
        mock_event.__getitem__.side_effect = json_cloud_event.__getitem__
        mock_event['attributes'] = json_cloud_event['attributes']
        mock_event.data = json_cloud_event["data"]
        return mock_event

    def wait_while_there_is_a_event_in_queue(self, queue_name, project_id, default_sleep_time=4):
        while not check_if_event_is_available_in_pubsub_queue(queue_name, project_id):
            log(f"Waiting for event to be available in queue {queue_name}")
            time.sleep(default_sleep_time)

    def wait_till_no_exception(self, function, default_sleep_time=4):
        while True:
            try:
                function(None)
                break
            except QueuePushBackException:
                log(traceback.format_exc())
                time.sleep(default_sleep_time)

    def test_end_to_end(self):
        try:
            os.environ["PROJECT_ID"] = self.PROJECT_ID
            os.environ["ZONE"] = self.ZONE

            log("snapshot creation in progress")
            os.environ["OUTPUT_TOPIC"] = "snapshot_waiting"
            self.wait_till_no_exception(lambda x: TriggerDiskSnapshottingForIncomingCompute().entry_point(
                self.get_cloud_event_for_given_payload(
                    {"volume_name": self.snapshot_taking_instance, "instance_name": self.snapshot_taking_instance,
                     "dest_snapshot_name": f"snapshot-{datetime.now().strftime('%Y%m%d%H%M%S')}",
                     "dest_volume_name": f"volume-{datetime.now().strftime('%Y%m%d%H%M%S')}"})
            ))
            self.wait_while_there_is_a_event_in_queue("snapshot_waiting", self.PROJECT_ID)
            message_from_queue = json.loads(fetch_single_message_from_pubsub_queue("snapshot_waiting", self.PROJECT_ID))

            log(f"snapshot message in progress {message_from_queue}")
            # self.assertEqual(message_from_queue["volume_name"], "%s" % self.snapshot_taking_instance)
            snapshot_name = message_from_queue["snapshot_name"]
            log("disk creation trigger")
            os.environ["OUTPUT_TOPIC"] = "disk_creation_waiting"
            self.wait_till_no_exception(lambda x: TriggerDiskCreationOnSnapshotComplete().entry_point(
                self.get_cloud_event_for_given_payload(message_from_queue)))
            self.wait_while_there_is_a_event_in_queue("disk_creation_waiting", self.PROJECT_ID)
            message_from_queue = json.loads(
                fetch_single_message_from_pubsub_queue("disk_creation_waiting", self.PROJECT_ID))
            log(message_from_queue)

            log("disk attachment in progress")
            os.environ["OUTPUT_TOPIC"] = "attachment_completed"
            os.environ["TAGS"] = 'scanners'
            os.environ["MAX_SLOTS"] = "18"
            self.wait_till_no_exception(lambda x: TriggerVolumeAttachment().entry_point(
                self.get_cloud_event_for_given_payload(message_from_queue)))

            message_from_queue = json.loads(
                fetch_single_message_from_pubsub_queue("attachment_completed", self.PROJECT_ID))
            log(message_from_queue)
            self.assertTrue(
                get_number_of_disks_for_instance(self.PROJECT_ID, self.ZONE, self.scanning_taking_instance), 2)
            detachment_event = {"volume_name": message_from_queue["volume_name"],
                                "instance_name": message_from_queue[
                                    "instance_name"]}
            self.wait_till_no_exception(lambda x: TriggerVolumeDettachment().entry_point(
                self.get_cloud_event_for_given_payload(detachment_event)))
            self.assertTrue(
                get_number_of_disks_for_instance(self.PROJECT_ID, self.ZONE, self.scanning_taking_instance), 1)

        except:
            traceback.print_exc()
            self.fail()
        finally:
            delete_gcp_snapshot(snapshot_name, self.PROJECT_ID)
            # delete_gcp_disk(message_from_queue["volume_name"], self.project_id, self.zone)


if __name__ == "__main__":
    TestConsumers.PROJECT_ID = os.environ.get('PROJECT_ID', "electionscraping")
    TestConsumers.ZONE = os.environ.get('ZONE', "asia-south1-c")
    unittest.main()
