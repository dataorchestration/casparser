import json
import unittest

from cloudevents.conversion import to_structured
from cloudevents.http import CloudEvent

from main import function_new_compute_creation_trigger


class TestNewInstance(unittest.TestCase):

    def setUp(self) -> None:
        self.json = {'attributes': {'specversion': '1.0',
                                    'id': 'projects/electionscraping/logs/cloudaudit.googleapis.com%2Factivityoz2u71dev601679732848381516',
                                    'source': '//cloudaudit.googleapis.com/projects/electionscraping/logs/activity',
                                    'type': 'google.cloud.audit.log.v1.written',
                                    'datacontenttype': 'application/json; charset=utf-8',
                                    'dataschema': 'https://googleapis.github.io/google-cloudevents/jsonschema/google/events/cloud/audit/v1/LogEntryData.json',
                                    'subject': 'compute.googleapis.com/projects/electionscraping/zones/asia-south1-c/instances/test-eventerv',
                                    'time': '2023-03-25T08:27:33.239663656Z',
                                    'resourcename': 'projects/electionscraping/zones/asia-south1-c/instances/test-eventerv',
                                    'recordedtime': '2023-03-25T08:27:28.381516Z',
                                    'methodname': 'beta.compute.instances.insert',
                                    'servicename': 'compute.googleapis.com'}, 'data': {
            'protoPayload': {'authenticationInfo': {'principalEmail': 'navdeep@dataorc.in'},
                             'requestMetadata': {'callerIp': '2401:4900:1c61:726f:405b:6f50:a375:583b',
                                                 'callerSuppliedUserAgent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36,gzip(gfe),gzip(gfe)',
                                                 'requestAttributes': {'time': '2023-03-25T08:27:32.517495Z',
                                                                       'reason': '8uSywAYQGg5Db2xpc2V1bSBGbG93cw',
                                                                       'auth': {}}, 'destinationAttributes': {}},
                             'serviceName': 'compute.googleapis.com', 'methodName': 'beta.compute.instances.insert',
                             'authorizationInfo': [{'permission': 'compute.instances.create', 'granted': True,
                                                    'resourceAttributes': {'service': 'compute',
                                                                           'name': 'projects/electionscraping/zones/asia-south1-c/instances/test-eventerv',
                                                                           'type': 'compute.instances'}},
                                                   {'permission': 'compute.disks.create', 'granted': True,
                                                    'resourceAttributes': {'service': 'compute',
                                                                           'name': 'projects/electionscraping/zones/asia-south1-c/disks/test-eventerv',
                                                                           'type': 'compute.disks'}},
                                                   {'permission': 'compute.subnetworks.use', 'granted': True,
                                                    'resourceAttributes': {'service': 'compute',
                                                                           'name': 'projects/electionscraping/regions/asia-south1/subnetworks/default',
                                                                           'type': 'compute.subnetworks'}},
                                                   {'permission': 'compute.subnetworks.useExternalIp', 'granted': True,
                                                    'resourceAttributes': {'service': 'compute',
                                                                           'name': 'projects/electionscraping/regions/asia-south1/subnetworks/default',
                                                                           'type': 'compute.subnetworks'}},
                                                   {'permission': 'compute.instances.setServiceAccount',
                                                    'granted': True, 'resourceAttributes': {'service': 'compute',
                                                                                            'name': 'projects/electionscraping/zones/asia-south1-c/instances/test-eventerv',
                                                                                            'type': 'compute.instances'}}],
                             'resourceName': 'projects/electionscraping/zones/asia-south1-c/instances/test-eventerv',
                             'serviceData': {},
                             'request': {'@type': 'type.googleapis.com/compute.instances.insert', 'canIpForward': False,
                                         'reservationAffinity': {'consumeReservationType': 'ANY_ALLOCATION'}, 'disks': [
                                     {'mode': 'READ_WRITE', 'autoDelete': True, 'initializeParams': {
                                         'diskType': 'projects/electionscraping/zones/us-central1-a/diskTypes/pd-balanced',
                                         'diskSizeGb': '10',
                                         'sourceImage': 'projects/debian-cloud/global/images/debian-11-bullseye-v20230306'},
                                      'boot': True, 'type': 'PERSISTENT', 'deviceName': 'test-eventerv'}],
                                         'keyRevocationActionType': 'NONE_ON_KEY_REVOCATION', 'serviceAccounts': [{
                                     'scopes': [
                                         'https://www.googleapis.com/auth/devstorage.read_only',
                                         'https://www.googleapis.com/auth/logging.write',
                                         'https://www.googleapis.com/auth/monitoring.write',
                                         'https://www.googleapis.com/auth/servicecontrol',
                                         'https://www.googleapis.com/auth/service.management.readonly',
                                         'https://www.googleapis.com/auth/trace.append'],
                                     'email': '367536339233-compute@developer.gserviceaccount.com'}],
                                         'scheduling': {'automaticRestart': True, 'provisioningModel': 'STANDARD',
                                                        'onHostMaintenance': 'MIGRATE'},
                                         'displayDevice': {'enableDisplay': False},
                                         'machineType': 'projects/electionscraping/zones/asia-south1-c/machineTypes/e2-micro',
                                         'description': '', 'networkInterfaces': [{'stackType': 'IPV4_ONLY',
                                                                                   'subnetwork': 'projects/electionscraping/regions/asia-south1/subnetworks/default',
                                                                                   'accessConfigs': [
                                                                                       {'networkTier': 'PREMIUM',
                                                                                        'name': 'External NAT'}]}],
                                         'confidentialInstanceConfig': {'enableConfidentialCompute': False},
                                         'deletionProtection': False,
                                         'shieldedInstanceConfig': {'enableSecureBoot': False, 'enableVtpm': True,
                                                                    'enableIntegrityMonitoring': True},
                                         'name': 'test-eventerv'},
                             'response': {'startTime': '2023-03-25T01:27:32.465-07:00',
                                          'name': 'operation-1679732848278-5f7b547bd3bb9-4c8b4ab7-b4921d9e',
                                          'selfLinkWithId': 'https://www.googleapis.com/compute/beta/projects/electionscraping/zones/asia-south1-c/operations/3214493247039803035',
                                          'insertTime': '2023-03-25T01:27:32.464-07:00',
                                          'targetLink': 'https://www.googleapis.com/compute/beta/projects/electionscraping/zones/asia-south1-c/instances/test-eventerv',
                                          'selfLink': 'https://www.googleapis.com/compute/beta/projects/electionscraping/zones/asia-south1-c/operations/operation-1679732848278-5f7b547bd3bb9-4c8b4ab7-b4921d9e',
                                          '@type': 'type.googleapis.com/operation', 'user': 'navdeep@dataorc.in',
                                          'id': '3214493247039803035', 'status': 'RUNNING',
                                          'zone': 'https://www.googleapis.com/compute/beta/projects/electionscraping/zones/asia-south1-c',
                                          'targetId': '4161033240837295772', 'operationType': 'insert',
                                          'progress': '0'},
                             'resourceLocation': {'currentLocations': ['asia-south1-c']}}, 'insertId': 'oz2u71dev60',
            'resource': {'type': 'gce_instance',
                         'labels': {'project_id': 'electionscraping', 'instance_id': '4161033240837295772',
                                    'zone': 'asia-south1-c'}}, 'timestamp': '2023-03-25T08:27:28.381516Z',
            'severity': 'NOTICE', 'logName': 'projects/electionscraping/logs/cloudaudit.googleapis.com%2Factivity',
            'operation': {'id': 'operation-1679732848278-5f7b547bd3bb9-4c8b4ab7-b4921d9e',
                          'producer': 'compute.googleapis.com', 'first': True},
            'receiveTimestamp': '2023-03-25T08:27:33.239663656Z'}}

    def test_new_instance(self):
        cloudevent = CloudEvent(attributes={
            "type": "com.example.sampletype2",
            "source": "https://example.com/event-producer",
        }, data=self.json)
        headers, body = to_structured(cloudevent)
        function_new_compute_creation_trigger(body)
