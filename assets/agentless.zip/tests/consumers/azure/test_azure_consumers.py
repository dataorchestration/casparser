import os
import time
import unittest
from datetime import datetime

from handlers.failure.RaiseExceptionHandler import QueuePushBackException
from logger.custom_logging import log
from messages.message_ec2_scanning_info import InstanceVolumeToScan
from triggers.trigger_disk_creation_for_snapshot_ready import TriggerDiskCreationOnSnapshotComplete
from triggers.trigger_disk_snapshotting_for_incoming_compute import TriggerDiskSnapshottingForIncomingCompute
from triggers.trigger_snapshot_copy import TriggerSnapshotCopy
from triggers.trigger_volume_attachment import TriggerVolumeAttachment
from utils.azure.utils_service_bus import send_message_to_service_bus_topic, receive_message_from_service_bus_topic


class TestAzureServiceConsumers(unittest.TestCase):
    def setUp(self) -> None:
        # create service bus queue
        self.queues_object = {
            "compute-listing-queue": {
                "service_bus_connection_string": "Endpoint=sb://compute-listing-queue-servicebus.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=hy/CZk6RK25/gYcuC26aM+yJNf314rhdg+ASbP/Mjj8=",
                "service_bus_namespace_name": "compute-listing-queue-servicebus",
                "topic_name": "compute-listing-queue-topic",
                "topic_subscription_name": "compute-listing-queue-subscription"
            },
            "disk-attach-queue": {
                "service_bus_connection_string": "Endpoint=sb://disk-attach-queue-servicebus.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=2bUmQ4DB1UgZkWSOpoYuztMvgDToH8KLL+ASbNCoH+s=",
                "service_bus_namespace_name": "disk-attach-queue-servicebus",
                "topic_name": "disk-attach-queue-topic",
                "topic_subscription_name": "disk-attach-queue-subscription"
            },
            "disk-creation-queue": {
                "service_bus_connection_string": "Endpoint=sb://disk-creation-queue-servicebus.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=5sHsY0IlgH/HolVzl+oVGDxLFmxlkh+FB+ASbKcMnAM=",
                "service_bus_namespace_name": "disk-creation-queue-servicebus",
                "topic_name": "disk-creation-queue-topic",
                "topic_subscription_name": "disk-creation-queue-subscription"
            },
            "snapshot-copy-queue": {
                "service_bus_connection_string": "Endpoint=sb://snapshot-copy-queue-servicebus.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=lbaXtfktWLZqyBgN0o2zUe+JEfwimVXpu+ASbNgIL1E=",
                "service_bus_namespace_name": "snapshot-copy-queue-servicebus",
                "topic_name": "snapshot-copy-queue-topic",
                "topic_subscription_name": "snapshot-copy-queue-subscription"
            },
            "snapshot-creation-queue": {
                "service_bus_connection_string": "Endpoint=sb://snapshot-creation-queue-servicebus.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=2S6ddlloHGbqxo1KCI4YDozWuLwwb48sC+ASbDTLdBs=",
                "service_bus_namespace_name": "snapshot-creation-queue-servicebus",
                "topic_name": "snapshot-creation-queue-topic",
                "topic_subscription_name": "snapshot-creation-queue-subscription"
            }
        }
        # adding here for explicitness
        os.environ['RESOURCE_GROUP_NAME'] = os.getenv("RESOURCE_GROUP_NAME", "dataorc-rg")
        os.environ['SUBSCRIPTION_ID'] = os.getenv("SUBSCRIPTION_ID")
        os.environ['CLIENT_ID'] = os.getenv("CLIENT_ID")
        os.environ['TENANT_ID'] = os.getenv("TENANT_ID")
        os.environ['CLIENT_SECRET'] = os.getenv("CLIENT_SECRET")
        os.environ['REGION'] = os.getenv("REGION", "eastus")
        os.environ['SNAPSHOT_STORAGE_NAME'] = 'dataorcsnapshotstorage'
        os.environ[
            "SNAPSHOT_STORAGE_CONNECTION_STRING"] = os.getenv("SNAPSHOT_STORAGE_CONNECTION_STRING")

    def test_flow(self):
        # create compute listing message
        instance_volume_to_scan = InstanceVolumeToScan(volume_name="osdisk-myvm-0",
                                                       dest_snapshot_name=f"test_snapshot_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}",
                                                       dest_volume_name=f"snapshot_created_volume-{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}")
        json_data = instance_volume_to_scan.to_json()
        send_message_to_service_bus_topic(self.queues_object["compute-listing-queue"]["service_bus_connection_string"],
                                          self.queues_object["compute-listing-queue"]["topic_name"],
                                          json_data)
        # receve message from compute listing queue
        message = receive_message_from_service_bus_topic(
            self.queues_object["compute-listing-queue"]["service_bus_connection_string"],
            self.queues_object["compute-listing-queue"]["topic_name"],
            self.queues_object["compute-listing-queue"]["topic_subscription_name"])
        os.environ["OUTPUT_TOPIC"] = self.queues_object["snapshot-copy-queue"]["topic_name"]
        os.environ["OUTPUT_SERVICE_BUS_CONNECTION_STRING"] = self.queues_object["snapshot-copy-queue"][
            "service_bus_connection_string"]
        TriggerDiskSnapshottingForIncomingCompute().entry_point(cloud_type="azure", data=message)
        # receive message from snapshot copy queue
        time.sleep(30)
        message = receive_message_from_service_bus_topic(
            self.queues_object["snapshot-copy-queue"]["service_bus_connection_string"],
            self.queues_object["snapshot-copy-queue"]["topic_name"],
            self.queues_object["snapshot-copy-queue"]["topic_subscription_name"])
        os.environ["OUTPUT_TOPIC"] = self.queues_object["disk-creation-queue"]["topic_name"]
        os.environ["OUTPUT_SERVICE_BUS_CONNECTION_STRING"] = self.queues_object["disk-creation-queue"][
            "service_bus_connection_string"]
        os.environ["CONTAINER_NAME"] = "snapshots"

        response = TriggerSnapshotCopy().entry_point(cloud_type="azure", data=message)
        # mark message as complete

        time.sleep(30)
        while True:
            message = receive_message_from_service_bus_topic(
                self.queues_object["disk-creation-queue"]["service_bus_connection_string"],
                self.queues_object["disk-creation-queue"]["topic_name"],
                self.queues_object["disk-creation-queue"]["topic_subscription_name"])
            if message is not None:
                break
            time.sleep(10)

        os.environ["OUTPUT_TOPIC"] = self.queues_object["disk-attach-queue"]["topic_name"]
        os.environ["OUTPUT_SERVICE_BUS_CONNECTION_STRING"] = self.queues_object["disk-attach-queue"][
            "service_bus_connection_string"]
        os.environ["CURRENT_VM_NAME"] = "myvm-vmLinux-0"
        time.sleep(30)
        while True:
            try:
                response = TriggerDiskCreationOnSnapshotComplete().entry_point(cloud_type="azure", data=message)
                break
            except QueuePushBackException as e:
                log(f"failed to push back message to queue {e}. we will try again in 30 seconds")
                time.sleep(30)
        while True:
            message = receive_message_from_service_bus_topic(
                self.queues_object["disk-attach-queue"]["service_bus_connection_string"],
                self.queues_object["disk-attach-queue"]["topic_name"],
                self.queues_object["disk-attach-queue"]["topic_subscription_name"])
            if message is not None:
                break
            time.sleep(10)
        TriggerVolumeAttachment().entry_point(cloud_type="azure", data=message)

    def test_send_message_to_compute_listing_queue(self):
        instance_volume_to_scan = InstanceVolumeToScan(volume_name="osdisk-myvm-0",
                                                       dest_snapshot_name=f"test_snapshot-{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}",
                                                       dest_volume_name=f"snapshot_created_volume-{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}")
        json_data = instance_volume_to_scan.to_json()
        send_message_to_service_bus_topic(
            "Endpoint=sb://agentless-queues-namespace.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=Pb9bx5ftRwntpDpg8lmaAEEHJ78HEyyKC+ASbID7d6s=",
            "compute-listing-queue-topic",
            json_data)
