import os
import time
import traceback
import unittest

from handlers.failure.RaiseExceptionHandler import QueuePushBackException
from logger.custom_logging import log, log_error
from messages.message_ec2_disk_dettachment import InstanceVolumeDetachment
from messages.message_ec2_scanning_info import InstanceVolumeToScan
from triggers.trigger_disk_creation_for_snapshot_ready import TriggerDiskCreationOnSnapshotComplete
from triggers.trigger_disk_snapshotting_for_incoming_compute import TriggerDiskSnapshottingForIncomingCompute
from triggers.trigger_volume_attachment import TriggerVolumeAttachment
from triggers.trigger_volume_dettachment import TriggerVolumeDettachment
from utils.aws.utils_compute import aws_create_instance_for_default_network, aws_delete_instance_for_instance_id, \
    aws_get_volume_id_of_disk_attached
from utils.aws.utils_sqs import aws_create_sqs_queue, aws_delete_sqs_queue, send_message_to_sqs, receive_message, \
    wait_till_message_is_received


class TestVolumeScanningWithAWS(unittest.TestCase):
    account_id = "216727195602"
    region = "ap-south-1"
    zone = "ap-south-1a"
    snapshot_taking_instance = "i-00637885cd2607d87"
    scanning_taking_instance = "i-07284c9cea69afa24"
    volume_to_dettach = "vol-0b1b1b1b1b1b1b1b1"

    def __init__(self, methodName: str = ...):
        super().__init__(methodName)
        self.snapshot_waiting_queue_name = "snapshot_waiting"
        self.attachment_completed_queue_name = "attachment_completed"
        self.disk_creation_waiting_queue_name = "disk_creation_waiting"

    def get_sqs_message_for_given_payload(self, data: str):
        return {
            "Records": [
                {
                    "messageId": "19dd0b57-b21e-4ac1-bd88-01bbb068cb78",
                    "receiptHandle": "MessageReceiptHandle",
                    "body": data,
                    "attributes": {
                        "ApproximateReceiveCount": "1",
                        "SentTimestamp": "1523232000000",
                        "SenderId": "123456789012",
                        "ApproximateFirstReceiveTimestamp": "1523232000001"
                    },
                    "messageAttributes": {},
                    "md5OfBody": "7b270e59b47ff90a553787216d55d91d",
                    "eventSource": "aws:sqs",
                    "eventSourceARN": "arn:aws:sqs:ap-southeast-2:123456789012:MyQueue",
                    "awsRegion": "ap-southeast-2"
                }
            ]
        }

    def setUp(self) -> None:
        log("setting up for aws test cases")
        # create aws instance, snapshot taking
        # create aws instance, scanning taking
        # create sqs queue, volume listing
        self.snapshot_taking_instance_name = "snapshot-taking-instance"
        self.scanning_taking_instance_name = "scanning-taking-instance"
        self.snapshot_taking_instance = \
            aws_create_instance_for_default_network(self.account_id, self.region,
                                                    "ami-052639b6127cfb32d", "t2.micro",
                                                    "dataorc-standalone-keypair",
                                                    self.snapshot_taking_instance_name,
                                                    tag_value="snapshot")["instance_id"]
        self.scanning_taking_instance = \
            aws_create_instance_for_default_network(self.account_id, self.region,
                                                    "ami-052639b6127cfb32d", "t2.micro",
                                                    "dataorc-standalone-keypair",
                                                    "type",
                                                    tag_value="scanners")["instance_id"]
        aws_create_sqs_queue(self.account_id, self.region, self.snapshot_waiting_queue_name
                             )
        aws_create_sqs_queue(self.account_id, self.region, self.attachment_completed_queue_name)
        aws_create_sqs_queue(self.account_id, self.region, self.disk_creation_waiting_queue_name)

    def wait_till_no_exception(self, function, default_sleep_time=4):
        while True:
            try:
                function(None)
                break
            except QueuePushBackException:
                log(traceback.format_exc())
                time.sleep(default_sleep_time)

    def tearDown(self) -> None:
        log("tearing down for aws test cases")
        aws_delete_instance_for_instance_id(self.account_id, self.region, self.snapshot_taking_instance)
        aws_delete_instance_for_instance_id(self.account_id, self.region, self.scanning_taking_instance)
        aws_delete_sqs_queue(self.account_id, self.region, self.snapshot_waiting_queue_name
                             )
        aws_delete_sqs_queue(self.account_id, self.region, self.attachment_completed_queue_name)
        aws_delete_sqs_queue(self.account_id, self.region, self.disk_creation_waiting_queue_name)

    def test_end_to_end(self):
        # create instance id and send volume id
        try:
            os.environ["ACCOUNT_ID"] = self.account_id
            os.environ["REGION"] = self.region
            os.environ["OUTPUT_TOPIC"] = self.snapshot_waiting_queue_name
            os.environ["ZONE"] = self.zone
            os.environ["TAGS"] = "scanners"

            instance_volume_to_scan = InstanceVolumeToScan(account_id=self.account_id, region=self.region,
                                                           instance_name=self.snapshot_taking_instance,
                                                           volume_name=aws_get_volume_id_of_disk_attached(
                                                               self.account_id,
                                                               self.region,
                                                               self.snapshot_taking_instance),
                                                           dest_volume_name="dest_volume_name",
                                                           dest_snapshot_name="dest_snapshot_name")
            TriggerDiskSnapshottingForIncomingCompute().entry_point(
                self.get_sqs_message_for_given_payload(instance_volume_to_scan.to_json()), "aws")
            message = wait_till_message_is_received(self.account_id, self.region, self.snapshot_waiting_queue_name)
            os.environ["OUTPUT_TOPIC"] = self.disk_creation_waiting_queue_name
            TriggerDiskCreationOnSnapshotComplete().entry_point(self.get_sqs_message_for_given_payload(message), "aws")
            message = wait_till_message_is_received(self.account_id, self.region, self.disk_creation_waiting_queue_name)
            self.assertIsNotNone(message)
            os.environ["OUTPUT_TOPIC"] = self.attachment_completed_queue_name
            TriggerVolumeAttachment().entry_point(self.get_sqs_message_for_given_payload(message), "aws")
            message = wait_till_message_is_received(self.account_id, self.region, self.attachment_completed_queue_name)
            self.assertIsNotNone(message)

        except:
            log_error("failed to execute test_end_to_end")
            log_error(traceback.format_exc())
            self.fail("failed to execute test_end_to_end")

    # def test_trigger_disk_dettachment(self):
    #     os.environ["OUTPUT_TOPIC"] = "sqs_snapshot_waiting"
    #     os.environ["ACCOUNT_ID"] = self.account_id
    #     os.environ["REGION"] = self.region
    #     os.environ["ZONE"] = self.zone
    #     disk_to_detach = InstanceVolumeDetachment("i-0de41c7eaa54c9911", "vol-0fb894aa21dfa02bc")
    #     TriggerVolumeDettachment().entry_point(self.get_sqs_message_for_given_payload(disk_to_detach.to_json()), "aws")
    #     wait_till_message_is_received(self.account_id, self.region, os.getenv("OUTPUT_TOPIC"))


if __name__ == '__main__':
    TestVolumeScanningWithAWS.PROJECT_ID = os.environ.get('account_id', "216727195602")
    TestVolumeScanningWithAWS.ZONE = os.environ.get('region', "ap-south-1")
    # TestVolumeScanningWithAWS.scanning_taking_instance = "i-0de41c7eaa54c9911"
    # TestVolumeScanningWithAWS.snapshot_taking_instance = "i-00637885cd2607d87"
    # TestVolumeScanningWithAWS.volume_to_dettach = "vol-0c062722af7f0adfc"
    unittest.main()
