import os
import time
import traceback
import unittest

from logger.custom_logging import log, log_error
from main_aws import function_monitoring
from utils.aws.utils_compute import aws_create_instance_for_default_network, aws_delete_instance_for_instance_id, \
    get_aws_instance_with_tags_and_given_state, aws_attach_disk_to_instance, \
    aws_get_instances_with_disks_attached_less_than_given_limit, aws_convert_snapshot_to_disk_volume, \
    aws_check_if_disk_creation_completed


class TestIntancesScaling(unittest.TestCase):
    account_id = "216727195602"
    region = "ap-south-1"
    zone = "ap-south-1a"

    def __init__(self, methodName: str = ...):
        super().__init__(methodName)
        self.MAX_INSTANCES = 3
        self.MIN_INSTANCES = 1
        self.MAX_SLOTS = 2
        self.MIN_SLOTS = 1
        self.snapshot_id = "snap-06dd768c11418bf03"

    def write_to_local_file(self, list_of_instance_ids):
        with open("instance_ids.txt", "w") as file:
            for instance_id in list_of_instance_ids:
                file.write(instance_id + "\n")

    def get_instance_ids_from_file(self):
        with open("instance_ids.txt", "r") as file:
            return [line.replace("\n", '') for line in file if len(line) > 0]

    def setUp(self) -> None:
        log("setting up for aws test cases")
        instance_ids = [aws_create_instance_for_default_network(self.account_id, self.region,
                                                                "ami-052639b6127cfb32d", "t2.micro",
                                                                "dataorc-standalone-keypair",
                                                                "type",
                                                                tag_value="scanners")["instance_id"] for i in
                        range(self.MAX_INSTANCES)]
        self.write_to_local_file(instance_ids)

    def tearDown(self) -> None:
        log("tearing down for aws test cases")
        instances = self.get_instance_ids_from_file()
        for instance_id in instances:
            aws_delete_instance_for_instance_id(self.account_id, self.region, instance_id)
        # delete the file
        os.remove("instance_ids.txt")

    def wait_till_function_is_true(self, function, default_sleep_time=4):
        while True:
            if function():
                break
            time.sleep(default_sleep_time)

    def get_volume_id_for_snapshot_id(self, snapshot_id):
        volume_data = aws_convert_snapshot_to_disk_volume(self.account_id, self.region,
                                                          snapshot_id, "cross_region",
                                                          "ap-south-1a")
        # attach volume to instance
        self.wait_till_function_is_true(lambda: aws_check_if_disk_creation_completed(self.account_id,
                                                                                     self.region,
                                                                                     volume_name=volume_data[
                                                                                         "volume_id"]))
        return volume_data["volume_id"]

    def test_scale_down(self):
        # create instance id and send volume id
        try:
            os.environ["ACCOUNT_ID"] = self.account_id
            os.environ["REGION"] = self.region
            os.environ["ZONE"] = self.zone
            os.environ["TAGS"] = "scanners"
            os.environ["MIN_INSTANCES"] = str(self.MIN_INSTANCES)
            os.environ["MAX_INSTANCES"] = str(self.MAX_INSTANCES)
            os.environ["MAX_SLOTS"] = str(self.MAX_SLOTS)
            os.environ["MIN_SLOTS"] = str(self.MIN_SLOTS)
            # we will attach two volumes to only instance

            function_monitoring(None, None)
            time.sleep(10)
            instances = get_aws_instance_with_tags_and_given_state(self.account_id, self.region, ["scanners"], "running")
            assert len(instances) == 2
            function_monitoring(None, None)
            time.sleep(10)
            instances = get_aws_instance_with_tags_and_given_state(self.account_id, self.region, ["scanners"], "running")
            assert len(instances) == 1
            function_monitoring(None, None)
            time.sleep(10)
            assert len(instances) == 1
            # attach another to running instance
            aws_attach_disk_to_instance(self.account_id, self.region, instances[0],
                                        self.get_volume_id_for_snapshot_id(self.snapshot_id))
            function_monitoring(None, None)
            time.sleep(30)
            instances = get_aws_instance_with_tags_and_given_state(self.account_id, self.region, ["scanners"], "running")
            assert len(instances) == 2
            instances = aws_get_instances_with_disks_attached_less_than_given_limit(self.account_id, self.region,
                                                                                    "scanners", 2, zone=self.zone)
            log("instances with less than 2 disks attached are {}".format(instances))
            assert len(instances) == 1
            aws_attach_disk_to_instance(self.account_id, self.region, instances[0].instance_id,
                                        self.get_volume_id_for_snapshot_id(self.snapshot_id))
            function_monitoring(None, None)
            time.sleep(30)
            instances = get_aws_instance_with_tags_and_given_state(self.account_id, self.region, ["scanners"], "running")
            log("instances with state running are {}".format(instances))
            assert len(instances) == 3


        except:
            log_error("failed to execute test_end_to_end")
            log_error(traceback.format_exc())
            self.fail("failed to execute test_end_to_end")


if __name__ == '__main__':
    unittest.main()
