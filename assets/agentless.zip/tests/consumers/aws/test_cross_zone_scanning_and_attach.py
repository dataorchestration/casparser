import os
import time
import traceback
import unittest

from handlers.failure.RaiseExceptionHandler import QueuePushBackException
from logger.custom_logging import log, log_error
from messages.message_ec2_disk_dettachment import InstanceVolumeDetachment
from messages.message_ec2_scanning_info import InstanceVolumeToScan
from triggers.trigger_disk_creation_for_snapshot_ready import TriggerDiskCreationOnSnapshotComplete
from triggers.trigger_disk_snapshotting_for_incoming_compute import TriggerDiskSnapshottingForIncomingCompute
from triggers.trigger_volume_attachment import TriggerVolumeAttachment
from triggers.trigger_volume_dettachment import TriggerVolumeDettachment
from utils.aws.utils_compute import aws_create_instance_for_default_network, aws_delete_instance_for_instance_id, \
    aws_get_volume_id_of_disk_attached, aws_take_snapshot, aws_convert_snapshot_to_disk_volume, \
    aws_attach_given_disk_to_instance, aws_check_if_snapshot_completed, aws_check_if_disk_creation_completed, \
    get_first_unfilled_device_name
from utils.aws.utils_sqs import aws_create_sqs_queue, aws_delete_sqs_queue, send_message_to_sqs, receive_message, \
    wait_till_message_is_received


class TestVolumeScanningWithAWS(unittest.TestCase):
    account_id = "216727195602"
    region = "ap-south-1"
    zone = "ap-south-1a"
    snapshot_taking_instance = "i-0281566846af51501"
    scanning_taking_instance = "i-0fbd2576cef1b5250"
    volume_to_dettach = "vol-0c9b7f2e14bfadb1b"

    def __init__(self, methodName: str = ...):
        super().__init__(methodName)
        self.snapshot_waiting_queue_name = "snapshot_waiting"
        self.attachment_completed_queue_name = "attachment_completed"
        self.disk_creation_waiting_queue_name = "disk_creation_waiting"

    def get_sqs_message_for_given_payload(self, data: str):
        return {
            "Records": [
                {
                    "messageId": "19dd0b57-b21e-4ac1-bd88-01bbb068cb78",
                    "receiptHandle": "MessageReceiptHandle",
                    "body": data,
                    "attributes": {
                        "ApproximateReceiveCount": "1",
                        "SentTimestamp": "1523232000000",
                        "SenderId": "123456789012",
                        "ApproximateFirstReceiveTimestamp": "1523232000001"
                    },
                    "messageAttributes": {},
                    "md5OfBody": "7b270e59b47ff90a553787216d55d91d",
                    "eventSource": "aws:sqs",
                    "eventSourceARN": "arn:aws:sqs:ap-southeast-2:123456789012:MyQueue",
                    "awsRegion": "ap-southeast-2"
                }
            ]
        }

    def setUp(self) -> None:
        log("setting up for aws test cases")
        return
        # create aws instance, snapshot taking
        # create aws instance, scanning taking
        # create sqs queue, volume listing
        self.snapshot_taking_instance_name = "snapshot-taking-instance"
        self.scanning_taking_instance_name = "scanning-taking-instance"

    def wait_till_no_exception(self, function, default_sleep_time=4):
        while True:
            try:
                function(None)
                break
            except QueuePushBackException:
                log(traceback.format_exc())
                time.sleep(default_sleep_time)

    def wait_till_function_is_true(self, function, default_sleep_time=4):
        while True:
            if function():
                break
            time.sleep(default_sleep_time)

    def test_end_to_end(self):
        # create instance id and send volume id
        try:
            # take snapshot of volume to detach
            snapshot_data = aws_take_snapshot(self.account_id, self.region, self.volume_to_dettach, "snapshot_name")
            # crete volume for snapshot
            self.wait_till_function_is_true(
                lambda: aws_check_if_snapshot_completed(self.account_id, self.region, snapshot_data["snapshot_id"]))
            volume_data = aws_convert_snapshot_to_disk_volume(self.account_id, self.region,
                                                              snapshot_data["snapshot_id"], "cross_region",
                                                              "ap-south-1b")
            # attach volume to instance
            self.wait_till_function_is_true(lambda: aws_check_if_disk_creation_completed(self.account_id,
                                                                                         self.region,
                                                                                         volume_name=volume_data[
                                                                                             "volume_id"]))
            device_name = get_first_unfilled_device_name(self.account_id, self.region, self.scanning_taking_instance)
            aws_attach_given_disk_to_instance(self.account_id, self.region, self.scanning_taking_instance,
                                              volume_data["volume_id"],device_location=device_name)







        except:
            log_error("failed to execute test_end_to_end")
            log_error(traceback.format_exc())
            self.fail("failed to execute test_end_to_end")


if __name__ == '__main__':
    TestVolumeScanningWithAWS.PROJECT_ID = os.environ.get('account_id', "216727195602")
    TestVolumeScanningWithAWS.ZONE = os.environ.get('region', "ap-south-1")
    TestVolumeScanningWithAWS.snapshot_taking_instance = "i-0281566846af51501"
    TestVolumeScanningWithAWS.scanning_taking_instance = "i-0fbd2576cef1b5250"
    TestVolumeScanningWithAWS.volume_to_dettach = "vol-0c9b7f2e14bfadb1b"
    unittest.main()
