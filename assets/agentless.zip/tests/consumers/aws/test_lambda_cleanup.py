import os
import time
import unittest

from logger.custom_logging import log
from main_aws import function_cleanup_trigger


class TestIntancesScaling(unittest.TestCase):
    account_id = "216727195602"
    region = "ap-south-1"
    zone = "ap-south-1a"

    def __init__(self, methodName: str = ...):
        super().__init__(methodName)
        self.MAX_INSTANCES = 3
        self.MIN_INSTANCES = 1
        self.MAX_SLOTS = 2
        self.MIN_SLOTS = 1
        self.snapshot_id = "snap-06dd768c11418bf03"

    def setUp(self) -> None:
        log("setting up for aws test cases")

    def tearDown(self) -> None:
        log("tearing down for aws test cases")

    def wait_till_function_is_true(self, function, default_sleep_time=4):
        while True:
            if function():
                break
            time.sleep(default_sleep_time)

    def test_cleanup(self):
        os.environ["ACCOUNT_ID"] = self.account_id
        os.environ["REGION"] = self.region
        os.environ["ZONE"] = self.zone
        os.environ["TAGS"] = "scanners"
        function_cleanup_trigger(None, None)


if __name__ == '__main__':
    unittest.main()
