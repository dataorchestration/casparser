import os
import unittest

from main_aws import function_ec2_running_trigger


class TestEC2RunningEventBridgeEvent(unittest.TestCase):

    def test_ec2_running_event(self):
        create_ec2_event = {
            "version": "0",
            "id": "7bf73129-1428-4cd3-a780-95db273d1602",
            "detail-type": "EC2 Instance State-change Notification",
            "source": "aws.ec2",
            "account": "216727195602",
            "time": "2015-11-11T21:29:54Z",
            "region": "us-east-1",
            "resources": ["arn:aws:ec2:ap-south-1:216727195602:instance/i-09b85f2debd10231f"],
            "detail": {
                "instance-id": "i-09b85f2debd10231f",
                "state": "running"
            }
        }
        os.environ["ACCOUNT_ID"] = "216727195602"
        os.environ["REGION"] = "ap-south-1"
        os.environ["VOLUME_SCANNER_TRIGGER_QUEUE"] = "sqs_snapshot_waiting"

        function_ec2_running_trigger(create_ec2_event, None)
