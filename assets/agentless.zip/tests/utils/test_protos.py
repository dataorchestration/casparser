import base64
import unittest

from protos.classes.volume_tagging_pb2 import DiskCreated


class TestProtos(unittest.TestCase):
    def test_protos(self):
        # Test that the protos are valid
        """{"v":1,"oi":"i-03f3c4ba4f01bb47b","ci":"i-01a2bd8f186cd9529","ovol":"vol-0a5fcb655d228efc5","cvol":"vol-008b30b9b74b581c3","jid":"job_id","acid":"319527549264","r":"us-east-1"}"""
        disk_created = DiskCreated(version="1", original_volume_id="vol-0a5fcb655d228efc5",
                                   original_instance_id="i-03f3c4ba4f01bb47b",
                                   created_volume_id="vol-008b30b9b74b581c3", created_instance_id="i-01a2bd8f186cd9529",
                                   job_id="job_id", account_id="319527549264", region="us-east-1")
        base64str = base64.b64encode(disk_created.SerializeToString())
        print(base64str)
