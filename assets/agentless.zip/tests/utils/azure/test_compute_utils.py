import os
import unittest

from utils.azure.utils_compute import *


class TestAzureComputeUtils(unittest.TestCase):
    def setUp(self) -> None:
        self.resource_group_name = os.environ.get("AZURE_RESOURCE_GROUP_NAME")
        self.subscription_id = os.environ.get("AZURE_SUBSCRIPTION_ID")
        self.client_id = os.environ.get("AZURE_CLIENT_ID")
        self.tenant_id = os.environ.get("AZURE_TENANT_ID")
        self.client_secret = os.environ.get("AZURE_CLIENT_SECRET")
        self.storage_account_name = os.environ.get("AZURE_STORAGE_ACCOUNT_NAME")
        self.disk_name = "scanner_OsDisk_1_33d9855326824e10bba2f8937fdfa4be"
        self.original_location = "eastus"
        self.snapshot_storage_container_name = f"snapshots"
        self.blob_name = f"test-snapshot-{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}"
        self.scanner_location = "southindia"
        self.scanning_vm_name = "southindiascanner"
        self.destination_disk_name = "scanning_disk_name"
        self.snapshot_name = "test-snapshot"
        self.destination_storage_account = "storageforsnapshots"
        self.snapshot_storage_connection_string = os.environ.get("AZURE_STORAGE_CONNECTION_STRING")

    def tearDown(self):
        pass

    def test_snapshotting(self):
        # take snapshot
        snapshot_name = self.snapshot_name
        snapshot = azure_create_snapshot_from_disk_name(resource_group_name=self.resource_group_name,
                                                        subscription_id=self.subscription_id,
                                                        client_id=self.client_id,
                                                        tenant_id=self.tenant_id,
                                                        client_secret=self.client_secret,
                                                        disk_name=self.disk_name,
                                                        snapshot_name=snapshot_name,
                                                        location=self.original_location)
        print(azure_check_if_snapshot_is_ready(resource_group_name=self.resource_group_name,
                                               subscription_id=self.subscription_id,
                                               client_id=self.client_id,
                                               tenant_id=self.tenant_id,
                                               client_secret=self.client_secret,
                                               snapshot_name=snapshot_name))
        # get sas url
        original_sas_url = azure_create_sas_url(resource_group_name=self.resource_group_name,
                                                subscription_id=self.subscription_id,
                                                client_id=self.client_id,
                                                tenant_id=self.tenant_id,
                                                client_secret=self.client_secret,
                                                snapshot_name=snapshot_name,
                                                )
        # copy sas url to given blob storage
        snapshot_storage_bob = copy_snapshot_blob_from_sas_url_to_blob_storage(sas_url=original_sas_url,
                                                                               dest_container_name=self.snapshot_storage_container_name,
                                                                               dest_blob_name=self.blob_name,
                                                                               subscription_id=self.subscription_id,
                                                                               client_id=self.client_id,
                                                                               tenant_id=self.tenant_id,
                                                                               client_secret=self.client_secret,
                                                                               snapshot_storage_connection_string=self.snapshot_storage_connection_string
                                                                               )

        while (not check_if_bob_status_is_completed(subscription_id=self.subscription_id,
                                                    client_id=self.client_id,
                                                    tenant_id=self.tenant_id,
                                                    client_secret=self.client_secret,
                                                    storage_connection_string=self.snapshot_storage_connection_string,
                                                    container_name=self.snapshot_storage_container_name,
                                                    blob_name=self.blob_name)):
            print("waiting for blob to be copied")
            time.sleep(5)
        # https://storageforsnapshots.blob.core.windows.net/snapshots/test-snapshot-2023-04-26-16-39-44
        blob_url = f"{self.storage_account_name}.blob.core.windows.net/self.snapshot_storage_container_name/self.blob_name"
        # create disk from snapshot
        disk = create_disk_from_snapshot_sas_url(resource_group_name=self.resource_group_name,
                                                 subscription_id=self.subscription_id,
                                                 client_id=self.client_id,
                                                 tenant_id=self.tenant_id,
                                                 client_secret=self.client_secret,
                                                 sas_url=blob_url,
                                                 disk_name=self.destination_disk_name,
                                                 location=self.scanner_location,
                                                 snapshot_storage_name=self.destination_storage_account)
        # attach disk to vm
        azure_attach_disk_to_vm(resource_group_name=self.resource_group_name, subscription_id=self.subscription_id,
                                client_id=self.client_id, tenant_id=self.tenant_id, client_secret=self.client_secret,
                                disk_id=disk.name, vm_name=self.scanning_vm_name)
        # delete snapshot
        azure_delete_snapshot(resource_group_name=self.resource_group_name, subscription_id=self.subscription_id,
                              client_id=self.client_id, tenant_id=self.tenant_id, client_secret=self.client_secret,
                              snapshot_name=snapshot.name)
        # delete disk

    def test_create_disk_util(self):
        sas_url = "https://storageforsnapshots.blob.core.windows.net/snapshots/test-snapshot-2023-04-26-16-39-44"
        disk = create_disk_from_snapshot_sas_url(resource_group_name=self.resource_group_name,
                                                 subscription_id=self.subscription_id,
                                                 client_id=self.client_id,
                                                 tenant_id=self.tenant_id,
                                                 client_secret=self.client_secret,
                                                 sas_url=sas_url,
                                                 disk_name=self.destination_disk_name + "_test",
                                                 location="eastus",
                                                 disk_type="StandardSSD_LRS",
                                                 snapshot_storage_name="/subscriptions/7e0c1319-b948-4bb3-8579-67a38c4ba83c/resourceGroups/uptycs-resource-group/providers/Microsoft.Storage/storageAccounts/storageforsnapshots")
        print(disk)

    def test_attach_disk_to_vm(self):
        disk_name = "/subscriptions/7e0c1319-b948-4bb3-8579-67a38c4ba83c/resourceGroups/UPTYCS-RESOURCE-GROUP/providers/Microsoft.Compute/disks/scanning_disk_name_test"
        azure_attach_disk_to_vm(resource_group_name=self.resource_group_name, subscription_id=self.subscription_id,
                                client_id=self.client_id, tenant_id=self.tenant_id, client_secret=self.client_secret,
                                disk_id=disk_name, vm_name="scanner")

    def test_get_all_vms_with_filter(self):
        vm_list = azure_get_vm_with_filters(resource_group_name=self.resource_group_name,
                                            subscription_id=self.subscription_id,
                                            client_id=self.client_id, tenant_id=self.tenant_id,
                                            client_secret=self.client_secret)
        print(vm_list)
