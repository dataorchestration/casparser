import unittest

from utils.azure.utils_service_bus import send_message_to_service_bus, send_message_to_service_bus_topic


class TestServiceBus(unittest.TestCase):
    def setUp(self):
        self.connection_string = "Endpoint=sb://agentless-queues-namespace.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=oQKXHK/W6vSp537stSRA+MVAqPrkLeIes+ASbIE6L3c="
        self.queue_name = "example-servicebus-queue"
        self.topic_name = "dataorc-azure-function-compute-list-topic"

    def test_service_bus(self):
        response = send_message_to_service_bus(self.connection_string, self.queue_name, "test message 1")
        print(response)

    def test_service_bus_topic(self):
        response = send_message_to_service_bus_topic(self.connection_string, self.topic_name, "test message 2")
        print(response)
