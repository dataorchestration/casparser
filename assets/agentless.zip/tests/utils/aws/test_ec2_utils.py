import time
import traceback
import unittest

from logger.custom_logging import log, log_error
from utils.aws.utils_compute import get_instances_with_tags, aws_attach_given_disk_to_instance, \
    aws_create_instance_for_default_network, aws_delete_instance_for_instance_id, \
    aws_get_instances_with_disks_attached_less_than_given_limit, get_all_possible_combinations_of_device_names, \
    aws_detach_disk_from_instance, aws_kms_key_id_for_snapshot_id, add_tags_to_given_instance, \
    remove_tags_from_given_instance, wait_till_instance_tag_is_assigned


class TestEC2Utils(unittest.TestCase):
    account_id = "216727195602"
    region = "ap-south-1"
    zone = "ap-south-1a"

    def test_fetchEc2InstancesByTagFilter(self):
        response = get_instances_with_tags("123456789", "ap-south-1", ["scanners"])
        instances = [instance for instance in response]
        self.assertGreaterEqual(len(instances), 1)

    def test_aws_attach_given_disk_to_instance(self):
        response = aws_attach_given_disk_to_instance("123456789", "ap-south-1", "i-0de41c7eaa54c9911",
                                                     "vol-0fb894aa21dfa02bc")
        print(response)
        self.assertIsNotNone(response)

    def test_aws_detach_disk_from_instance(self):
        aws_detach_disk_from_instance(self.account_id, self.region, "vol-0c062722af7f0adfc",
                                      "i-0de41c7eaa54c9911", "/dev/sdd")

    def test_all_device_name_attachable(self):
        devices = get_all_possible_combinations_of_device_names()
        for device in devices:
            try:
                log("attaching to device: " + device)
                aws_attach_given_disk_to_instance(self.account_id, self.region, "i-0de41c7eaa54c9911",
                                                  "vol-0c062722af7f0adfc", device)
                log("successfully attached to device: " + device)
                time.sleep(3)
                aws_detach_disk_from_instance(self.account_id, self.region, "vol-0c062722af7f0adfc",
                                              "i-0de41c7eaa54c9911", device)
                time.sleep(12)

            except Exception as e:
                log_error("error attaching to device: " + device)
                log_error(traceback.format_exc())

    def test_create_instances(self):
        snapshot_taking_instance = \
            aws_create_instance_for_default_network(self.account_id, self.region,
                                                    "ami-052639b6127cfb32d", "t2.micro",
                                                    "dataorc-standalone-keypair",
                                                    "snapshot-taking-instance",
                                                    tag_value="snapshot")["instance_id"]
        scanning_taking_instance = \
            aws_create_instance_for_default_network(self.account_id, self.region,
                                                    "ami-052639b6127cfb32d", "t2.micro",
                                                    "dataorc-standalone-keypair",
                                                    "type",
                                                    tag_value="scanners")["instance_id"]
        self.assertIsNotNone(snapshot_taking_instance)
        self.assertIsNotNone(scanning_taking_instance)
        log("snapshot taking instance id: " + snapshot_taking_instance)
        log("scanning taking instance id: " + scanning_taking_instance)

    def test_destroy_instances(self):
        snapshot_taking_instance = "i-03a0fd3ee2a0e1e26"
        scanning_taking_instance = "i-0358b16d5408b2b98"
        aws_delete_instance_for_instance_id(self.account_id, self.region, snapshot_taking_instance)
        aws_delete_instance_for_instance_id(self.account_id, self.region, scanning_taking_instance)

    def test_aws_get_instances_with_disks_attached_less_than_given_limit(self):
        response = aws_get_instances_with_disks_attached_less_than_given_limit(self.account_id, self.region,
                                                                               ["scanners"], 18, "ap-south-1a")
        assert len(response) == 1

    def test_aws_kms_key_id_for_snapshot_id(self):
        response = aws_kms_key_id_for_snapshot_id(self.account_id, self.region, "snap-06dd768c11418bf03")
        print(response)

    def test_add_and_removal_of_tags(self):
        instance_id = "i-09b85f2debd10231f"
        for i in range(0, 2):
            add_tags_to_given_instance(self.account_id, self.region, instance_id, "test", "test")
            if (wait_till_instance_tag_is_assigned(self.account_id, self.region, instance_id, "test")):
                log("tag added successfully")
                remove_tags_from_given_instance(self.account_id, self.region, instance_id, "test")


if __name__ == '__main__':
    unittest.main()
