import time
import traceback
import unittest

from logger.custom_logging import log
from utils.gcp.utils_gcp_compute import list_all_instances, take_snapshot_for_disk, check_if_snapshot_completed, \
    delete_snapshot, convert_snapshot_to_disk_volume, get_disk_size_from_disk, create_gcp_instance, delete_gcp_instance, \
    get_instances_with_disks_attached_less_than_given_limit, update_tags_for_instance, attach_given_disk_to_instance, \
    validate_gcp_instance, list_all_disk_not_used_by, delete_disk


class TestGcpComputeUtils(unittest.TestCase):
    """Test GcpComputeUtils class."""

    def setUp(self) -> None:
        # create a instance
        self.project_id = "electionscraping"
        self.zone = "asia-south1-c"

    def tearDown(self) -> None:
        # delete the instance
        pass

    def test_get_instance_details(self):
        response = list_all_instances(self.project_id)
        log(response)

    def get_disk_for_instance(self):
        response = list_all_instances(self.project_id)
        source_url = response[f"zones/{self.zone}"][0].disks[0].source
        log(source_url)
        disk_name_or_id = source_url.split("/")[-1]
        log(disk_name_or_id)

    def wait_while_snapshot_is_being_created(self, snapshot_name, default_sleep_time=7):
        while not check_if_snapshot_completed(self.project_id, snapshot_name):
            time.sleep(default_sleep_time)
            log("waiting for snapshot to complete")
        log(f"snahpshot {snapshot_name} completed")

    def test_snapshot_while_waiting_for_it_to_complete(self):
        zone = self.zone
        disk_id = "testing-instance"
        snapshot_name = "testing-snapshot"
        take_snapshot_for_disk(zone, self.project_id, disk_id, snapshot_name)
        self.wait_while_snapshot_is_being_created(snapshot_name)
        log(f"snahpshot {snapshot_name} completed")
        delete_snapshot(self.project_id, snapshot_name)

    def test_disk_creation_waiting_for_it_to_complete(self):
        zone = self.zone
        disk_id = "testing-instance"
        snapshot_name = "testing-snapshot"
        take_snapshot_for_disk(zone, self.project_id, disk_id, snapshot_name)
        self.wait_while_snapshot_is_being_created(snapshot_name)
        log(f"snahpshot {snapshot_name} completed")
        disk_size = get_disk_size_from_disk(self.project_id, zone, disk_id)
        convert_snapshot_to_disk_volume(self.project_id, snapshot_name, "testing-disk-for-scanning", zone, disk_size)

    def test_create_and_delete_instance(self):
        # create_gcp_instance("unit-testing-instance", self.project_id, self.zone)
        delete_gcp_instance("unit-testing-instance", self.project_id, self.zone)

    def test_get_instances_with_disks_attached_less_than_given_limit(self):
        instances = get_instances_with_disks_attached_less_than_given_limit(project_id=self.project_id, zone=self.zone,
                                                                            tags=["scanners"], max_slots=18)
        assert len(instances) == 0

    def test_get_instances_with_disks_attached_less_than_given_limit_with_tags(self):
        time_tag = f"scanners-{int(time.time())}"
        update_tags_for_instance(self.project_id, self.zone, "scanning-taking-instance", [time_tag])
        instances = get_instances_with_disks_attached_less_than_given_limit(project_id=self.project_id, zone=self.zone,
                                                                            tags=[time_tag], max_slots=18)
        assert len(instances) == 1

    def test_attach_given_disk_to_instance(self):
        try:
            attach_given_disk_to_instance(self.project_id, self.zone, "scanning-taking-instance",
                                          "disk-snapshot-taking-instance-1667895077")
            self.assertTrue(True)
        except:
            log(traceback.format_exc())
            self.assertTrue(False)

    def test_create_compute(self):
        create_gcp_instance(name=("snapshot-taking-instance"), project_id=self.project_id, zone=self.zone)
        create_gcp_instance(name="scanning-taking-instance", project_id=self.project_id, zone=self.zone,
                            tags=["scanners"])

    def test_validate_gcp_instance(self):
        response = validate_gcp_instance(self.project_id, self.zone, "scanning-taking-instance",
                                         "scanning-taking-instance")
        log(response)

    def test_delete_compute(self):
        delete_gcp_instance("snapshot-taking-instance", self.project_id, self.zone)
        delete_gcp_instance("scanning-taking-instance", self.project_id, self.zone)

    def test_delete_all_not_used_by(self):
        disks = list_all_disk_not_used_by(self.project_id, self.zone)
        for disk in disks:
            delete_disk(self.project_id, self.zone, disk.name)
