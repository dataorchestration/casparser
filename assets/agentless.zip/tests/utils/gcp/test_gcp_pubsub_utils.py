import time
import unittest

from logger.custom_logging import log
from utils.gcp.utils_gcp_queue import create_pubsub_topic, delete_pubsub_topic, send_message_to_topic, \
    fetch_single_message_from_pubsub_queue, create_pubsub_topic_if_not_exists, \
    check_if_event_is_available_in_pubsub_queue, create_subscription_if_not_exists


class TestPubSubUtils(unittest.TestCase):
    """Test PubSubUtils class."""

    def setUp(self) -> None:
        self.project_id = "electionscraping"
        self.zone = "asia-south1-c"

    def tearDown(self) -> None:
        pass

    def test_creation_deletion(self):
        create_pubsub_topic_if_not_exists(topic_name="test_topic", project_id=self.project_id)
        delete_pubsub_topic(topic_name="test_topic", project_id=self.project_id)

    def test_publish_and_fetch(self):
        create_pubsub_topic_if_not_exists(topic_name="test_topic", project_id=self.project_id)
        create_subscription_if_not_exists("test_topic", self.project_id)
        send_message_to_topic(topic_name="test_topic", project_id=self.project_id, message="test_message")
        while not check_if_event_is_available_in_pubsub_queue("test_topic", self.project_id):
            log("waiting for message become available")
            time.sleep(1)
        message = fetch_single_message_from_pubsub_queue("test_topic", self.project_id)
        assert message == "test_message"
        delete_pubsub_topic(topic_name="test_topic", project_id=self.project_id)
