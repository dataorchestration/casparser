import base64
import json

from google.events.cloud.pubsub.v1 import MessagePublishedData

from consumer.base_consumer import BaseConsumer
from logger.custom_logging import log


class GCPPubSubConsumer(BaseConsumer):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def get_queue_name_from_source(self, source):
        return source.split("/")[-1]

    def handle_input_message(self, data):
        """we will be handling cloud events, we will be setting
        queuename,
        raw_data
        original_json
        example json message is like this
        {
          'attributes': {
            'specversion': '1.0',
            'id': '6161074933123473',
            'source': '//pubsub.googleapis.com/projects/electionscraping/topics/dataorc-test-function-volume-scanning-trigger-topic',
            'type': 'google.cloud.pubsub.topic.v1.messagePublished',
            'datacontenttype': 'application/json',
            'time': '2022-11-06T09:45:55.603Z'
          },
          'data': {
            'message': {
              'data': 'eyJ2b2x1bWVfaWQiOiJzbmFwc2hvdF90YWtpbmdfaW5zdGFuY2UiLCJpbnN0YW5jZV9pZCI6InNuYXBzaG90X3Rha2luZ19pbnN0YW5jZSJ9',
              'messageId': '6161074933123473',
              'message_id': '6161074933123473',
              'publishTime': '2022-11-06T09:45:55.603Z',
              'publish_time': '2022-11-06T09:45:55.603Z'
            },
            'subscription': 'projects/electionscraping/subscriptions/eventarc-asia-southeast1-function-volume-scanning-trigger-427495-sub-628'
          }
        }
        """
        log("handling input message {}".format(data))
        self.queue_name = self.get_queue_name_from_source(data.get("attributes", {}).get("source", ""))
        self.json_data = self.get_event_data_from_data(data)
        self.original_json = data
        self.output_json = {}

    def output_handler(self):
        pass

    def apply(self):
        pass

    def apply_filter(self):
        pass

    def trigger_function(self):
        pass

    def get_event_data_from_data(self, data):
        message_data = MessagePublishedData(message=data, subscription=data.get("data", {}).get("subscription", ""))
        base64encoded_data = message_data.message.data["message"]["data"]
        decoded_data = json.loads(base64.b64decode(base64encoded_data))
        log("decoded data is {}".format(decoded_data))
        return decoded_data
