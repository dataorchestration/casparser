from datetime import datetime

from funcy import merge

from consumer.gcp_consumer.consumer_pubsub import GCPPubSubConsumer
from handlers.failure.RaiseExceptionHandler import RaiseException
from logger.custom_logging import log
from messages.message_ec2_disk_attachment import Ec2InstancesDiskAttachment
from messages.message_ec2_disk_creation import DiskCreationInProgress
from utils.gcp.utils_gcp_compute import check_if_disk_creation_completed, \
    get_instances_with_disks_attached_less_than_given_limit, \
    attach_given_disk_to_instance, is_disk_already_attached_to_given_instance
from utils.gcp.utils_gcp_queue import send_message_to_topic


class GCPPubSubConsumerVolumeAttachment(GCPPubSubConsumer):
    """GCP Pub/Sub Consumer Compute Listing"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(GCPPubSubConsumerVolumeAttachment, self).handle_input_message(data)

    def output_handler(self):
        # get from config or apply here
        if self.output_json is not None:
            send_message_to_topic(self.consumer_config["project_id"], self.consumer_config["output_topic_name"],
                                  self.output_json)

    def apply_filter(self) -> bool:
        """ we need to check is
        """
        disk_created = DiskCreationInProgress()
        disk_created.from_dict(self.json_data)
        return check_if_disk_creation_completed(self.consumer_config.get("project_id"),
                                                self.consumer_config.get("zone"), disk_created.volume_name)

    def apply(self) -> dict:
        """"
        we will receive disk creation message, we will now try to attach.
        we will assume that instance to attach to is ready
        """
        log("processing disk creation: {}".format(self.json_data))
        disk_created = DiskCreationInProgress()
        disk_created.from_dict(self.json_data)
        compute_available = get_instances_with_disks_attached_less_than_given_limit(
            self.consumer_config.get("project_id"),
            self.consumer_config.get("zone"),
            self.consumer_config.get("tags"),
            int(self.consumer_config.get("max_slots", 18)))
        if len(compute_available) == 0:
            RaiseException("No compute available")
        else:
            # we will take first one
            instance = compute_available[0]
            if not is_disk_already_attached_to_given_instance(self.consumer_config.get("project_id"),
                                                              self.consumer_config.get("zone"),
                                                              instance.name, disk_created.volume_name):
                attach_given_disk_to_instance(self.consumer_config.get("project_id"), self.consumer_config.get("zone"),
                                              instance.name, disk_created.volume_name)
                diskattachment = Ec2InstancesDiskAttachment()
                diskattachment.from_dict(
                    merge({"instance_name": instance.name, "project_id": self.consumer_config.get("project_id"),
                           "zone": self.consumer_config.get("zone"), "volume_name": disk_created.volume_name,
                           "disk_size_gb": disk_created.disk_size_gb, "attachment_time": datetime.now().isoformat(),
                           "dest_volume_name": disk_created.dest_volume_name}))
                self.output_json = diskattachment.to_json()
                return self.output_json

    def failure_handler(self):
        RaiseException("Snapshot still in progress")
