from datetime import datetime

from google.events.cloud.pubsub.v1 import MessagePublishedData

from consumer.gcp_consumer.consumer_pubsub import GCPPubSubConsumer
from logger.custom_logging import log
from messages.message_ec2_scanning_info import InstanceVolumeToScan
from utils.gcp.utils_gcp_compute import get_root_volume_for_instance_id
from utils.gcp.utils_gcp_queue import send_message_to_topic


class NewGCPComputeConsumer(GCPPubSubConsumer):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(NewGCPComputeConsumer, self).handle_input_message(data)

    def output_handler(self):
        # get from config or apply here
        send_message_to_topic(self.consumer_config["project_id"], self.consumer_config["output_topic_name"],
                              self.output_json)

    def apply_filter(self) -> bool:
        """we will be filtering out the events which are not related to
        compute listing, though by default it is true always, but can be a filter of
        invalid ids
        """
        # apply validate for volume and instance id
        return True

    def get_event_data_from_data(self, data):
        message_data = MessagePublishedData(message=data, subscription=data.get("data", {}).get("subscription", ""))
        log("event proto payload is {} of type {}".format(message_data.message.data,
                                                          type(message_data.message.data)))
        data = message_data.message.data
        return dict(data)

    def get_queue_name_from_source(self, source):
        return ""

    def apply(self) -> dict:
        log("processing instance: {}".format(self.json_data))
        # json data will be eventarch of protoPayload and method name of beta.compute.instances.start
        instance_name = self.json_data.get("protoPayload", {}).get("resourceName", "").split("/")[-1]
        zone_name = self.json_data.get("protoPayload", {}).get("resourceName", "").split("/")[-3]
        log("instance name is {} and zone is {}".format(instance_name, zone_name))
        disk_name = get_root_volume_for_instance_id(self.consumer_config.get("project_id"), zone_name, instance_name)
        dest_volume_name = f"{instance_name}:uptycs-vol-eventarc_triggered-{datetime.now().strftime('%s')}"
        dest_snapshot_name = f"{instance_name}:uptycs-snap-eventarc_triggered-{datetime.now().strftime('%s')}"
        instance_volume_to_scan = InstanceVolumeToScan(instance_name=instance_name, volume_name=disk_name,
                                                       dest_volume_name=dest_volume_name,
                                                       dest_snapshot_name=dest_snapshot_name)
        self.output_json = instance_volume_to_scan.to_json()
