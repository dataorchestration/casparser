from consumer.gcp_consumer.consumer_pubsub import GCPPubSubConsumer
from logger.custom_logging import log
from messages.message_ec2_scanning_info import InstanceVolumeToScan
from messages.message_ec2_snapshot_in_progress import SnapshotInProgress
from utils.gcp.utils_gcp_compute import take_snapshot_for_disk, validate_gcp_instance, get_disk_size_from_disk
from utils.gcp.utils_gcp_queue import send_message_to_topic


class GCPPubSubConsumerComputeListing(GCPPubSubConsumer):
    """GCP Pub/Sub Consumer Compute Listing"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(GCPPubSubConsumerComputeListing, self).handle_input_message(data)

    def output_handler(self):
        # get from config or apply here
        send_message_to_topic(self.consumer_config["project_id"], self.consumer_config["output_topic_name"],
                              self.output_json)

    def apply_filter(self) -> bool:
        """we will be filtering out the events which are not related to
        compute listing, though by default it is true always, but can be a filter of
        invalid ids
        """
        # apply validate for volume and instance id
        instanceVolumeToScan = InstanceVolumeToScan()
        instanceVolumeToScan.from_dict(self.json_data)
        log("validating instance: {} for disk : {}".format(instanceVolumeToScan.instance_name,
                                                           instanceVolumeToScan.volume_name))
        return validate_gcp_instance(self.consumer_config.get("project_id"), self.consumer_config.get("zone"),
                                     instanceVolumeToScan.instance_name, instanceVolumeToScan.volume_name)

    def create_snapshot_for_instance(self, project_id, zone, volume_name, snapshot_name) -> SnapshotInProgress:
        disk_size = get_disk_size_from_disk(project_id, zone, volume_name)
        take_snapshot_for_disk(zone, project_id, volume_name, snapshot_name)
        # push message to pubsub
        message = SnapshotInProgress(snapshot_name=snapshot_name, volume_name=volume_name, project_id=project_id,
                                     zone=zone, disk_size_gb=disk_size)
        return message

    def apply(self) -> dict:
        """"
        we will receive one message for one instance, so we will be creating snapshot for each instance
        {"instance_id": "gkc_1", "volume_id": "gkc_1_vol"},
        """
        log("processing instance: {}".format(self.json_data))
        instanceVolumeToScan = InstanceVolumeToScan()
        instanceVolumeToScan.from_dict(self.json_data)
        # create the snapshot of the instance
        message = self.create_snapshot_for_instance(
            self.consumer_config.get("project_id"), self.consumer_config.get("zone"), instanceVolumeToScan.volume_name,
            instanceVolumeToScan.dest_snapshot_name)
        message.dest_volume_name = instanceVolumeToScan.dest_volume_name
        self.output_json = message.to_json()
        return self.output_json
