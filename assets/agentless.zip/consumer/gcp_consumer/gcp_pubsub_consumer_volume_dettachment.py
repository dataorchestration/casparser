from consumer.gcp_consumer.consumer_pubsub import GCPPubSubConsumer
from handlers.failure.RaiseExceptionHandler import RaiseException
from logger.custom_logging import log
from messages.message_ec2_disk_deletion_complete_info import DiskDeletionComplete
from messages.message_ec2_disk_dettachment import InstanceVolumeDetachment
from utils.gcp.utils_gcp_compute import detach_disk_from_instance, \
    delete_gcp_disk
from utils.gcp.utils_gcp_queue import send_message_to_topic


class GCPPubSubConsumerVolumeDettachment(GCPPubSubConsumer):
    """GCP Pub/Sub Consumer Compute Listing"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(GCPPubSubConsumerVolumeDettachment, self).handle_input_message(data)

    def output_handler(self):
        # get from config or apply here
        if self.output_json is not None:
            send_message_to_topic(self.consumer_config["project_id"], self.consumer_config["output_topic_name"],
                                  self.output_json)

    def apply_filter(self) -> bool:
        """ here we know whenever we get it, its ready for detach and delete
        """
        return True

    def apply(self) -> dict:
        """"
        we will receive disk creation message, we will now try to attach.
        we will assume that instance to attach to is ready
        """
        log("processing disk detaching: {}".format(self.json_data))
        disk_detachment = InstanceVolumeDetachment()
        disk_detachment.from_dict(self.json_data)
        log("we are detaching disk: {}".format(disk_detachment.volume_name))
        detach_disk_from_instance(self.consumer_config.get("project_id"), self.consumer_config.get("zone"),
                                  disk_detachment.instance_name, disk_detachment.volume_name)
        log("disk detached: {}".format(disk_detachment.volume_name))
        log("we are deleting disk: {}".format(disk_detachment.volume_name))
        delete_gcp_disk(self.consumer_config.get("project_id"), self.consumer_config.get("zone"),
                        disk_detachment.volume_name)
        log("disk deleted: {}".format(disk_detachment.volume_name))
        disk_deletion = DiskDeletionComplete(volume_name=disk_detachment.volume_name)
        self.output_json = disk_deletion.to_json()

    def failure_handler(self):
        RaiseException("Snapshot still in progress")
