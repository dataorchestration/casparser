import json

from consumer.base_consumer import BaseConsumer
from handlers.failure.RaiseExceptionHandler import RaiseException
from logger.custom_logging import log, log_error


class AzureServiceBusConsumer(BaseConsumer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def get_queue_name_from_source(self, source):
        return source.split("/")[-1]

    def handle_input_message(self, data):
        """we will be handling cloud events, we will be setting
        queuename,
        raw_data
        original_json
        example json message is like this
       {
        'message_id': msg.message_id,
        'body': msg.get_body().decode('utf-8'),
        'content_type': msg.content_type,
        'expiration_time': msg.expiration_time,
        'label': msg.label,
        'partition_key': msg.partition_key,
        'reply_to': msg.reply_to,
        'reply_to_session_id': msg.reply_to_session_id,
        'scheduled_enqueue_time': msg.scheduled_enqueue_time,
        'session_id': msg.session_id,
        'time_to_live': msg.time_to_live,
        'to': msg.to,
        'user_properties': msg.user_properties,
        'metadata' : msg.metadata
    }
        """
        log("handling input message {}".format(data))
        self.json_data = self.get_event_data_from_data(data)
        self.original_json = data
        self.output_json = {}

    def output_handler(self):
        pass

    def apply(self):
        pass

    def apply_filter(self):
        pass

    def trigger_function(self):
        pass

    def failure_handler(self):
        log_error(f"failure for current class of type {type(self)} with attributes {self.__dict__}")
        raise RaiseException(f"failure for current class of type {type(self)} with attributes {self.__dict__}")

    def get_event_data_from_data(self, data):
        raw_message = data.message
        self.json_data = json.loads(str(raw_message))
        return self.json_data
