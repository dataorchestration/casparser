from consumer.azure_consumer.azure_consumer_service_bus import AzureServiceBusConsumer
from logger.custom_logging import log
from messages.message_ec2_scanning_info import InstanceVolumeToScan
from messages.message_ec2_snapshot_in_progress import SnapshotInProgress
from utils.azure.utils_compute import azure_create_snapshot_from_disk_name, azure_check_if_disk_exists
from utils.azure.utils_service_bus import send_message_to_service_bus_topic


class AzureServiceBusConsumerComputeListing(AzureServiceBusConsumer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(AzureServiceBusConsumerComputeListing, self).handle_input_message(data)

    def output_handler(self):
        log("sending message to service bus topic: {}".format(self.output_json))
        send_message_to_service_bus_topic(self.consumer_config.get("output_service_bus_connection_string"),
                                          self.consumer_config.get("output_topic_name"),
                                          self.output_json)

    def apply_filter(self):
        # check is volume id(name) is present
        instanceVolumeToScan = InstanceVolumeToScan()
        instanceVolumeToScan.from_dict(self.json_data)
        log("validating instance: {} for disk : {}".format(instanceVolumeToScan.instance_name,
                                                           instanceVolumeToScan.volume_name))
        return azure_check_if_disk_exists(resource_group_name=self.consumer_config.get("resource_group_name"),
                                          subscription_id=self.consumer_config.get("subscription_id"),
                                          client_id=self.consumer_config.get("client_id"),
                                          tenant_id=self.consumer_config.get("tenant_id"),
                                          client_secret=self.consumer_config.get("client_secret"),
                                          disk_name=instanceVolumeToScan.volume_name)

    def apply(self):
        log("we will be receiving compute listing data here")
        instanceVolumeToScan = InstanceVolumeToScan()
        instanceVolumeToScan.from_dict(self.json_data)
        log("validating instance: {} for disk : {}".format(instanceVolumeToScan.instance_name,
                                                           instanceVolumeToScan.volume_name))
        # create snapshot for the instance
        azure_create_snapshot_from_disk_name(resource_group_name=self.consumer_config.get("resource_group_name"),
                                             subscription_id=self.consumer_config.get("subscription_id"),
                                             client_id=self.consumer_config.get("client_id"),
                                             tenant_id=self.consumer_config.get("tenant_id"),
                                             client_secret=self.consumer_config.get("client_secret"),
                                             disk_name=instanceVolumeToScan.volume_name,
                                             snapshot_name=instanceVolumeToScan.dest_snapshot_name,
                                             location=self.consumer_config.get("region"))

        # push the snapshot name to the queue for creation of sas url
        snapshot_in_progress = SnapshotInProgress(instanceVolumeToScan.dest_snapshot_name,
                                                  instanceVolumeToScan.volume_name,
                                                  dest_volume_name=instanceVolumeToScan.dest_volume_name)
        self.output_json = snapshot_in_progress.to_json()
