import datetime

from consumer.azure_consumer.azure_consumer_service_bus import AzureServiceBusConsumer
from logger.custom_logging import log
from messages.message_ec2_snapshot_copy_in_progress import SnapshotCopyInProgress
from messages.message_ec2_snapshot_in_progress import SnapshotInProgress
from utils.azure.utils_compute import azure_create_sas_url, \
    copy_snapshot_blob_from_sas_url_to_blob_storage, azure_check_if_snapshot_is_ready
from utils.azure.utils_service_bus import send_message_to_service_bus_topic


class AzureServiceBusConsumerCopyDisk(AzureServiceBusConsumer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(AzureServiceBusConsumerCopyDisk, self).handle_input_message(data)

    def output_handler(self):
        log("sending message to service bus topic: {}".format(self.output_json))
        send_message_to_service_bus_topic(self.consumer_config.get("output_service_bus_connection_string"),
                                          self.consumer_config.get("output_topic_name"),
                                          self.output_json)

    def apply_filter(self):
        snapshotInProgress = SnapshotInProgress()
        snapshotInProgress.from_dict(self.json_data)
        return azure_check_if_snapshot_is_ready(resource_group_name=self.consumer_config.get("resource_group_name"),
                                                subscription_id=self.consumer_config.get("subscription_id"),
                                                client_id=self.consumer_config.get("client_id"),
                                                tenant_id=self.consumer_config.get("tenant_id"),
                                                client_secret=self.consumer_config.get("client_secret"),
                                                snapshot_name=snapshotInProgress.snapshot_name)

    def apply(self):
        log("we will be receiving copy disk data here")
        snapshotInProgress = SnapshotInProgress()
        snapshotInProgress.from_dict(self.json_data)
        # create sas url for the snapshot
        original_sas_url = azure_create_sas_url(resource_group_name=self.consumer_config.get("resource_group_name"),
                                                subscription_id=self.consumer_config.get("subscription_id"),
                                                client_id=self.consumer_config.get("client_id"),
                                                tenant_id=self.consumer_config.get("tenant_id"),
                                                client_secret=self.consumer_config.get("client_secret"),
                                                snapshot_name=snapshotInProgress.snapshot_name
                                                )
        blob_name = snapshotInProgress.snapshot_name + f"{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}" + ".vhd"
        copy_snapshot_blob_from_sas_url_to_blob_storage(sas_url=original_sas_url,
                                                        dest_container_name=self.consumer_config.get(
                                                            "container_name"),
                                                        dest_blob_name=blob_name,
                                                        subscription_id=self.consumer_config.get(
                                                            "subscription_id"),
                                                        client_id=self.consumer_config.get(
                                                            "client_id"),
                                                        tenant_id=self.consumer_config.get(
                                                            "tenant_id"),
                                                        client_secret=self.consumer_config.get(
                                                            "client_secret"),
                                                        snapshot_storage_connection_string=self.consumer_config.get(
                                                            "snapshot_storage_connection_string")
                                                        )

        # push the snapshot name to the queue for creation of sas url
        snapshot_copy_in_progress = SnapshotCopyInProgress(blob_name=blob_name,
                                                           dest_volume_name=snapshotInProgress.dest_volume_name,
                                                           container_name=self.consumer_config.get("container_name")
                                                           )
        self.output_json = snapshot_copy_in_progress.to_json()
