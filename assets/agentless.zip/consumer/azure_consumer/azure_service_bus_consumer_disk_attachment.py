import os

from consumer.azure_consumer.azure_consumer_service_bus import AzureServiceBusConsumer
from logger.custom_logging import log
from messages.message_ec2_disk_attachment import Ec2InstancesDiskAttachment
from utils.azure.utils_compute import azure_check_if_disk_is_created, azure_get_number_of_disks_attached_to_vm, \
    azure_attach_disk_to_vm
from utils.azure.utils_service_bus import send_message_to_service_bus_topic


class AzureServiceBusConsumerDiskAttachment(AzureServiceBusConsumer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(AzureServiceBusConsumerDiskAttachment, self).handle_input_message(data)

    def output_handler(self):
        log("sending message to service bus topic: {}".format(self.output_json))
        return True

    def apply_filter(self):
        snapshotCopyInProgress = Ec2InstancesDiskAttachment()
        snapshotCopyInProgress.from_dict(self.json_data)
        disk_created = azure_check_if_disk_is_created(subscription_id=self.consumer_config.get("subscription_id"),
                                                      client_id=self.consumer_config.get("client_id"),
                                                      tenant_id=self.consumer_config.get("tenant_id"),
                                                      client_secret=self.consumer_config.get("client_secret"),
                                                      resource_group_name=self.consumer_config.get(
                                                          "resource_group_name"),
                                                      disk_name=snapshotCopyInProgress.dest_volume_name)
        if disk_created:
            # check if this node have free disk slots
            log(f"checking if slots are available")
            # number of disks attached to this VM
            num_disk_attached = azure_get_number_of_disks_attached_to_vm(
                subscription_id=self.consumer_config.get("subscription_id"),
                client_id=self.consumer_config.get("client_id"),
                tenant_id=self.consumer_config.get("tenant_id"),
                client_secret=self.consumer_config.get("client_secret"),
                resource_group_name=self.consumer_config.get("resource_group_name"),
                vm_name=os.getenv("CURRENT_VM_NAME", "vm1")
            )
            # number of disks that can be attached to this VM
            if num_disk_attached < int(os.getenv("max_disks_attached", 18)):
                log(f"slots are available")
                return True
            else:
                log(f"slots are not available")
                return False
        else:
            return False

    def apply(self):
        log("we will be receiving disk attachment data here")
        ec2InstancesDiskAttachment = Ec2InstancesDiskAttachment()
        ec2InstancesDiskAttachment.from_dict(self.json_data)

        disk_name = f'/subscriptions/{self.consumer_config.get("subscription_id")}/resourceGroups/{self.consumer_config.get("resource_group_name")}/providers/Microsoft.Compute/disks/{ec2InstancesDiskAttachment.dest_volume_name}'
        azure_attach_disk_to_vm(resource_group_name=self.consumer_config.get("resource_group_name"),
                                subscription_id=self.consumer_config.get("subscription_id"),
                                client_id=self.consumer_config.get("client_id"),
                                tenant_id=self.consumer_config.get("tenant_id"),
                                client_secret=self.consumer_config.get("client_secret"),
                                disk_id=disk_name, vm_name=os.getenv("CURRENT_VM_NAME"))
        log("disk attached to VM")
