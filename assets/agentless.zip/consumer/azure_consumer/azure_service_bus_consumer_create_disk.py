from consumer.azure_consumer.azure_consumer_service_bus import AzureServiceBusConsumer
from logger.custom_logging import log
from messages.message_ec2_disk_attachment import Ec2InstancesDiskAttachment
from messages.message_ec2_snapshot_copy_in_progress import SnapshotCopyInProgress
from utils.azure.utils_compute import check_if_bob_status_is_completed, \
    create_disk_from_snapshot_sas_url
from utils.azure.utils_service_bus import send_message_to_service_bus_topic


class AzureServiceBusConsumerCreateDisk(AzureServiceBusConsumer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(AzureServiceBusConsumerCreateDisk, self).handle_input_message(data)

    def output_handler(self):
        log("sending message {} to service bus topic: {}".format(self.output_json,
                                                                 self.consumer_config.get("output_topic_name")))
        send_message_to_service_bus_topic(self.consumer_config.get("output_service_bus_connection_string"),
                                          self.consumer_config.get("output_topic_name"),
                                          self.output_json)

    def apply_filter(self):
        snapshotCopyInProgress = SnapshotCopyInProgress()
        snapshotCopyInProgress.from_dict(self.json_data)
        return check_if_bob_status_is_completed(subscription_id=self.consumer_config.get("subscription_id"),
                                                client_id=self.consumer_config.get("client_id"),
                                                tenant_id=self.consumer_config.get("tenant_id"),
                                                client_secret=self.consumer_config.get("client_secret"),
                                                storage_connection_string=self.consumer_config.get(
                                                    "snapshot_storage_connection_string"),
                                                blob_name=snapshotCopyInProgress.blob_name,
                                                container_name=self.consumer_config.get("container_name"))

    def apply(self):
        log("we will be receiving create disk data here")
        snapshotCopyInProgress = SnapshotCopyInProgress()
        snapshotCopyInProgress.from_dict(self.json_data)
        sas_url = f'https://{self.consumer_config.get("snapshot_storage_name")}.blob.core.windows.net/{self.consumer_config.get("container_name")}/{snapshotCopyInProgress.blob_name}'
        create_disk_from_snapshot_sas_url(
            resource_group_name=self.consumer_config.get("resource_group_name"),
            subscription_id=self.consumer_config.get("subscription_id"),
            client_id=self.consumer_config.get("client_id"),
            tenant_id=self.consumer_config.get("tenant_id"),
            client_secret=self.consumer_config.get("client_secret"),
            sas_url=sas_url,
            disk_name=snapshotCopyInProgress.dest_volume_name,
            location=self.consumer_config.get("region"),
            snapshot_storage_name=self.consumer_config.get("snapshot_storage_name"))

        ec2InstancesDiskAttachment = Ec2InstancesDiskAttachment()
        ec2InstancesDiskAttachment.dest_volume_name = snapshotCopyInProgress.dest_volume_name
        self.output_json = ec2InstancesDiskAttachment.to_json()
