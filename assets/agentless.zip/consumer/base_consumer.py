class BaseConsumer():

    def __init__(self, *args, **kwargs):
        self.queue_name = None
        self.json_data = None
        self.original_json = None
        self.output_json = None

    def handle_input_message(self, data: dict):
        raise NotImplementedError()

    def output_handler(self):
        raise NotImplementedError()

    def apply(self) -> dict:
        """process and transform the data"""
        raise NotImplementedError()

    def apply_filter(self) -> bool:
        raise NotImplementedError()

    def failure_handler(self):
        raise NotImplementedError()
