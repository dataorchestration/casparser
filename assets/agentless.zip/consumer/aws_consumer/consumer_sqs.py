import json

from consumer.base_consumer import BaseConsumer
from logger.custom_logging import log


class AWSSQSConsumer(BaseConsumer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def __get_queue_name_from_source(self, source):
        return source.split(":")[-1]

    def handle_input_message(self, data):
        """
        {
          "Records": [
            {
              "messageId": "19dd0b57-b21e-4ac1-bd88-01bbb068cb78",
              "receiptHandle": "MessageReceiptHandle",
              "body": "Hello from SQS!",
              "attributes": {
                "ApproximateReceiveCount": "1",
                "SentTimestamp": "1523232000000",
                "SenderId": "123456789012",
                "ApproximateFirstReceiveTimestamp": "1523232000001"
              },
              "messageAttributes": {},
              "md5OfBody": "7b270e59b47ff90a553787216d55d91d",
              "eventSource": "aws:sqs",
              "eventSourceARN": "arn:aws:sqs:ap-southeast-2:123456789012:MyQueue",
              "awsRegion": "ap-southeast-2"
            }
          ]
        }
        :param data:
        :return:
        """
        log("handling input message {}".format(data))
        self.queue_name = self.__get_queue_name_from_source(
            next(iter(data.get("Records", [])), {}).get("eventSourceARN", ""))
        self.json_data = self.__get_event_data_from_data(data)
        self.original_json = data
        self.output_json = {}

    def output_handler(self):
        pass

    def apply(self):
        pass

    def apply_filter(self):
        pass

    def trigger_function(self):
        pass

    def __get_event_data_from_data(self, data):
        if 'Records' in data and len(data['Records']) > 0:
            return json.loads(data['Records'][0]['body'])
        else:
            raise Exception
