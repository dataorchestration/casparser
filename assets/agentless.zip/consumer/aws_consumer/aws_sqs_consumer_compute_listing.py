from consumer.aws_consumer.consumer_sqs import AWSSQSConsumer
from handlers.failure.RaiseExceptionHandler import RaiseException
from logger.api_logging import APILogMessage
from logger.custom_logging import log
from logger.sqs_logging import SQSLogMessage, ActionType
from messages.message_ec2_scanning_info import InstanceVolumeToScan
from messages.message_ec2_snapshot_in_progress import SnapshotInProgress
from utils.aws.utils_compute import aws_validate_instance, aws_take_snapshot
from utils.aws.utils_sqs import send_message_to_sqs


class AWSSQSConsumerComputeListing(AWSSQSConsumer):
    """GCP Pub/Sub Consumer Compute Listing"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(AWSSQSConsumerComputeListing, self).handle_input_message(data)

    def output_handler(self):
        # get from config or apply here
        send_message_to_sqs(account_id=self.consumer_config["account_id"],
                            region_name=self.consumer_config["region"],
                            queue_name=self.consumer_config["output_topic_name"],
                            message=self.output_json)

    def apply_filter(self) -> bool:
        """we will be filtering out the events which are not related to
        compute listing, though by default it is true always, but can be a filter of
        invalid ids
        """
        # apply validate for volume and instance id
        instanceVolumeToScan = InstanceVolumeToScan()
        instanceVolumeToScan.from_dict(self.json_data)
        log("validating instance: {} for disk : {}".format(instanceVolumeToScan.instance_name,
                                                           instanceVolumeToScan.volume_name))
        return aws_validate_instance(self.consumer_config.get("account_id"), self.consumer_config.get("region"),
                                     instanceVolumeToScan.instance_name, instanceVolumeToScan.volume_name)

    def create_snapshot_for_instance(self, account_id, region, volume_name, snapshot_name,
                                     instance_id) -> SnapshotInProgress:
        response = aws_take_snapshot(account_id, region, volume_name, snapshot_name)
        # push message to pubsub
        message = SnapshotInProgress(snapshot_name=response["snapshot_id"], volume_name=volume_name,
                                     account_id=account_id,
                                     region=region, disk_size_gb=response["disk_size"],
                                     original_instance_id=instance_id)
        return message

    def apply(self) -> dict:
        """"
        we will receive one message for one instance, so we will be creating snapshot for each instance
        {"instance_id": "gkc_1", "volume_id": "gkc_1_vol"},
        """
        log("processing instance: {}".format(self.json_data))
        instanceVolumeToScan = InstanceVolumeToScan()
        instanceVolumeToScan.from_dict(self.json_data)
        # create the snapshot of the instance
        SQSLogMessage(instanceVolumeToScan.instance_name,
                      instanceVolumeToScan.volume_name,
                      instanceVolumeToScan.asset_id,
                      action=ActionType.CREATE_SNAPSHOT).send_to_sqs()
        APILogMessage(instanceVolumeToScan.instance_name,
                      instanceVolumeToScan.volume_name,
                      instanceVolumeToScan.asset_id,
                      action=ActionType.CREATE_SNAPSHOT).send_to_endpoint()
        message = self.create_snapshot_for_instance(
            self.consumer_config.get("account_id"), self.consumer_config.get("region"),
            instanceVolumeToScan.volume_name,
            instanceVolumeToScan.dest_snapshot_name, instanceVolumeToScan.instance_name)
        message.dest_volume_name = instanceVolumeToScan.dest_volume_name
        message.aws_job_id = instanceVolumeToScan.aws_job_id
        self.output_json = message.to_json()
        return self.output_json

    def failure_handler(self):
        RaiseException("invalid instance received")
        instanceVolumeToScan = InstanceVolumeToScan()
        instanceVolumeToScan.from_dict(self.json_data)
        APILogMessage(instanceVolumeToScan.instance_name,
                      instanceVolumeToScan.volume_name,
                      instanceVolumeToScan.asset_id,
                      action=ActionType.INVALID_INSTANCE).send_to_endpoint()
