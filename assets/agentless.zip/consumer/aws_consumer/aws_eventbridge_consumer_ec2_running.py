import os

from consumer.aws_consumer.consumer_eventbridge_event import AWSEventBridgeConsumer
from logger.api_logging import APILogMessage, ActionType
from logger.custom_logging import log
from messages.message_ec2_scanning_info import InstanceVolumeToScan
from utils.aws.utils_compute import aws_get_all_volume_ids_attached_to_instance_id, get_root_volume_id_of_instance
from utils.aws.utils_sqs import send_message_to_sqs


class NewEC2RunningConsumer(AWSEventBridgeConsumer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def handle_input_message(self, data: dict):
        super(NewEC2RunningConsumer, self).handle_input_message(data)

    def send_message_to_sqs(self):
        if self.output_json is not None:
            log("pushing to volume scanner queue with message {}".format(self.output_json))
            send_message_to_sqs(self.consumer_config.get("ACCOUNT_ID"), self.consumer_config.get("REGION"),
                                self.output_json,
                                self.consumer_config.get("VOLUME_SCANNER_TRIGGER_QUEUE"))

    def output_handler(self):
        # get from config or apply here
        pass

    # get from config or apply here

    def apply_filter(self):
        # get from config or apply here
        return True

    def apply(self):
        ec2_resources = self.json_data.get("resources", [])
        for ec2 in ec2_resources:
            # create json volume scanner and push to volume scanner queue
            ec2_id = ec2.split("/")[-1]
            region = ec2.split(":")[3]
            log("scanning ec2 {} in region {}".format(ec2_id, region))
            volume_id = get_root_volume_id_of_instance(self.consumer_config.get("ACCOUNT_ID"),
                                                       self.consumer_config.get("REGION"), ec2_id)
            APILogMessage(ec2_id,
                          volume_id,
                          "new_instance_spawned",
                          action=ActionType.NEW_INSTANCE).send_to_endpoint()
            log("scanning volume {} in region {}".format(volume_id, region))
            # check if it is a root volume
            volume_to_scan = InstanceVolumeToScan(instance_name=ec2_id, region=region,
                                                  volume_name=volume_id, dest_snapshot_name=f"snap-{volume_id}",
                                                  dest_volume_name="").to_json()
            # push to volume scanner queue
            self.output_json = volume_to_scan
            self.send_message_to_sqs()
