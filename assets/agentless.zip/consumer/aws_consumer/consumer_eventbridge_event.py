import json

from consumer.base_consumer import BaseConsumer
from logger.custom_logging import log


class AWSEventBridgeConsumer(BaseConsumer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def __get_resource_name_from_source(self, source):
        return source["source"]

    def handle_input_message(self, data):
        """
            {
      "version": "0",
      "id": "7bf73129-1428-4cd3-a780-95db273d1602",
      "detail-type": "EC2 Instance State-change Notification",
      "source": "aws.ec2",
      "account": "123456789012",
      "time": "2015-11-11T21:29:54Z",
      "region": "us-east-1",
      "resources": ["arn:aws:ec2:us-east-1:123456789012:instance/i-abcd1111"],
      "detail": {
        "instance-id": "i-abcd1111",
        "state": "running"
      }
    }
        :param data:
        :return:
        """
        log("handling input message {}".format(data))
        self.resource_name = self.__get_resource_name_from_source(data)
        self.json_data = self.__get_event_data_from_data(data)
        self.original_json = data
        self.output_json = {}

    def output_handler(self):
        pass

    def apply(self):
        pass

    def apply_filter(self):
        pass

    def trigger_function(self):
        pass

    def __get_event_data_from_data(self, data):
        return data
