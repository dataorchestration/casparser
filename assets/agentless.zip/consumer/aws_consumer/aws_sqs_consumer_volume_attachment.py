import json
from datetime import datetime

from funcy import merge

from consumer.aws_consumer.consumer_sqs import AWSSQSConsumer
from handlers.failure.RaiseExceptionHandler import RaiseException
from logger.api_logging import APILogMessage
from logger.custom_logging import log
from logger.sqs_logging import SQSLogMessage, ActionType
from messages.message_ec2_disk_attachment import Ec2InstancesDiskAttachment
from messages.message_ec2_disk_creation import DiskCreationInProgress
from utils.aws.utils_compute import aws_check_if_disk_creation_completed, \
    aws_get_instances_with_disks_attached_less_than_given_limit, in_aws_is_disk_already_attached_to_given_instance, \
    aws_attach_disk_to_instance, \
    add_tags_to_given_instance, wait_till_instance_tag_is_assigned
from utils.aws.utils_sqs import send_message_to_sqs


class AWSSQSConsumerVolumeAttachment(AWSSQSConsumer):
    """GCP Pub/Sub Consumer Compute Listing"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(AWSSQSConsumerVolumeAttachment, self).handle_input_message(data)

    def output_handler(self):
        # get from config or apply here
        if self.output_json is not None:
            try:
                send_message_to_sqs(account_id=self.consumer_config["account_id"],
                                    region_name=self.consumer_config["region"],
                                    queue_name=self.consumer_config["output_topic_name"],
                                    message=self.output_json)
            except:
                pass

    def apply_filter(self) -> bool:
        """ we need to check is
        """
        disk_created = DiskCreationInProgress()
        disk_created.from_dict(self.json_data)
        return aws_check_if_disk_creation_completed(self.consumer_config.get("account_id"),
                                                    self.consumer_config.get("region"), disk_created.volume_name)

    def apply(self) -> dict:
        """"
        we will receive disk creation message, we will now try to attach.
        we will assume that instance to attach to is ready
        """
        log("processing disk creation messation {}".format(self.json_data))
        disk_created = DiskCreationInProgress()
        disk_created.from_dict(self.json_data)
        compute_available = aws_get_instances_with_disks_attached_less_than_given_limit(
            self.consumer_config.get("account_id"),
            self.consumer_config.get("region"),
            self.consumer_config.get("tags"),
            int(self.consumer_config.get("max_slots", 18)), self.consumer_config.get("zone"))
        # filter for running instances
        if len(compute_available) == 0:
            RaiseException("No compute available")
        else:
            # we will take first one
            instance = compute_available[0]
            if not in_aws_is_disk_already_attached_to_given_instance(self.consumer_config.get("account_id"),
                                                                     self.consumer_config.get("region"),
                                                                     instance.instance_id, disk_created.volume_name):
                log("attaching disk {} to instance {}".format(disk_created.volume_name, instance.instance_id))
                SQSLogMessage(None,
                              disk_created.volume_name,
                              disk_created.asset_id,
                              action=ActionType.ATTACH_VOLUME, scanner_instance_id=instance.instance_id).send_to_sqs()
                APILogMessage(disk_created.original_instance_id,
                              disk_created.volume_name,
                              disk_created.asset_id,
                              action=ActionType.ATTACH_VOLUME).send_to_endpoint()
                # need to update the tags for instance
                tag_value = f"{disk_created.original_instance_id}-uptycs-vol-{disk_created.volume_name}-uptycs-job-{default_job_id}"
                tag_value_json = {"oi": disk_created.original_instance_id,
                                  "ovol": disk_created.original_volume_id,
                                  "cvol": disk_created.volume_name,
                                  "az": disk_created.zone
                                  }
                if disk_created.aws_job_id:
                    tag_value_json['jid'] =  disk_created.aws_job_id
                # minimize json to get tag value
                tag_value = json.dumps(tag_value_json, separators=(',', '#'))
                add_tags_to_given_instance(self.consumer_config.get("account_id"),
                                           self.consumer_config.get("region"),
                                           instance.instance_id, disk_created.volume_name, tag_value)
                # ensure tag is assigned or wait, though as checked this is instantaneously assigned
                wait_till_instance_tag_is_assigned(self.consumer_config.get("account_id"),
                                                   self.consumer_config.get("region"), instance.instance_id,
                                                   disk_created.volume_name)
                # we will attach disk to instance
                aws_attach_disk_to_instance(self.consumer_config.get("project_id"),
                                            self.consumer_config.get("region"),
                                            instance.instance_id, disk_created.volume_name)

                diskattachment = Ec2InstancesDiskAttachment()
                diskattachment.from_dict(
                    merge({"instance_name": instance.instance_id, "project_id": self.consumer_config.get("project_id"),
                           "zone": self.consumer_config.get("zone"), "volume_name": disk_created.volume_name,
                           "disk_size_gb": disk_created.disk_size_gb, "attachment_time": datetime.now().isoformat()}))
                self.output_json = diskattachment.to_json()
                return self.output_json

    def failure_handler(self):
        RaiseException("disk creation in progress")
