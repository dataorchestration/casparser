import os

from consumer.aws_consumer.consumer_sqs import AWSSQSConsumer
from handlers.failure.RaiseExceptionHandler import RaiseException
from logger.api_logging import APILogMessage
from logger.custom_logging import log
from logger.sqs_logging import SQSLogMessage, ActionType
from messages.message_ec2_disk_creation import DiskCreationInProgress
from messages.message_ec2_snapshot_in_progress import SnapshotInProgress
from utils.aws.utils_compute import aws_check_if_snapshot_completed, aws_convert_snapshot_to_disk_volume
from utils.aws.utils_sqs import send_message_to_sqs


class AWSSQSConsumerSnapshotWaiting(AWSSQSConsumer):
    """GCP Pub/Sub Consumer Compute Listing"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(AWSSQSConsumerSnapshotWaiting, self).handle_input_message(data)

    def output_handler(self):
        # get from config or apply here
        send_message_to_sqs(account_id=self.consumer_config["account_id"],
                            region_name=self.consumer_config["region"],
                            queue_name=self.consumer_config["output_topic_name"],
                            message=self.output_json)

    def apply_filter(self) -> bool:
        """ we need to check is
        """
        snapshot_in_progress = SnapshotInProgress()
        snapshot_in_progress.from_dict(self.json_data)
        return aws_check_if_snapshot_completed(self.consumer_config.get("account_id"),
                                               self.consumer_config.get("region"),
                                               snapshot_in_progress.snapshot_name)

    def apply(self) -> dict:
        """"
        we will receive SnapshotInProgress message, we will now initiate disk creation
        """
        log("processing snapshot: {}".format(self.json_data))
        snapshot_in_progress = SnapshotInProgress()
        snapshot_in_progress.from_dict(self.json_data)
        SQSLogMessage(None,
                      snapshot_in_progress.volume_name,
                      snapshot_in_progress.asset_id,
                      action=ActionType.CREATE_VOLUME).send_to_sqs()
        APILogMessage(snapshot_in_progress.original_instance_id,
                      snapshot_in_progress.volume_name,
                      snapshot_in_progress.asset_id,
                      action=ActionType.CREATE_VOLUME).send_to_endpoint()
        response = aws_convert_snapshot_to_disk_volume(self.consumer_config.get("account_id"),
                                                       self.consumer_config.get("region"),
                                                       snapshot_in_progress.snapshot_name,
                                                       snapshot_in_progress.dest_volume_name,
                                                       availability_zone=self.consumer_config.get("zone"),
                                                       volume_type=os.getenv("VOLUME_TYPE", "gp3"),

                                                       )
        disk_creation_message = DiskCreationInProgress(volume_name=response["volume_id"],
                                                       snapshot_name=snapshot_in_progress.snapshot_name,
                                                       account_id=self.consumer_config.get("account_id"),
                                                       disk_size_gb=response["disk_size"],
                                                       region=snapshot_in_progress.aws_region,
                                                       zone=self.consumer_config.get("zone"),
                                                       dest_volume_name=snapshot_in_progress.dest_volume_name,
                                                       aws_job_id=snapshot_in_progress.aws_job_id,
                                                       original_instance_id=snapshot_in_progress.original_instance_id,
                                                       original_volume_id=snapshot_in_progress.volume_name
                                                       )
        self.output_json = disk_creation_message.to_json()
        return self.output_json

    def failure_handler(self):
        RaiseException("Snapshot still in progress")
