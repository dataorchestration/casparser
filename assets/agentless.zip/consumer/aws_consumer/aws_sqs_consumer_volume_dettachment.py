from consumer.aws_consumer.consumer_sqs import AWSSQSConsumer
from handlers.failure.RaiseExceptionHandler import RaiseException
from logger.api_logging import APILogMessage
from logger.custom_logging import log
from logger.sqs_logging import SQSLogMessage, ActionType
from messages.message_ec2_disk_deletion_complete_info import DiskDeletionComplete
from messages.message_ec2_disk_dettachment import InstanceVolumeDetachment
from utils.aws.utils_compute import aws_detach_disk_from_instance, aws_delete_disk, wait_till_volume_is_dettached, \
    get_snapshot_id_from_volume_id, aws_delete_snapshot, remove_tags_from_given_instance
from utils.aws.utils_sqs import send_message_to_sqs


class AWSSQSConsumerVolumeDettachment(AWSSQSConsumer):
    """GCP Pub/Sub Consumer Compute Listing"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer_config = kwargs.get("consumer_config", {})

    def handle_input_message(self, data):
        super(AWSSQSConsumerVolumeDettachment, self).handle_input_message(data)

    def output_handler(self):
        # get from config or apply here
        try:
            if self.output_json is not None:
                send_message_to_sqs(account_id=self.consumer_config["account_id"],
                                    region_name=self.consumer_config["region"],
                                    queue_name=self.consumer_config["output_topic_name"],
                                    message=self.output_json)
        except:
            log("ignoring this error since this is last")

    def apply_filter(self) -> bool:
        """ here we know whenever we get it, its ready for detach and delete
        """
        return True

    def apply(self) -> dict:
        """"
        we will receive disk creation message, we will now try to attach.
        we will assume that instance to attach to is ready
        """
        log("processing disk detaching: {}".format(self.json_data))
        disk_detachment = InstanceVolumeDetachment()
        disk_detachment.from_dict(self.json_data)
        log("we are detaching disk: {}".format(disk_detachment.volume_name))

        snapshot_for_volume_deleted = get_snapshot_id_from_volume_id(self.consumer_config.get("account_id"),
                                                                     self.consumer_config.get("region"),
                                                                     disk_detachment.volume_name)
        SQSLogMessage(None,
                      disk_detachment.volume_name,
                      disk_detachment.asset_id,
                      action=ActionType.DETACH_VOLUME, scanner_instance_id=disk_detachment.instance_name).send_to_sqs()
        APILogMessage(disk_detachment.instance_name,
                      disk_detachment.volume_name,
                      disk_detachment.asset_id,
                      action=ActionType.DETACH_VOLUME).send_to_endpoint()
        aws_detach_disk_from_instance(self.consumer_config.get("account_id"), self.consumer_config.get("region"),
                                      disk_detachment.volume_name, disk_detachment.instance_name)
        log("disk detached: {}".format(disk_detachment.volume_name))
        log("we are deleting disk: {}".format(disk_detachment.volume_name))
        wait_till_volume_is_dettached(self.consumer_config.get("account_id"), self.consumer_config.get("region"),
                                      disk_detachment.volume_name)
        remove_tags_from_given_instance(self.consumer_config.get("account_id"), self.consumer_config.get("region")
                                        , disk_detachment.instance_name, disk_detachment.volume_name)
        SQSLogMessage(None,
                      disk_detachment.volume_name,
                      disk_detachment.asset_id,
                      action=ActionType.DELETE_VOLUME).send_to_sqs()
        APILogMessage(disk_detachment.instance_name,
                      disk_detachment.volume_name,
                      disk_detachment.asset_id,
                      action=ActionType.DELETE_VOLUME).send_to_endpoint()
        aws_delete_disk(self.consumer_config.get("account_id"), self.consumer_config.get("region"),
                        disk_detachment.volume_name)
        log("disk deleted: {}".format(disk_detachment.volume_name))
        log("deleting snapshot")
        SQSLogMessage(None,
                      disk_detachment.volume_name,
                      disk_detachment.asset_id,
                      action=ActionType.DELETE_SNAPSHOT).send_to_sqs()
        APILogMessage(disk_detachment.instance_name,
                      disk_detachment.volume_name,
                      disk_detachment.asset_id,
                      action=ActionType.DELETE_SNAPSHOT).send_to_endpoint()
        aws_delete_snapshot(self.consumer_config.get("account_id"), self.consumer_config.get("region"),
                            snapshot_for_volume_deleted)
        disk_deletion = DiskDeletionComplete(volume_name=disk_detachment.volume_name)
        self.output_json = disk_deletion.to_json()

    def failure_handler(self):
        RaiseException("Unknown error")
