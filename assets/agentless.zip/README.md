# Introduction

Lambda Function Framework for on premise public cloud Side query

# Architcture

1) entry_point - main.py
2) calls the relevant trigger class' entrypoint
3) trigger class entrypoint calls for configured consumer
4) Consumer class is responsible for consuming the message from the queue and processing it
    * Consumer class implements following methods:
        * input_handler - responsible for parsing the message from the queue
        * apply_filter - checks if the message should be processed
        * apply - main logic where the input is processed
        * output_handler - publishes the message to the queue or else configured

# GCP

# AWS

# Azure

1) az login
2) subscriber id (in id) - 7e0c1319-b948-4bb3-8579-67a38c4ba83c
3) az account set --subscription=7e0c1319-b948-4bb3-8579-67a38c4ba83c
4) az ad sp create-for-rbac --role="Contributor" --scopes="/subscriptions/7e0c1319-b948-4bb3-8579-67a38c4ba83c"
5) az login --service-principal -u CLIENT_ID -p CLIENT_SECRET --tenant TENANT_ID

# func init

```shell
func init agentless-scanning-orchestration --worker-runtime python
```

# publish

```shell
func azure functionapp publish azure-function-compute-list --python --build-native-deps
```

# zip cmd to build the zip

```shell
# exclude directories .git, venv-azure-func, __pycache__, .python_packages
zip -r azure-function-compute-list.zip . -x "*.git*" "*venv-azure-func*" "*__pycache__*" "*.python_packages*" "*.idea*" "*.vscode*" "*.zip*"   
```

az functionapp deployment source config-zip --resource-group uptycs-functions-resource-group --name
azure-function-compute-list --src "function-2023-05-09T12:47:51Z.zip" --build-remote true --verbose


zip -r azure-function-compute-list.zip azure_function_compute_listing/ config/ consumer/ executors/ handlers/ logger/ messages/ triggers/ utils/ host.json requirements.txt -x '*__pycache__*' 