class QueuePushBackException(Exception):
    pass


def RaiseException(message):
    raise QueuePushBackException(message)
