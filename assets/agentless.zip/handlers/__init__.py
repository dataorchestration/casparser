from handlers.output.gcp.output_handler_pubsub import PubSubOutputHandler


def get_output_handler_from_name(name):
    if name == "gcp_pubsub":
        return PubSubOutputHandler
