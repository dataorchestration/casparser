from handlers.output.base_handler import BaseHandler
from utils.gcp.utils_gcp_queue import send_message_to_topic


class PubSubOutputHandler(BaseHandler):
    def __init__(self, config):
        super().__init__(config)

    def handle(self, data):
        send_message_to_topic(self.config.get("topic"), data)
