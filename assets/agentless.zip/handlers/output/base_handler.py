class BaseHandler():
    def __init__(self, config):
        self.config = config

    def handle(self, data):
        raise NotImplementedError
