from handlers.output.base_handler import BaseHandler


class SQSOutputHandler(BaseHandler):
    def __init__(self, config):
        super().__init__(config)

    def handle(self, data):
        send_to_sqs(queue_name,data)

