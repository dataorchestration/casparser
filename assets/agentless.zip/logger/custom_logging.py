import logging
import sys

# logger.basicConfig()
root = logging.getLogger()
root.setLevel(logging.INFO)
root.propagate = False

handler = logging.StreamHandler(sys.stdout)
# handler.setLevel(logger.INFO)
formatter = logging.Formatter('%(process)d %(filename)s %(asctime)s [%(name)s][%(levelname)s]::%(message)s')
handler.setFormatter(formatter)
root.addHandler(handler)

logger_resource = logging.getLogger('azure.mgmt.resource')
logger_resource.setLevel(logging.WARNING)
logger_mgmt = logging.getLogger('azure.core.pipeline.policies.http_logging_policy')
logger_mgmt.setLevel(logging.WARNING)
logger_uamqp = logging.getLogger('uamqp')
logger_uamqp.setLevel(logging.WARNING)
logger_identity = logging.getLogger('azure.identity._internal.get_token_mixin')
logger_identity.setLevel(logging.WARNING)


# disable logging from azure


def log(*args, **kwargs):
    logging.info(*args)


def log_error(*args, **kwargs):
    logging.exception(*args)


def debug(*args, **kwargs):
    logging.debug(*args)
