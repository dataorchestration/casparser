import enum
import json
import os

import requests


class BaseMessage():
    def to_json(self):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=4)


class ActionType(enum.Enum):
    CREATE_SNAPSHOT = 1
    WAIT_FOR_SNAPSHOT = 2
    CREATE_VOLUME = 3
    ATTACH_VOLUME = 4
    DETACH_VOLUME = 5
    DELETE_VOLUME = 6
    DELETE_SNAPSHOT = 7
    STOP_INSTANCE = 8
    START_INSTANCE = 9
    NEW_INSTANCE = 10


class APILogMessage(BaseMessage):
    def __init__(self, instance_id=None, volume_id=None, asset_id=None, type="pipeline_monitoring",
                 action: ActionType = None, message=None, action_metadata: dict = None, scanner_instance_id=None,
                 env_config={}, customer_id=None):
        self.instance_id = instance_id
        self.volume_id = volume_id
        self.asset_id = asset_id
        self.type = type
        self.action = action
        self.message = message
        self.action_metadata = action_metadata
        self.scanner_instance_id = scanner_instance_id
        self.customer_id = customer_id

    def get_formatted_json_data(self):
        data = {"node_key": f"{self.customer_id}:{self.asset_id}:asset:aws",
                "log_type": "result",
                "tables": {"side_query_agentless_pipeline": {"columns": {
                    "instance_id": self.instance_id,
                    "volume_id": self.volume_id,
                    "asset_id": self.asset_id,
                    "action": self.action,
                    "message": self.message,
                    "scanner_instance_id": self.scanner_instance_id,
                    "action_metadata": self.action_metadata,
                    "region": os.getenv("REGION"),
                    "account_id": os.getenv("ACCOUNT_ID"),
                    "zone": os.getenv("ZONE"),
                }}}}
        return data

    def send_to_endpoint(self):
        try:
            requests.post(os.getenv("API_ENDPOINT"), data=self.get_formatted_json_data())
        except:
            pass
