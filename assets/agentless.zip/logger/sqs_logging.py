import enum
import json
import os

from utils.aws.utils_sqs import send_message_to_sqs


class BaseMessage():
    def to_json(self):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=4)


class ActionType(enum.Enum):
    CREATE_SNAPSHOT = 1
    WAIT_FOR_SNAPSHOT = 2
    CREATE_VOLUME = 3
    ATTACH_VOLUME = 4
    DETACH_VOLUME = 5
    DELETE_VOLUME = 6
    DELETE_SNAPSHOT = 7
    STOP_INSTANCE = 8
    START_INSTANCE = 9
    INVALID_INSTANCE = 10


class SQSLogMessage(BaseMessage):
    def __init__(self, instance_id=None, volume_id=None, asset_id=None, type="pipeline_monitoring",
                 action: ActionType = None, message=None, action_metadata: dict = None, scanner_instance_id=None,
                 env_config={}):
        self.instance_id = instance_id
        self.volume_id = volume_id
        self.asset_id = asset_id
        self.type = type
        self.action = action
        self.message = message
        self.action_metadata = action_metadata
        self.scanner_instance_id = scanner_instance_id

    def send_to_sqs(self):
        try:
            send_message_to_sqs(region_name=os.getenv("REGION"), message=self.to_json(),
                                queue_name=os.getenv("LOGGING_QUEUE_NAME"))
        except:
            pass
