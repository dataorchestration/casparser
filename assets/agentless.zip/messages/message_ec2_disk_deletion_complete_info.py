from messages import BaseMessage


class DiskDeletionComplete(BaseMessage):
    def __init__(self, volume_name=None,asset_id=None):
        self.volume_name = volume_name
        self.asset_id = asset_id
