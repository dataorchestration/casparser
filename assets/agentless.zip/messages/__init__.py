"""
types of messages
"""
import json


class BaseMessage():
    def to_dict(self):
        return self.__dict__

    def to_json(self):
        return json.dumps(self.__dict__)

    def from_json(self, json_string):
        return json.loads(json_string)

    def from_dict(self, dict_data):
        for key, value in dict_data.items():
            setattr(self, key, value)
