from messages import BaseMessage


class InstanceVolumeToScan(BaseMessage):
    def __init__(self, instance_name=None, volume_name=None, dest_volume_name=None, dest_snapshot_name=None,
                 account_id=None, region=None, aws_job_id=None,asset_id=None):
        self.instance_name = instance_name
        self.volume_name = volume_name
        self.dest_volume_name = dest_volume_name
        self.dest_snapshot_name = dest_snapshot_name
        self.aws_account_id = account_id
        self.aws_region = region
        self.aws_job_id = aws_job_id
        self.asset_id = asset_id



