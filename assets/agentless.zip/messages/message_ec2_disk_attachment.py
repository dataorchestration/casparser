from messages import BaseMessage


class Ec2InstancesDiskAttachment(BaseMessage):
    def __init__(self, instance_name=None, project_id=None, zone=None, volume_name=None, disk_size_gb=None,
                 dest_volume_name=None, tags=[], aws_job_id=None,asset_id=None):
        self.instance_name = instance_name
        self.project_id = project_id
        self.zone = zone
        self.volume_name = volume_name
        self.disk_size_gb = disk_size_gb
        self.tags = tags
        self.dest_volume_name = dest_volume_name
        self.aws_job_id = aws_job_id
        self.asset_id = asset_id
