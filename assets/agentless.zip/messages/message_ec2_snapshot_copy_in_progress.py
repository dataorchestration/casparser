from messages import BaseMessage


class SnapshotCopyInProgress(BaseMessage):
    def __init__(self, snapshot_name=None, volume_name=None, project_id=None, zone=None, disk_size_gb=None,
                 dest_volume_name=None, account_id=None, region=None, aws_job_id=None, asset_id=None,
                 original_instance_id=None, blob_name=None, container_name=None):
        self.snapshot_name = snapshot_name
        self.volume_name = volume_name
        self.project_id = project_id
        self.zone = zone
        self.disk_size_gb = disk_size_gb
        self.dest_volume_name = dest_volume_name
        self.aws_account_id = account_id
        self.aws_region = region
        self.aws_job_id = aws_job_id
        self.asset_id = asset_id
        self.original_instance_id = original_instance_id
        self.blob_name = blob_name
        self.container_name = container_name
