from messages import BaseMessage


class InstanceVolumeDetachment(BaseMessage):
    def __init__(self, instance_name=None, volume_name=None,asset_id=None):
        self.instance_name = instance_name
        self.volume_name = volume_name
        self.asset_id = asset_id
