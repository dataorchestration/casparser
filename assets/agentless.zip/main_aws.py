import logging

from triggers.trigger_cleanup_lambda import TriggerCleanUp
from triggers.trigger_disk_creation_for_snapshot_ready import TriggerDiskCreationOnSnapshotComplete
from triggers.trigger_disk_snapshotting_for_incoming_compute import TriggerDiskSnapshottingForIncomingCompute
from triggers.trigger_monitoring_lambda import TriggerMonitoring
from triggers.trigger_new_ec2_running_trigger import NewEC2RunningEvent
from triggers.trigger_volume_attachment import TriggerVolumeAttachment
from triggers.trigger_volume_dettachment import TriggerVolumeDettachment


def function_volume_scanning_trigger(cloud_event, context):
    logging.info(f"Received event: {cloud_event}")
    logging.info("Triggering volume scanning with data: %s", cloud_event)
    TriggerDiskSnapshottingForIncomingCompute().entry_point(cloud_event, cloud_type="aws")


def function_disk_creation_trigger(cloud_event, context):
    logging.info(f"Received event: {cloud_event}")
    logging.info("Triggering disk creation with data: %s", cloud_event)
    TriggerDiskCreationOnSnapshotComplete().entry_point(cloud_event, cloud_type="aws")


def function_disk_attachment_trigger(cloud_event, context):
    logging.info(f"Received event: {cloud_event}")
    logging.info("Triggering disk attachment with data: %s", cloud_event)
    TriggerVolumeAttachment().entry_point(cloud_event, cloud_type="aws")


def function_disk_detachment_trigger(cloud_event, context):
    logging.info(f"Received event: {cloud_event}")
    logging.info("Triggering disk detachment with data: %s", cloud_event)
    TriggerVolumeDettachment().entry_point(cloud_event, cloud_type="aws")


def function_monitoring(cloud_event, context):
    logging.info(f"Received event: {cloud_event}")
    logging.info("Triggering monitoring with data: %s", cloud_event)
    TriggerMonitoring().entry_point(cloud_event, cloud_type="aws")


def function_ec2_running_trigger(cloud_event, context):
    logging.info(f"Received event: {cloud_event}")
    logging.info("Triggering ec2 running with data: %s", cloud_event)
    NewEC2RunningEvent().entry_point(cloud_event, cloud_type="aws")


def function_cleanup_trigger(cloud_event, context):
    logging.info(f"Received event: {cloud_event}")
    logging.info("Triggering ec2 running with data: %s", cloud_event)
    TriggerCleanUp().entry_point(cloud_event, cloud_type="aws")
