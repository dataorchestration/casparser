#!/usr/bin/env bash
rm layer.zip || true
rm -r python || true
rm cloudfunction-v1.zip  || true && zip -r cloudfunction-v1.zip ./* -x "./venv/*" "./.idea/*" "./.git/*" "./\.*" "./layers/\.*" "./buildvenv/*"
mkdir python
pip3 --version
pip3 install -r requirements.txt -t python/ && zip -r layer.zip python -x "./buildvenv/*" && rm -rf python
